var getChatbotRecentReportList = {
    "response": [
        {
            "stockCode": null,
            "title": "[11-05] AI 실적속보: AMD (AMD US) - FY25 3분기 실적 및 가이던스 리뷰 / 김세환",
            "category": null,
            "flag": null,
            "cnt": 2167,
            "pageNo": 0,
            "documentid": "20251105140108213K",
            "keyword": null,
            "pageSize": 0,
            "urlLinkH": "▶ https://bit.ly/4nFLc7B",
            "urlLink": "https://rcv.kbsec.com/streamdocs/pdfview?id=B520190322125512762443&amp;wInfo=(wInfo)&url=aHR0cDovL3JkYXRhLmtic2VjLmNvbS9wZGZfZGF0YS8yMDI1MTEwNTE0MDEwODIxM0sucGRm"
        },
        {
            "stockCode": null,
            "title": "[11-05] KB Asia Monitor - 선명해지는 중국의 희토류, 자동차 반도체 장악력 / 박수현",
            "category": null,
            "flag": null,
            "cnt": 2167,
            "pageNo": 0,
            "documentid": "20251105124925277K",
            "keyword": null,
            "pageSize": 0,
            "urlLinkH": "▶ https://bit.ly/3WFcQGS",
            "urlLink": "https://rcv.kbsec.com/streamdocs/pdfview?id=B520190322125512762443&amp;wInfo=(wInfo)&url=aHR0cDovL3JkYXRhLmtic2VjLmNvbS9wZGZfZGF0YS8yMDI1MTEwNTEyNDkyNTI3N0sucGRm"
        },
        {
            "stockCode": null,
            "title": "[11-05] AI 실적속보: SK바이오팜 (326030) - 3Q25 실적속보: 컨센서스 상회 / 김혜민",
            "category": null,
            "flag": null,
            "cnt": 2167,
            "pageNo": 0,
            "documentid": "20251104102907910K",
            "keyword": null,
            "pageSize": 0,
            "urlLinkH": "▶ https://bit.ly/3JsXiTz",
            "urlLink": "https://rcv.kbsec.com/streamdocs/pdfview?id=B520190322125512762443&amp;wInfo=(wInfo)&url=aHR0cDovL3JkYXRhLmtic2VjLmNvbS9wZGZfZGF0YS8yMDI1MTEwNDEwMjkwNzkxMEsucGRm"
        },
        {
            "stockCode": null,
            "title": "[11-05] 글로벌 기업 | Tracker+ - 밥콕 앤 윌콕스 엔터프라이즈, 염 브랜즈, AMD 등 / 김세환",
            "category": null,
            "flag": null,
            "cnt": 2167,
            "pageNo": 0,
            "documentid": "20251105110236600K",
            "keyword": null,
            "pageSize": 0,
            "urlLinkH": "▶ https://bit.ly/4hIdddf",
            "urlLink": "https://rcv.kbsec.com/streamdocs/pdfview?id=B520190322125512762443&amp;wInfo=(wInfo)&url=aHR0cDovL3JkYXRhLmtic2VjLmNvbS9wZGZfZGF0YS8yMDI1MTEwNTExMDIzNjYwMEsucGRm"
        },
        {
            "stockCode": null,
            "title": "[11-05] KB 주식시황 - 강세장 속 조정에 대해 (1): 조정의 폭과 기간 / 하인환",
            "category": null,
            "flag": null,
            "cnt": 2167,
            "pageNo": 0,
            "documentid": "20251105102217353K",
            "keyword": null,
            "pageSize": 0,
            "urlLinkH": "▶ https://bit.ly/4oShf5e",
            "urlLink": "https://rcv.kbsec.com/streamdocs/pdfview?id=B520190322125512762443&amp;wInfo=(wInfo)&url=aHR0cDovL3JkYXRhLmtic2VjLmNvbS9wZGZfZGF0YS8yMDI1MTEwNTEwMjIxNzM1M0sucGRm"
        }
    ],
    "message": "OK",
    "status": "200"
};

