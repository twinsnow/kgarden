/**
 * 금리 시장 동향 샘플 데이터 (개발 환경용)
 */
var getMainScrtMrktTrndDy = {
    "response": {
        "chartUrl": null,
        "strt_date": "20251005",
        "end_date": "20251105",
        "lngth": "03059",
        "clsfP": "SC",
        "nxtKey": "        ",
        "record1": [
            {
                "amt1": "257",
                "dt": "20251104",
                "amt3": "308",
                "amt2": "273",
                "gnlIndx": "4121.74",
                "amt4": "288",
                "bdyRt3": "0",
                "bdyRt4": "0",
                "bdyRt1": "1",
                "bdyRt2": "-1",
                "upDwnR": "-2.37",
                "upDwnGap": "-100.13"
            }
        ]
    },
    "message": "OK",
    "status": "200"
};

