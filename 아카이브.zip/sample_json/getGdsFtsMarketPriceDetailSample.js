/**
 * 유가/상품 상세 조회 샘플 데이터 (차트 포함)
 * 실제 서버 연결 전까지 사용되는 샘플 데이터
 */
var getGdsFtsMarketPriceDetailSample = {
    "NYM@CL": {
        "response": {
            "clsf": "21",
            "chartUrl": "/chartImgFiles/202511/chart_NYM@CL_3_20251105135940680.png",
            "dataCnt": "3",
            "record1": [
                {
                    "krxNm": "뉴욕상업거래소(NYM)",
                    "nowPrc": "60.56",
                    "dt": "20251104",
                    "opnPrc": "61.03",
                    "cmprr": "-0.80",
                    "lwPrc": "59.94",
                    "isNm": "WTI",
                    "vlm": "193610",
                    "ttm": "      ",
                    "cmpr": "-0.49",
                    "hghPrc": "61.03",
                    "cd": "NYM@CL"
                }
            ]
        },
        "message": "OK",
        "status": "200"
    },
    "SPT@DU": {
        "response": {
            "clsf": "21",
            "chartUrl": "/chartImgFiles/202511/chart_SPT@DU_3_20251105135940680.png",
            "dataCnt": "1",
            "record1": [
                {
                    "krxNm": "현물(SPT)",
                    "nowPrc": "65.37",
                    "dt": "20251104",
                    "opnPrc": "65.37",
                    "cmprr": "-1.98",
                    "lwPrc": "65.37",
                    "isNm": "두바이유 현물",
                    "vlm": "0",
                    "ttm": "      ",
                    "cmpr": "-1.32",
                    "hghPrc": "65.37",
                    "cd": "SPT@DU"
                }
            ]
        },
        "message": "OK",
        "status": "200"
    },
    "IPE@EB": {
        "response": {
            "clsf": "21",
            "chartUrl": "/chartImgFiles/202511/chart_IPE@EB_3_20251105135940680.png",
            "dataCnt": "1",
            "record1": [
                {
                    "krxNm": "국제석유거래소(IPE)",
                    "nowPrc": "64.44",
                    "dt": "20251104",
                    "opnPrc": "64.73",
                    "cmprr": "-0.69",
                    "lwPrc": "63.82",
                    "isNm": "브렌트유",
                    "vlm": "307105",
                    "ttm": "      ",
                    "cmpr": "-0.45",
                    "hghPrc": "64.80",
                    "cd": "IPE@EB"
                }
            ]
        },
        "message": "OK",
        "status": "200"
    },
    "COM@GC": {
        "response": {
            "clsf": "22",
            "chartUrl": "/chartImgFiles/202511/chart_COM@GC_3_20251105135940680.png",
            "dataCnt": "1",
            "record1": [
                {
                    "krxNm": "뉴욕상품거래소(COM)",
                    "nowPrc": "4014.00",
                    "dt": "20251103",
                    "opnPrc": "4001.00",
                    "cmprr": "0.44",
                    "lwPrc": "3971.30",
                    "isNm": "금",
                    "vlm": "0",
                    "ttm": "      ",
                    "cmpr": "17.50",
                    "hghPrc": "4043.10",
                    "cd": "COM@GC"
                }
            ]
        },
        "message": "OK",
        "status": "200"
    },
    "COM@SI": {
        "response": {
            "clsf": "22",
            "chartUrl": "/chartImgFiles/202511/chart_COM@SI_3_20251105135940680.png",
            "dataCnt": "1",
            "record1": [
                {
                    "krxNm": "뉴욕상품거래소(COM)",
                    "nowPrc": "48.05",
                    "dt": "20251103",
                    "opnPrc": "48.25",
                    "cmprr": "-0.23",
                    "lwPrc": "47.76",
                    "isNm": "은",
                    "vlm": "0",
                    "ttm": "      ",
                    "cmpr": "-0.11",
                    "hghPrc": "48.84",
                    "cd": "COM@SI"
                }
            ]
        },
        "message": "OK",
        "status": "200"
    },
    "COM@HG": {
        "response": {
            "clsf": "22",
            "chartUrl": "/chartImgFiles/202511/chart_COM@HG_3_20251105135940680.png",
            "dataCnt": "1",
            "record1": [
                {
                    "krxNm": "뉴욕상품거래소(COM)",
                    "nowPrc": "3.50",
                    "dt": "20251103",
                    "opnPrc": "3.52",
                    "cmprr": "-0.57",
                    "lwPrc": "3.48",
                    "isNm": "구리",
                    "vlm": "0",
                    "ttm": "      ",
                    "cmpr": "-0.02",
                    "hghPrc": "3.55",
                    "cd": "COM@HG"
                }
            ]
        },
        "message": "OK",
        "status": "200"
    }
};

