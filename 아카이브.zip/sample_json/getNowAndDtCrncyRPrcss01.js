/**
 * 원/달러 환율 샘플 데이터 (개발 환경용)
 */
var getNowAndDtCrncyRPrcss01 = {
    "response": {
        "nowPrc": "144575",
        "dt": "20251105",
        "opnPrc": "144350",
        "chartUrl": null,
        "dataCnt": "50",
        "tm": "1445",
        "crncyNm": "원",
        "lwPrc": "144320",
        "record1": [
            {
                "dt": "20251105",
                "krwExchR": "10000",
                "mm1Bfr": "327",
                "bdyRt": "78500",
                "usdExchR": "144575",
                "mm3Bfr": "467"
            },
            {
                "dt": "20251104",
                "krwExchR": "10000",
                "mm1Bfr": "271",
                "bdyRt": "91000",
                "usdExchR": "143790",
                "mm3Bfr": "411"
            }
        ],
        "bdyRt": "785",
        "ntnNm": "한국",
        "crncyCd": "KRW",
        "hghPrc": "144950",
        "upDwnR": "055"
    },
    "message": "OK",
    "status": "200"
};

