/**
 * 엔/달러 환율 샘플 데이터 (개발 환경용)
 */
var getNowAndDtCrncyRPrcss02 = {
    "response": {
        "nowPrc": "153",
        "dt": "20251105",
        "opnPrc": "154",
        "chartUrl": null,
        "dataCnt": "50",
        "tm": "0550",
        "crncyNm": "엔(100)",
        "lwPrc": "153",
        "record1": [
            {
                "dt": "20251105",
                "krwExchR": "9421000",
                "mm1Bfr": "002",
                "bdyRt": "-0020",
                "usdExchR": "153",
                "mm3Bfr": "004"
            }
        ],
        "bdyRt": "-000",
        "ntnNm": "일본",
        "crncyCd": "JPY",
        "hghPrc": "154",
        "upDwnR": "-000"
    },
    "message": "OK",
    "status": "200"
};

