/**
 * 글로벌증시 조회 샘플 데이터
 * 실제 서버 연결 전까지 사용되는 샘플 데이터
 */
var getWorldIndexSample = {
    "response": {
        "dataCnt": "38",
        "record1": [
            {
                "nowPrc": "399755",
                "dt": "20251105",
                "opnPrc": "405547",
                "tm": "1336",
                "cmprr": "-301",
                "lwPrc": "386781",
                "indxCd": "KI.001",
                "ntnNm": "한국",
                "indxNm": "KOSPI",
                "vlm": "474284",
                "hghPrc": "405547",
                "cmpr": "-12419"
            },
            {
                "nowPrc": "89878",
                "dt": "20251105",
                "opnPrc": "91928",
                "tm": "1336",
                "cmprr": "-300",
                "lwPrc": "87179",
                "indxCd": "QI.001",
                "ntnNm": "한국",
                "indxNm": "KOSDAQ",
                "vlm": "940371",
                "hghPrc": "91928",
                "cmpr": "-2779"
            },
            {
                "nowPrc": "4708524",
                "dt": "20251104",
                "opnPrc": "4714804",
                "tm": "9999",
                "cmprr": "-053",
                "lwPrc": "4687706",
                "indxCd": "DJI@DJI",
                "ntnNm": "미국",
                "indxNm": "다우 산업",
                "vlm": "504133312",
                "hghPrc": "4727490",
                "cmpr": "-25144"
            },
            {
                "nowPrc": "2334864",
                "dt": "20251104",
                "opnPrc": "2345821",
                "tm": "9999",
                "cmprr": "-204",
                "lwPrc": "2333332",
                "indxCd": "NAS@IXIC",
                "ntnNm": "미국",
                "indxNm": "나스닥 종합",
                "vlm": "2147483647",
                "hghPrc": "2364415",
                "cmpr": "-48609"
            },
            {
                "nowPrc": "677155",
                "dt": "20251104",
                "opnPrc": "678852",
                "tm": "9999",
                "cmprr": "-117",
                "lwPrc": "676671",
                "indxCd": "SPI@SPX",
                "ntnNm": "미국",
                "indxNm": "S&P 500",
                "vlm": "2147483647",
                "hghPrc": "682021",
                "cmpr": "-8042"
            },
            {
                "nowPrc": "4987722",
                "dt": "20251105",
                "opnPrc": "5129139",
                "tm": "1321",
                "cmprr": "-315",
                "lwPrc": "4907358",
                "indxCd": "NII@NI225",
                "ntnNm": "일본",
                "indxNm": "니케이 225",
                "vlm": "1295653700",
                "hghPrc": "5142242",
                "cmpr": "-161998"
            },
            {
                "nowPrc": "2587880",
                "dt": "20251105",
                "opnPrc": "2570163",
                "tm": "1205",
                "cmprr": "-028",
                "lwPrc": "2549613",
                "indxCd": "HSI@HSI",
                "ntnNm": "홍콩",
                "indxNm": "항셍",
                "vlm": "1477076850",
                "hghPrc": "2588391",
                "cmpr": "-7360"
            },
            {
                "nowPrc": "396204",
                "dt": "20251105",
                "opnPrc": "392258",
                "tm": "1130",
                "cmprr": "005",
                "lwPrc": "392258",
                "indxCd": "SHS@000001",
                "ntnNm": "중국",
                "indxNm": "상해종합",
                "vlm": "386105207",
                "hghPrc": "396492",
                "cmpr": "185"
            },
            {
                "nowPrc": "2777813",
                "dt": "20251105",
                "opnPrc": "2778591",
                "tm": "1216",
                "cmprr": "-120",
                "lwPrc": "2737305",
                "indxCd": "TWS@TI01",
                "ntnNm": "대만",
                "indxNm": "대만 가권",
                "vlm": "0",
                "hghPrc": "2779909",
                "cmpr": "-33843"
            },
            {
                "nowPrc": "2394911",
                "dt": "20251104",
                "opnPrc": "2380124",
                "tm": "9999",
                "cmprr": "-076",
                "lwPrc": "2367465",
                "indxCd": "XTR@DAX30",
                "ntnNm": "독일",
                "indxNm": "독일 DAX30",
                "vlm": "0",
                "hghPrc": "2397431",
                "cmpr": "-18330"
            },
            {
                "nowPrc": "971496",
                "dt": "20251104",
                "opnPrc": "970140",
                "tm": "9999",
                "cmprr": "014",
                "lwPrc": "957415",
                "indxCd": "LNS@FTSE100",
                "ntnNm": "영국",
                "indxNm": "영국 FTSE100",
                "vlm": "0",
                "hghPrc": "971496",
                "cmpr": "1359"
            }
        ]
    },
    "message": "OK",
    "status": "200"
};

