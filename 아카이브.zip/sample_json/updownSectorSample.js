/**
 * 업종 등락 조회 샘플 데이터
 * 실제 서버 연결 전까지 사용되는 샘플 데이터
 */
var updownSectorSample = {
    "updownSectorSample": {
        "description": "업종 등락 조회 샘플 데이터",
        "apis": [
            {
                "name": "업종 상승 (upDownKndCd=1)",
                "requestUrl": "/ajax/getRiseUpSectorQuotations.json",
                "payload": {
                    "infoClsf": "5",
                    "upDownKndCd": "1",
                    "isCnt": "5"
                },
                "response": {
                    "response": {
                        "infoClsf": "5",
                        "record1": [
                            {
                                "indTypNm": "KRX 건강",
                                "indx": "445570",
                                "bDyCmprSmbl": "2",
                                "vlm": null,
                                "bDyCmpr": "15194",
                                "upDwnR": "353",
                                "cd": "XGS03P"
                            },
                            {
                                "indTypNm": "KRX 기계장비",
                                "indx": "164889",
                                "bDyCmprSmbl": "2",
                                "vlm": null,
                                "bDyCmpr": "5077",
                                "upDwnR": "318",
                                "cd": "XGS10P"
                            },
                            {
                                "indTypNm": "KRX 증권",
                                "indx": "161419",
                                "bDyCmprSmbl": "2",
                                "vlm": null,
                                "bDyCmpr": "4872",
                                "upDwnR": "311",
                                "cd": "XGS09P"
                            },
                            {
                                "indTypNm": "KRX K콘텐츠",
                                "indx": "211819",
                                "bDyCmprSmbl": "2",
                                "vlm": null,
                                "bDyCmpr": "5265",
                                "upDwnR": "255",
                                "cd": "XGS15P"
                            },
                            {
                                "indTypNm": "KRX 100",
                                "indx": "880993",
                                "bDyCmprSmbl": "2",
                                "vlm": null,
                                "bDyCmpr": "21619",
                                "upDwnR": "252",
                                "cd": "XGG01P"
                            }
                        ]
                    },
                    "message": "OK",
                    "status": "200"
                }
            },
            {
                "name": "업종 하락 (upDownKndCd=2)",
                "requestUrl": "/ajax/getRiseUpSectorQuotations.json",
                "payload": {
                    "infoClsf": "5",
                    "upDownKndCd": "2",
                    "isCnt": "5"
                },
                "response": {
                    "response": {
                        "infoClsf": "5",
                        "record1": [
                            {
                                "indTypNm": "KRX 철강",
                                "indx": "248260",
                                "bDyCmprSmbl": "5",
                                "vlm": null,
                                "bDyCmpr": "4978",
                                "upDwnR": "197",
                                "cd": "XGS06P"
                            },
                            {
                                "indTypNm": "KRX 보험",
                                "indx": "259764",
                                "bDyCmprSmbl": "5",
                                "vlm": null,
                                "bDyCmpr": "663",
                                "upDwnR": "025",
                                "cd": "XGS11P"
                            },
                            {
                                "indTypNm": "KRX 유틸리티",
                                "indx": "79940",
                                "bDyCmprSmbl": "5",
                                "vlm": null,
                                "bDyCmpr": "118",
                                "upDwnR": "015",
                                "cd": "XGS17P"
                            }
                        ]
                    },
                    "message": "OK",
                    "status": "200"
                }
            }
        ]
    }
};

