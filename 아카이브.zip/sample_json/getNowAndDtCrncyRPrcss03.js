/**
 * 유로/달러 환율 샘플 데이터 (개발 환경용)
 */
var getNowAndDtCrncyRPrcss03 = {
    "response": {
        "nowPrc": "087",
        "dt": "20251105",
        "opnPrc": "087",
        "chartUrl": null,
        "dataCnt": "50",
        "tm": "0549",
        "crncyNm": "유로",
        "lwPrc": "087",
        "record1": [
            {
                "dt": "20251105",
                "krwExchR": "16620500",
                "mm1Bfr": "192",
                "bdyRt": "-0009",
                "usdExchR": "087",
                "mm3Bfr": "158"
            }
        ],
        "bdyRt": "-000",
        "ntnNm": "유럽",
        "crncyCd": "EUR",
        "hghPrc": "087",
        "upDwnR": "-010"
    },
    "message": "OK",
    "status": "200"
};

