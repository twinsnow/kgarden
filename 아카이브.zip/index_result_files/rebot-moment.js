/**
 * Rebot Moment.js 대체
 * 기존 moment.min.js의 핵심 기능들을 rebot 프로젝트에 맞게 최적화
 */

window.RebotMoment = {
    
    /**
     * 현재 시간 반환
     * @returns {Date} - 현재 시간
     */
    now: function() {
        return new Date();
    },
    
    /**
     * 날짜 파싱
     * @param {string|Date|number} input - 입력값
     * @returns {Date} - 파싱된 날짜
     */
    parse: function(input) {
        if (!input) return new Date();
        if (input instanceof Date) return input;
        if (typeof input === 'number') return new Date(input);
        if (typeof input === 'string') {
            const parsed = new Date(input);
            return isNaN(parsed.getTime()) ? new Date() : parsed;
        }
        return new Date();
    },
    
    /**
     * 날짜 포맷팅
     * @param {Date|string|number} date - 날짜
     * @param {string} format - 포맷 문자열
     * @returns {string} - 포맷된 날짜 문자열
     */
    format: function(date, format = 'YYYY-MM-DD HH:mm:ss') {
        const d = this.parse(date);
        if (isNaN(d.getTime())) return '';
        
        const year = d.getFullYear();
        const month = String(d.getMonth() + 1).padStart(2, '0');
        const day = String(d.getDate()).padStart(2, '0');
        const hours = String(d.getHours()).padStart(2, '0');
        const minutes = String(d.getMinutes()).padStart(2, '0');
        const seconds = String(d.getSeconds()).padStart(2, '0');
        
        return format
            .replace(/YYYY/g, year)
            .replace(/MM/g, month)
            .replace(/DD/g, day)
            .replace(/HH/g, hours)
            .replace(/mm/g, minutes)
            .replace(/ss/g, seconds)
            .replace(/YY/g, String(year).slice(-2))
            .replace(/M/g, d.getMonth() + 1)
            .replace(/D/g, d.getDate())
            .replace(/H/g, d.getHours())
            .replace(/m/g, d.getMinutes())
            .replace(/s/g, d.getSeconds());
    },
    
    /**
     * 상대 시간 표시
     * @param {Date|string|number} date - 날짜
     * @returns {string} - 상대 시간 문자열
     */
    fromNow: function(date) {
        const d = this.parse(date);
        const now = new Date();
        const diff = now - d;
        
        const seconds = Math.floor(diff / 1000);
        const minutes = Math.floor(seconds / 60);
        const hours = Math.floor(minutes / 60);
        const days = Math.floor(hours / 24);
        const months = Math.floor(days / 30);
        const years = Math.floor(days / 365);
        
        if (years > 0) return `${years}년 전`;
        if (months > 0) return `${months}개월 전`;
        if (days > 0) return `${days}일 전`;
        if (hours > 0) return `${hours}시간 전`;
        if (minutes > 0) return `${minutes}분 전`;
        return '방금 전';
    },
    
    /**
     * 날짜 차이 계산
     * @param {Date|string|number} date1 - 첫 번째 날짜
     * @param {Date|string|number} date2 - 두 번째 날짜
     * @param {string} unit - 단위 (days, hours, minutes, seconds)
     * @returns {number} - 차이값
     */
    diff: function(date1, date2, unit = 'days') {
        const d1 = this.parse(date1);
        const d2 = this.parse(date2);
        const diff = Math.abs(d1 - d2);
        
        switch (unit) {
            case 'years':
                return Math.floor(diff / (365 * 24 * 60 * 60 * 1000));
            case 'months':
                return Math.floor(diff / (30 * 24 * 60 * 60 * 1000));
            case 'days':
                return Math.floor(diff / (24 * 60 * 60 * 1000));
            case 'hours':
                return Math.floor(diff / (60 * 60 * 1000));
            case 'minutes':
                return Math.floor(diff / (60 * 1000));
            case 'seconds':
                return Math.floor(diff / 1000);
            default:
                return diff;
        }
    },
    
    /**
     * 날짜 더하기
     * @param {Date|string|number} date - 기준 날짜
     * @param {number} amount - 추가할 양
     * @param {string} unit - 단위
     * @returns {Date} - 계산된 날짜
     */
    add: function(date, amount, unit = 'days') {
        const d = new Date(this.parse(date));
        
        switch (unit) {
            case 'years':
                d.setFullYear(d.getFullYear() + amount);
                break;
            case 'months':
                d.setMonth(d.getMonth() + amount);
                break;
            case 'days':
                d.setDate(d.getDate() + amount);
                break;
            case 'hours':
                d.setHours(d.getHours() + amount);
                break;
            case 'minutes':
                d.setMinutes(d.getMinutes() + amount);
                break;
            case 'seconds':
                d.setSeconds(d.getSeconds() + amount);
                break;
        }
        
        return d;
    },
    
    /**
     * 날짜 빼기
     * @param {Date|string|number} date - 기준 날짜
     * @param {number} amount - 빼할 양
     * @param {string} unit - 단위
     * @returns {Date} - 계산된 날짜
     */
    subtract: function(date, amount, unit = 'days') {
        return this.add(date, -amount, unit);
    },
    
    /**
     * 날짜 시작 시간 (00:00:00)
     * @param {Date|string|number} date - 날짜
     * @returns {Date} - 시작 시간
     */
    startOf: function(date, unit = 'day') {
        const d = new Date(this.parse(date));
        
        switch (unit) {
            case 'year':
                d.setMonth(0, 1);
                d.setHours(0, 0, 0, 0);
                break;
            case 'month':
                d.setDate(1);
                d.setHours(0, 0, 0, 0);
                break;
            case 'day':
                d.setHours(0, 0, 0, 0);
                break;
            case 'hour':
                d.setMinutes(0, 0, 0);
                break;
            case 'minute':
                d.setSeconds(0, 0);
                break;
        }
        
        return d;
    },
    
    /**
     * 날짜 끝 시간 (23:59:59)
     * @param {Date|string|number} date - 날짜
     * @returns {Date} - 끝 시간
     */
    endOf: function(date, unit = 'day') {
        const d = new Date(this.parse(date));
        
        switch (unit) {
            case 'year':
                d.setMonth(11, 31);
                d.setHours(23, 59, 59, 999);
                break;
            case 'month':
                d.setMonth(d.getMonth() + 1, 0);
                d.setHours(23, 59, 59, 999);
                break;
            case 'day':
                d.setHours(23, 59, 59, 999);
                break;
            case 'hour':
                d.setMinutes(59, 59, 999);
                break;
            case 'minute':
                d.setSeconds(59, 999);
                break;
        }
        
        return d;
    },
    
    /**
     * 날짜 유효성 검사
     * @param {Date|string|number} date - 날짜
     * @returns {boolean} - 유효성 여부
     */
    isValid: function(date) {
        const d = this.parse(date);
        return !isNaN(d.getTime());
    },
    
    /**
     * 요일 반환
     * @param {Date|string|number} date - 날짜
     * @returns {number} - 요일 (0: 일요일, 6: 토요일)
     */
    day: function(date) {
        const d = this.parse(date);
        return d.getDay();
    },
    
    /**
     * 요일명 반환
     * @param {Date|string|number} date - 날짜
     * @param {string} locale - 로케일 (ko, en)
     * @returns {string} - 요일명
     */
    dayName: function(date, locale = 'ko') {
        const d = this.parse(date);
        const day = d.getDay();
        
        const dayNames = {
            ko: ['일요일', '월요일', '화요일', '수요일', '목요일', '금요일', '토요일'],
            en: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
        };
        
        return dayNames[locale] ? dayNames[locale][day] : dayNames.ko[day];
    },
    
    /**
     * 월명 반환
     * @param {Date|string|number} date - 날짜
     * @param {string} locale - 로케일 (ko, en)
     * @returns {string} - 월명
     */
    monthName: function(date, locale = 'ko') {
        const d = this.parse(date);
        const month = d.getMonth();
        
        const monthNames = {
            ko: ['1월', '2월', '3월', '4월', '5월', '6월', '7월', '8월', '9월', '10월', '11월', '12월'],
            en: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']
        };
        
        return monthNames[locale] ? monthNames[locale][month] : monthNames.ko[month];
    }
};
