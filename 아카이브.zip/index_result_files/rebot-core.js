/**
 * Rebot Core Utilities
 * 기존 챗봇의 핵심 기능들을 rebot 프로젝트에 맞게 최적화
 */

// 전역 변수
window.RebotCore = {
    searchNo: "01",
    isInitialized: false,
    
    // 기존 챗봇 상수들
    MARKET_DATA: [
        { mktClsf: '5', invstClsf: '1', indTypCd: 'KGG01P', marketType: 'KOSPI', koName: '코스피' },
        { mktClsf: '6', invstClsf: '2', indTypCd: 'QGG01P', marketType: 'KOSDAQ', koName: '코스닥' }
    ],
    UPDOWN_CODE: [
        { code:'051', koNm:'자동차', enNm:'KRXAutos' },
        { code:'052', koNm:'반도체', enNm:'KRXSemicon' },
        { code:'053', koNm:'헬스케어', enNm:'KRXHealthCare' },
        { code:'054', koNm:'은행', enNm:'KRXBanks' },
        { code:'056', koNm:'에너지화학', enNm:'KRXEnergy&Cchem' },
        { code:'057', koNm:'철강', enNm:'KRXSteels' },
        { code:'059', koNm:'방송통신', enNm:'KRXMedia&Telecom' },
        { code:'060', koNm:'건설', enNm:'KRXConstruction' },
        { code:'062', koNm:'증권', enNm:'KRXSecurities' },
        { code:'063', koNm:'기계장비', enNm:'KRXMachin.&Equip' },
        { code:'064', koNm:'보험', enNm:'KRXInsurance' },
        { code:'065', koNm:'운송', enNm:'KRXTransportation' }
    ],
    EU_US_CODE: [
        { code : 'SPI@SPX', name : 'S&P 500', img : 'us.png'},
        { code : 'NAS@IXIC', name : '나스닥', img : 'us.png'},
        { code : 'DJI@DJI', name : '다우산업', img : 'us.png'},
        { code : 'XTR@DAX30', name : '독일 DAX30', img : 'de.png'},
        { code : 'PAS@CAC40', name : '프랑스 CAC40', img : 'fr.png'},
        { code : 'LNS@FTSE100', name : '영국 FTSE100', img : 'gb.png'}
    ],
    ASIA_CODE: [
        { code : 'KI.001', name : '한국 코스피', img : 'kr.png'},
        { code : 'QI.001', name : '한국 코스닥', img : 'kr.png'},
        { code : 'NII@NI225', name : '일본 닛케이', img : 'jp.png'},
        { code : 'HSI@HSI', name : '홍콩 항셍', img : 'hk.png'},
        { code : 'SHS@000001', name : '중국 상해종합', img : 'cn.png'},
        { code : 'TWS@TI01', name : '대만 가권', img : 'tw.png'}
    ],
    CODE_DATA: [
        { clsf : '21', code : 'NYM@CL', name : 'WTI', emoji: '🛢'},
        { clsf : '21', code : 'SPT@DU', name : '두바이', emoji: '🛢'},
        { clsf : '21', code : 'IPE@EB', name : '브렌트', emoji: '🛢'},
        { clsf : '22', code : 'COM@GC', name : '금', emoji: '🥇'},
        { clsf : '22', code : 'COM@SI', name : '은', emoji: '🥈'},
        { clsf : '22', code : 'COM@HG', name : '구리', emoji: '🥉'}
    ],
    EXCN_DATA: [
        { type : 'rp', code : '01', name : '원/달러', crncyCd: 'KRW', emoji: '💵' },
        { type : 'rp', code : '02', name : '엔/달러', crncyCd: 'JPY', emoji: '💴' },
        { type : 'rp', code : '03', name : '유로/달러', crncyCd: 'EUR', emoji: '💶' },
        { type : 'cd', code : '61', name : 'CD', emoji: '🏦' },
        { type : 'cd', code : '12', name : '국고3년', emoji: '🏦' },
        { type : 'cd', code : '14', name : '국고10년', emoji: '🏦' }
    ],
    
    // 초기화 함수
    init: function() {
        if (this.isInitialized) {
            return;
        }
        
        this.bindEvents();
        this.showWelcomeMessage();
        this.isInitialized = true;
    },
    
    // 환영 메시지 표시
    showWelcomeMessage: function(serviceName = null) {
        const chatArea = document.getElementById('main-chat-area');
        const welcomeDate = document.getElementById('welcome-date');
        
        if (welcomeDate) {
            const today = new Date();
            const year = today.getFullYear();
            const month = String(today.getMonth() + 1).padStart(2, '0');
            const day = String(today.getDate()).padStart(2, '0');
            welcomeDate.textContent = `${year}년 ${month}월 ${day}일`;
        }
        
        if (chatArea) {
            const welcomeMessage = document.createElement('article');
            welcomeMessage.className = 'prompt__wrapper__query';
            welcomeMessage.setAttribute('data-id', '');
            
            // 서비스명이 있으면 해당 서비스명을, 없으면 기본 메시지를 표시
            const titleText = serviceName || 'KB증권 리봇';
            const contentText = serviceName ? 
                `${serviceName} 정보를 조회합니다...` : 
                '안녕하세요! KB증권 리봇입니다. 원하시는 서비스를 선택하거나 질문을 입력해주세요.';
            
            welcomeMessage.innerHTML = `
                <div class="prompt__cont">
                    <div class="prompt__src sr_only" data-role="">
                        query:
                    </div>
                    <div class="prompt__query_box">
                        <div class="prompt__txt_adjust">
                            <div class="prompt__query_title">${titleText}</div>
                            <div class="prompt__model_chosen">
                                rebot thinking
                                <img src="icons/gr_ic.svg" alt="">
                            </div>
                            <div class="prompt__txt">${contentText}</div>
                        </div>
                    </div>
                </div>
            `;
            
            chatArea.appendChild(welcomeMessage);
        }
    },
    
    // 이벤트 바인딩
    bindEvents: function() {
        const self = this;
        
        // 채팅 입력 키보드 이벤트
        $(document).ready(function() {
            $("#content-chat-input").keydown(function(event) {
                var chatInData = self.XSSCheck($("#content-chat-input").val(), 0);
                
                if(event.keyCode == 13){
                    if(chatInData == "") {
                        return;
                    }
                    if(self.searchNo != "03"){
                        $(".topbtn__item").css({"background-color":"#ffffff"});
                    }
                    self.fn_chatBotBtn('srch', 'send');
                }
            });
        });
    }
};

/**
 * XSS 보안 처리 함수
 * @param {string} str - 검증할 문자열
 * @param {number} level - 보안 레벨 (0: 기본, 1: HTML 엔티티 변환)
 * @returns {string} - 검증된 문자열
 */
window.RebotCore.XSSCheck = function(str, level) {
    if (!str) return "";
    
    if (level == undefined || level == 0) {
        // 기본 XSS 방지: 특수문자 제거
        str = str.replace(/\<|\>|\"|\'|\%|\;|\(|\)|\&|\+|\-/g,"");
    } else if (level == 1) {
        // HTML 엔티티 변환
        str = str.replace(/\</g, "&lt;");
        str = str.replace(/\>/g, "&gt;");
    }
    return str;
};

/**
 * 챗봇 서비스 버튼 클릭 처리
 * @param {HTMLElement|string} chk - 클릭된 버튼 요소 또는 'srch'
 * @param {string} serviceChk - 서비스 타입
 */
window.RebotCore.fn_chatBotBtn = function(chk, serviceChk) {
    // 버튼 색상 초기화
    if(chk != "srch" || this.searchNo != "03") {
        $(".topbtn__item").css({"background-color":"#ffffff"});
    }
    
    // 버튼 클릭 효과 (노란색 깜박임)
    if(chk != "srch") {
        $(chk).css({"background-color":"#ffcc00"});
        $(chk).animate({"background-color":"#ffffff"}, 500);
    }
    
    // 입력값 검증 및 전송
    if(serviceChk == "send"){
        var inputValue = this.XSSCheck($("#content-chat-input").val(), 0);
        
        if(inputValue == "") {
            $("#content-chat-input").focus();
            return;
        }
        
        // 입력창 초기화
        $("#content-chat-input").val("");
        
        // 서비스 함수 호출
        this.subCallFunc(inputValue);
    } else {
        // 서비스 버튼 클릭 시
        this.subCallFunc(serviceChk);
    }
};

/**
 * 서비스 함수 호출 (AI 프롬프트 연동 준비)
 * @param {string} serviceChk - 서비스 타입 또는 입력값
 */
window.RebotCore.subCallFunc = function(serviceChk) {
    console.log("서비스 요청:", serviceChk);
    
    // 사용자에게 피드백 제공
    this.showUserFeedback(serviceChk);
    
    // 향후 AI 프롬프트 API 연동을 위한 구조
    if (typeof window.RebotAI !== 'undefined' && window.RebotAI.sendMessage) {
        // AI 프롬프트 연동 (차후 구현)
        window.RebotAI.sendMessage(serviceChk);
    } else {
        // 현재는 기본 동작
        this.handleServiceRequest(serviceChk);
    }
};

/**
 * 사용자 피드백 표시 (퍼블리싱된 구조 사용)
 */
window.RebotCore.showUserFeedback = function(serviceChk) {
            const chatArea = document.getElementById('main-chat-area');
    if (chatArea) {
        const userMessage = document.createElement('article');
        userMessage.className = 'prompt__wrapper__sender';
        userMessage.setAttribute('data-id', '');
        
        userMessage.innerHTML = `
            <div class="prompt__cont">
                <div class="prompt__src sr_only" data-role="">
                    user said:
                </div>
                <div class="prompt__txt_box">
                    <div class="prompt__txt_adjust">
                        <div class="prompt__timestamp">${new Date().toLocaleTimeString()}</div>
                        <div class="prompt__txt">${serviceChk}</div>
                    </div>
                </div>
            </div>
        `;
        
        chatArea.appendChild(userMessage);
        chatArea.scrollTop = chatArea.scrollHeight;
    }
};

/**
 * 서비스 요청 처리
 * @param {string} serviceChk - 서비스 타입
 */
window.RebotCore.handleServiceRequest = function(serviceChk) {
    // 서비스별 처리 로직
    if(serviceChk == "주식시장"){
        this.searchNo = "";
        this.stockMarket("M","0");	// 처음 주식시장 선택시 기본:코스피
    }else if(serviceChk == "업종/종목등락"){
        this.searchNo = "";
        this.typeUpDown("", "K");	// 처음 업종/종목등락 선택시 기본:KRX 
    }else if(serviceChk == "종목현재가"){
        this.searchNo = "03";
        this.stockPrice("F", "");
    }else if(serviceChk == "글로벌증시"){
        this.searchNo = "";
        var toHours = new Date().getHours();
        var code = (0 <= toHours && toHours < 12) ? "us" : "asia";
        this.globalMarket("", code);
    }else if(serviceChk == "유가/상품"){
        this.searchNo = "";
        this.oilProduct("", "");
    }else if(serviceChk == "금리/환율"){
        this.searchNo = "";
        this.exchange("", "");
    }else if(serviceChk == "KB데일리"){
        this.searchNo = "";
        this.kbDaily("", "first");
    }else if(serviceChk == "최신리포트"){
        this.searchNo = "";
        this.todayReport();
    }else if(serviceChk == "캘린더"){
        this.searchNo = "";
        this.calendar("", "");
    }else if(serviceChk == "애널리스트"){
        this.searchNo = "";
        this.analyst("", "");
    }else{
        // 일반 검색어 입력
        this.generalSearch(serviceChk);
    }
};

/**
 * AJAX 호출 함수
 */
window.RebotCore.ajaxCall = function(url, params, callback, errorCallback) {
    console.log("API 호출:", url, params);
    
    fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(params)
    })
    .then(response => response.json())
    .then(data => {
        console.log("API 응답:", data);
        if (callback) callback(data);
    })
    .catch(error => {
        console.error("API 오류:", error);
        if (errorCallback) {
            errorCallback(error);
        } else {
            this.showBotMessage("❌ 데이터 조회 중 오류가 발생했습니다.");
        }
    });
};

/**
 * 주식시장 정보 조회
 */
window.RebotCore.stockMarket = function(typeChk, valueChk) {
        this.showBotMessage("주식시장 정보를 조회합니다...", "주식시장");
    
    // 실제 API 호출
    const params = {
        mktClsf: this.MARKET_DATA[0].mktClsf,
        invstClsf: this.MARKET_DATA[0].invstClsf,
        indTypCd: this.MARKET_DATA[0].indTypCd
    };
    
    this.ajaxCall("/ajax/getChatBotCospiCosdaqChart.json", params, (data) => {
        if (data && data.response) {
            const marketData = this.MARKET_DATA[0];
            // 복잡한 결과 구조로 표시
            this.showComplexResult("주식시장", data);
        } else {
            // 복잡한 결과 구조로 표시
            this.showComplexResult("주식시장", null);
        }
    });
};

/**
 * 업종/종목 등락 정보 조회
 */
window.RebotCore.typeUpDown = function(typeChk, valueChk) {
        this.showBotMessage("업종/종목 등락 정보를 조회합니다...", "업종 | 종목 등락");
    
    const params = {
        type: "K" // KRX 기본값
    };
    
    this.ajaxCall("/ajax/getRiseUpSectorQuotations.json", params, (data) => {
        // API 성공 시 실제 데이터로 복잡한 구조 표시
        this.showComplexResult("업종 | 종목 등락", data);
    }, (error) => {
        // API 실패 시 샘플 데이터로 복잡한 구조 표시
        this.showComplexResult("업종 | 종목 등락", null);
    });
};

/**
 * 종목현재가 조회
 */
window.RebotCore.stockPrice = function(typeChk, valueChk) {
        this.showBotMessage("종목현재가를 조회합니다. 종목명을 입력해주세요.", "종목현재가");
    
    // 종목명 입력 대기 상태
    this.searchNo = "03";
};

/**
 * 글로벌증시 정보 조회
 */
window.RebotCore.globalMarket = function(typeChk, valueChk) {
        this.showBotMessage("글로벌증시 정보를 조회합니다...", "글로벌증시");
    
    const params = {
        region: valueChk || "us"
    };
    
    this.ajaxCall("/ajax/getWorldIndex.json", params, (data) => {
        // API 성공 시 실제 데이터로 복잡한 구조 표시
        this.showComplexResult("글로벌증시", data);
    }, (error) => {
        // API 실패 시 샘플 데이터로 복잡한 구조 표시
        this.showComplexResult("글로벌증시", null);
    });
};

/**
 * 유가/상품 정보 조회
 */
window.RebotCore.oilProduct = function(typeChk, valueChk) {
        this.showBotMessage("유가/상품 정보를 조회합니다...", "유가 및 상품");
    
    const params = {
        clsf: "21" // 유가 기본값
    };
    
    this.ajaxCall("/ajax/getGdsFtsMarketPrice.json", params, (data) => {
        // API 성공 시 실제 데이터로 복잡한 구조 표시
        this.showComplexResult("유가 및 상품", data);
    }, (error) => {
        // API 실패 시 샘플 데이터로 복잡한 구조 표시
        this.showComplexResult("유가 및 상품", null);
    });
};

/**
 * 금리/환율 정보 조회
 */
window.RebotCore.exchange = function(typeChk, valueChk) {
        this.showBotMessage("금리/환율 정보를 조회합니다...", "금리 및 환율");
    
    const params = {
        type: "rp" // 환율 기본값
    };
    
    this.ajaxCall("/ajax/getNowAndDtCrncyRPrcss.json", params, (data) => {
        // API 성공 시 실제 데이터로 복잡한 구조 표시
        this.showComplexResult("금리 및 환율", data);
    }, (error) => {
        // API 실패 시 샘플 데이터로 복잡한 구조 표시
        this.showComplexResult("금리 및 환율", null);
    });
};

/**
 * KB데일리 정보 조회
 */
window.RebotCore.kbDaily = function(typeChk, valueChk) {
        this.showBotMessage("KB데일리 정보를 조회합니다...", "KB 데일리");
    
    const params = {
        type: "first"
    };
    
    this.ajaxCall("/ajax/getHeadLine.json", params, (data) => {
        // API 성공 시 실제 데이터로 복잡한 구조 표시
        this.showComplexResult("KB 데일리", data);
    }, (error) => {
        // API 실패 시 샘플 데이터로 복잡한 구조 표시
        this.showComplexResult("KB 데일리", null);
    });
};

/**
 * 최신리포트 조회
 */
window.RebotCore.todayReport = function() {
        this.showBotMessage("최신리포트를 조회합니다...", "최신 리포트");
    
    const params = {
        pageSize: 5
    };
    
    this.ajaxCall("/ajax/getChatBotTodayReportList.json", params, (data) => {
        // API 성공 시 실제 데이터로 복잡한 구조 표시
        this.showComplexResult("최신 리포트", data);
    }, (error) => {
        // API 실패 시 샘플 데이터로 복잡한 구조 표시
        this.showComplexResult("최신 리포트", null);
    });
};

/**
 * 캘린더 정보 조회
 */
window.RebotCore.calendar = function(typeChk, valueChk) {
    const params = {
        date: new Date().toISOString().split('T')[0]
    };
    
    this.ajaxCall("/ajax/getCalendarView.json", params, (data) => {
        // API 성공 시 실제 데이터로 복잡한 구조 표시
        this.showComplexResult("캘린더", data);
    }, (error) => {
        // API 실패 시 샘플 데이터로 복잡한 구조 표시
        console.log("캘린더 API 실패, 샘플 데이터 사용:", error);
        this.showComplexResult("캘린더", null);
    });
};

/**
 * 애널리스트 정보 조회
 */
window.RebotCore.analyst = function(typeChk, valueChk) {
    const params = {
        type: "analyst"
    };
    
    this.ajaxCall("/ajax/getChatbotRecentReportList.json", params, (data) => {
        // API 성공 시 실제 데이터로 복잡한 구조 표시
        this.showComplexResult("애널리스트", data);
    }, (error) => {
        // API 실패 시 샘플 데이터로 복잡한 구조 표시
        this.showComplexResult("애널리스트", null);
    });
};

/**
 * 일반 검색
 */
window.RebotCore.generalSearch = function(searchTerm) {
    this.showBotMessage(`"${searchTerm}"에 대한 검색을 수행합니다...`);
    
    // 종목명 검색인지 키워드 검색인지 판단
    const params = {
        keyword: searchTerm,
        type: "keyword" // 기본값
    };
    
    this.ajaxCall("/ajax/keywordReportList.json", params, (data) => {
        this.showBotMessage(`🔍 "${searchTerm}" 검색 결과를 조회했습니다.`);
    });
};

/**
 * 봇 메시지 표시 (기본 텍스트 메시지 - 퍼블리싱된 구조 사용)
 */
window.RebotCore.showBotMessage = function(message, serviceName = null) {
            const chatArea = document.getElementById('main-chat-area');
    if (chatArea) {
        const botMessage = document.createElement('article');
        botMessage.className = 'prompt__wrapper__query';
        botMessage.setAttribute('data-id', '');
        
        // 서비스명이 있으면 해당 서비스명을, 없으면 기본 메시지를 표시
        const titleText = serviceName || 'KB증권 리봇';
        
        botMessage.innerHTML = `
            <div class="prompt__cont">
                <div class="prompt__src sr_only" data-role="">
                    query:
                </div>
                <div class="prompt__query_box">
                    <div class="prompt__txt_adjust">
                        <div class="prompt__query_title">${titleText}</div>
                        <div class="prompt__model_chosen">
                            rebot thinking
                            <img src="icons/gr_ic.svg" alt="">
                        </div>
                        <div class="prompt__txt">${message}</div>
                    </div>
                </div>
            </div>
        `;
        
        chatArea.appendChild(botMessage);
        chatArea.scrollTop = chatArea.scrollHeight;
    }
};

/**
 * 복잡한 결과 구조 표시 (퍼블리싱된 HTML 구조)
 */
window.RebotCore.showComplexResult = function(serviceType, data) {
    console.log("showComplexResult 호출:", serviceType, data);
    const chatArea = document.getElementById('main-chat-area');
    if (!chatArea) {
        console.log("chatArea를 찾을 수 없습니다");
        return;
    }

    const resultContainer = document.createElement('article');
    resultContainer.className = 'prompt__wrapper__query';
    resultContainer.setAttribute('data-id', '');
    
    // 서비스별 데이터 설정
    const resultData = this.getServiceData(serviceType, data);
    console.log("getServiceData 결과:", resultData);
    console.log("캘린더 데이터 존재 여부:", !!resultData.calendar);
    if (resultData.calendar) {
        console.log("캘린더 days 길이:", resultData.calendar.days.length);
    }
    
    resultContainer.innerHTML = `
        <div class="prompt__cont">
            <div class="prompt__src sr_only" data-role="">
                query:
            </div>
            <div class="prompt__query_box">
                <div class="prompt__txt_adjust">
                    <div class="prompt__query_title">
                        ${serviceType}
                    </div>
                    <div class="prompt__model_chosen">
                        rebot thinking
                        <img src="icons/gr_ic.svg" alt="">
                    </div>
                    <div class="prompt__txt">
                        ${resultData.content}
                    </div>

                    ${resultData.exlinks ? `
                    <div class="prompt__query__exlinks">
                        <button type="button" id="prompt-exlinks-box" class="prompt__exlinks" data-target="right-popup-links">
                            <div class="prompt__exlinks_txt1">출처</div>
                            <div class="exlinks__img__group">
                                <img src="icons/k__ic.svg" alt="출처 카카오" class="exlink__ic">
                                <img src="icons/g__ic.svg" alt="출처 유튜브" class="exlink__ic">
                                <img src="icons/n__ic.svg" alt="출처 네이버" class="exlink__ic">
                            </div>
                            <div class="prompt__exlinks_txt2">외의 사이트</div>
                        </button>
                    </div>
                    ` : ''}

                    ${resultData.showActionButtons !== false ? `
                    <div class="prompt__query__btn__group">
                        <button id="prompt-query-btn" class="prompt__query__btn">
                            <div class="prompt__query__btn_ic1"></div>
                        </button>
                        <button id="prompt-query-btn" class="prompt__query__btn">
                            <div class="prompt__query__btn_ic2"></div>
                        </button>
                        <button id="prompt-query-btn" class="prompt__query__btn">
                            <div class="prompt__query__btn_ic3"></div>
                        </button>
                        <button id="prompt-query-btn" class="prompt__query__btn">
                            <div class="prompt__query__btn_ic4"></div>
                        </button>
                        <button id="prompt-query-btn" class="prompt__query__btn">
                            <div class="prompt__query__btn_ic5"></div>
                        </button>
                        <button id="prompt-query-btn-fd" class="prompt__query__btn" data-target="prompt-btn-more">
                            <div class="prompt__query__btn_ic6"></div>
                        </button>
                        
                        <div id="prompt-btn-more" class="prompt__btn__more">
                            <ul class="prompt__btn__more_ul">
                                <li class="prompt__btn__more_li">피드백</li>
                                <li class="prompt__btn__more_li">다른 메뉴</li>
                            </ul>
                        </div>
                    </div>
                    ` : ''}

                    ${resultData.relatedButtons ? `
                    <div id="query-rl-btn" class="query__rl__btn">
                        ${resultData.relatedButtons.map(btn => `
                            <div class="query__rl__btn__wrapper">
                                <button type="button" id="query-rl-it" class="query__rl__it" data-role="">${btn}</button>
                            </div>
                        `).join('')}
                    </div>
                    ` : ''}

                    ${resultData.smallButtons ? `
                    <div id="query-rl-btn-sm" class="query__rl__btn__sm">
                        ${resultData.smallButtons.map(btn => `
                            <div class="query__rl__btn__wrapper__sm">
                                <button type="button" id="query-rl-it-sm" class="query__rl__it__sm" data-role="">${btn}</button>
                            </div>
                        `).join('')}
                    </div>
                    ` : ''}

                    ${resultData.cards ? resultData.cards.map(card => `
                        <div id="${card.id}-card-comp" class="${card.class}">
                            ${card.id === 'staff' ? `
                                <div class="staff__card__title__box">
                                    <p class="staff__card__title">${card.title}</p>
                                    <p class="staff__card__subtitle">${card.subtitle}</p>
                                </div>
                            ` : `
                                <p class="card__title">${card.title}</p>
                            `}
                            <div id="card-box" class="${card.boxClass}">
                                ${card.items ? card.items.map(item => `
                                    <div class="${card.wrapperClass}">
                                        <div class="${card.itemClass}" data-id="${item.id}">
                                            <div class="${card.itemsClass}">
                                                <div class="${card.itemBoxClass}">
                                                    ${item.content.includes('staff__card__item__wrapper_c') ? 
                                                        item.content : 
                                                        `<div class="${card.itemWrapperClass}">${item.content}</div>`
                                                    }
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                `).join('') : ''}
                            </div>
                            ${card.id === 'li' ? `
                                <a href="/" target="_blank" id="cal-more-btn" class="cal__more__btn">
                                    페이지로 이동
                                </a>
                            ` : ''}
                        </div>
                    `).join('') : ''}

                    ${resultData.calendar ? `
                    <div class="calander__v calander_wd">
                        <p class="calander__v__title">캘린더</p>
                        <p class="calander__v__subtitle">주요 일정을 정리해서 보여줍니다.</p>
                        <div class="calander__wrapper">
                            <table id="prompt-calander" class="prompt__calander">
                                <thead>
                                    <tr>
                                        <th class="tg-0pky" colspan="7" data-id="">
                                            <div class="cal__th__wrapper">
                                                <button type="button" id="cal-mon-prev" class="cal__mon__prev"><img src="icons/arrow_l_ic.svg" alt="" class="cal__th__bf"></button>
                                                <span class="cal__th__title">2025년 8월</span>
                                                <button type="button" id="cal-mon-next" class="cal__mon__next"><img src="icons/arrow_r_ic.svg" alt="" class="cal__th__af"></button>
                                            </div>
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${resultData.calendar.days.map(day => `
                                        <tr>
                                            ${day.map(cell => `
                                                <td class="tg-0lax">
                                                    <div class="cal__box">
                                                        <div class="cal__nb__wrapper">
                                                            <div id="cal-nb-date" class="cal__nb__date" data-status-current="${cell.status}">
                                                                <span id="cal-nb-date-txt" class="cal__nb__date__txt">${cell.date}</span>
                                                            </div>
                                                            <div id="cal-nb-day" class="cal__nb__day">${cell.day}</div>
                                                        </div>
                                                        <div id="cal__schedule__wrapper" class="cal__schedule__wrapper">
                                                            <ul class="cal__sc__ul">
                                                                ${cell.schedules ? cell.schedules.map(schedule => `
                                                                    <li id="cal-sc-it" class="cal__sc__it" data-type="${schedule.type}">${schedule.text}</li>
                                                                `).join('') : ''}
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </td>
                                            `).join('')}
                                        </tr>
                                    `).join('')}
                                </tbody>
                            </table>
                            <a href="/" target="_blank" id="cal-more-btn" class="cal__more__btn">
                                캘린더 페이지로 이동
                            </a>
                        </div>
                    </div>
                    ` : ''}
                    
                    <div class="sc__btn__wrapper">
                        <button type="button" id="sc-btn" class="sc__btn"><div class="sc__dr__ic"></div></button>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    console.log("생성된 HTML:", resultContainer.innerHTML.substring(0, 500) + "...");
    chatArea.appendChild(resultContainer);
    chatArea.scrollTop = chatArea.scrollHeight;
    
    // 새로 추가된 요소들에 이벤트 리스너 바인딩
    this.bindComplexResultEvents(resultContainer);
};

/**
 * 서비스별 데이터 생성 (퍼블리싱된 HTML 구조에 맞게)
 */
window.RebotCore.getServiceData = function(serviceType, data) {
    const baseData = {
        title: serviceType,
        content: `${serviceType} 정보를 조회했습니다.`,
        exlinks: true,
        relatedButtons: [
            "버튼앰",
            "버튼앰", 
            "버튼앰",
            "버튼앰",
            "버튼앰",
            "버튼앰"
        ],
        smallButtons: [
            "버튼앰",
            "버튼앰", 
            "버튼앰",
            "버튼앰",
            "버튼앰",
            "버튼앰"
        ],
        cards: [],
        calendar: null
    };

    switch(serviceType) {
        case "주식시장":
            baseData.content = `중동 긴장 고조가 한국 시장에 미치는 영향은 주로 에너지 가격 변동, 수출입 불확실성, 그리고 금융시장 변동성으로 나타나고 있습니다.
<br>아래는 주요 동향과 영향을 정리한 내용입니다:
<hr class="prompt__linestyle">
금융시장 동향
<ul class="prompt__txt_ul">
    <li class="prompt__txt_li">환율 변동: 원/달러 환율은 강달러 기조와 중동 불확실성으로 인해 상승 압력을 받았으나,한국은행의 외환시장 안정화 조치로 큰 혼란은 억제되고 있습니다.</li>
    <li class="prompt__txt_li">환율 변동: 원/달러 환율은 강달러 기조와 중동 불확실성으로 인해 상승 압력을 받았으나,한국은행의 외환시장 안정화 조치로 큰 혼란은 억제되고 있습니다.</li>
    <li class="prompt__txt_li">환율 변동: 원/달러 환율은 강달러 기조와 중동 불확실성으로 인해 상승 압력을 받았으나,한국은행의 외환시장 안정화 조치로 큰 혼란은 억제되고 있습니다.</li>
</ul>`;
            
            baseData.cards = [
                {
                    id: "query",
                    class: "staff__card__comp",
                    title: "관련된 질문",
                    boxClass: "query__card__box",
                    wrapperClass: "query__card__box__wrapper",
                    itemClass: "query__card__wrapper",
                    itemsClass: "query__card__items",
                    itemBoxClass: "query__card__item__box",
                    itemWrapperClass: "query__card__item__wrapper",
                    items: [
                        {
                            id: 1,
                            content: `
                                <div class="query__card__title__wrapper">
                                    <p id="query-card-title" class="query__card__title" data-id="" data-name="">현재 외국인 매수 동향이 궁금해요</p>
                                </div>
                                <div class="query__card__subtitle__wrapper">
                                    <p id="card-item-kp" class="query__card__subtitle">코스피&nbsp;-&nbsp;외국인 0억</p>
                                    <p id="card-item-kd" class="query__card__subtitle">코스닥&nbsp;-&nbsp;외국인 0억</p>
                                </div>
                                <div class="query__card__inner__box">
                                    <div class="query__card__indice__box">
                                        <p id="card-chart-index" class="card__chart__index">0000.00</p>
                                        <div id="card-chart-trend" class="card__chart__trend"><img src="/icons/index_up.svg" alt="인덱스 오름" id="chart-trend-ic" class="chart__trend__ic"><span id="chart-trend-indice" class="chart__trend__indice">100.00</span></div>
                                        <p id="card-chart-pc" class="card__chart__pc">100.00%</p>
                                    </div>
                                    <a href="/" id="news-more-btn" class="card__more__btn card__btn__flex">자세히 보기</a>
                                </div>
                            `
                        },
                        {
                            id: 2,
                            content: `
                                <div class="query__card__title__wrapper">
                                    <p id="query-card-title" class="query__card__title" data-id="" data-name="">현재 외국인 매수 동향이 궁금해요</p>
                                </div>
                                <div class="query__card__subtitle__wrapper">
                                    <p id="card-item-kp" class="query__card__subtitle">코스피&nbsp;-&nbsp;외국인 0억</p>
                                    <p id="card-item-kd" class="query__card__subtitle">코스닥&nbsp;-&nbsp;외국인 0억</p>
                                </div>
                                <div class="query__card__inner__box">
                                    <div class="query__card__indice__box">
                                        <p id="card-chart-index" class="card__chart__index">0000.00</p>
                                        <div id="card-chart-trend" class="card__chart__trend"><img src="/icons/index_up.svg" alt="인덱스 오름" id="chart-trend-ic" class="chart__trend__ic"><span id="chart-trend-indice" class="chart__trend__indice">100.00</span></div>
                                        <p id="card-chart-pc" class="card__chart__pc">100.00%</p>
                                    </div>
                                    <a href="/" id="news-more-btn" class="card__more__btn card__btn__flex">자세히 보기</a>
                                </div>
                            `
                        },
                        {
                            id: 3,
                            content: `
                                <div class="query__card__title__wrapper">
                                    <p id="query-card-title" class="query__card__title" data-id="" data-name="">현재 외국인 매수 동향이 궁금해요</p>
                                </div>
                                <div class="query__card__subtitle__wrapper">
                                    <p id="card-item-kp" class="query__card__subtitle">코스피&nbsp;-&nbsp;외국인 0억</p>
                                    <p id="card-item-kd" class="query__card__subtitle">코스닥&nbsp;-&nbsp;외국인 0억</p>
                                </div>
                                <div class="query__card__inner__box">
                                    <div class="query__card__indice__box">
                                        <p id="card-chart-index" class="card__chart__index">0000.00</p>
                                        <div id="card-chart-trend" class="card__chart__trend"><img src="/icons/index_up.svg" alt="인덱스 오름" id="chart-trend-ic" class="chart__trend__ic"><span id="chart-trend-indice" class="chart__trend__indice">100.00</span></div>
                                        <p id="card-chart-pc" class="card__chart__pc">100.00%</p>
                                    </div>
                                    <a href="/" id="news-more-btn" class="card__more__btn card__btn__flex">자세히 보기</a>
                                </div>
                            `
                        }
                    ]
                },
                {
                    id: "report",
                    class: "report__card__comp",
                    title: "최신 리포트",
                    boxClass: "report__card__box",
                    wrapperClass: "report__card__box__wrapper",
                    itemClass: "report__card__wrapper",
                    itemsClass: "report__card__items",
                    itemBoxClass: "report__card__item__box",
                    itemWrapperClass: "report__card__item__wrapper",
                    items: [
                        {
                            id: 1,
                            content: `
                                <div id="report-name-chip" class="report__name__chip">채권/크레딧</div>
                                <div class="report__card__title__wrapper">
                                    <p id="report-card-title" class="report__card__title" data-id="" data-name="">KB Bond</p>
                                </div>
                                <div class="report__card__subtitle__wrapper">
                                    <p id="report-card-subtitle" class="report__card__subtitle" data-id="" data-name="">예정되어 있던 관세 서한과 유예기간 연장</p>
                                </div>
                                <div class="report__card__inner__box">
                                    <div class="report__card__textbox">
                                        <div class="report__card__info_row">by&nbsp;<span id="report-card-info" class="report__card__info">Author</span></div>
                                        <p id="report-card-timestamp" class="report__card__timestamp">2025-07-08</p>
                                    </div>
                                    <a href="/" id="report-more-btn" class="card__more__btn">자세히 보기</a>
                                </div>
                            `
                        },
                        {
                            id: 2,
                            content: `
                                <div id="report-name-chip" class="report__name__chip">모닝코멘트</div>
                                <div class="report__card__title__wrapper">
                                    <p id="report-card-subtitle" class="report__card__title" data-id="" data-name="">KB Bond</p>
                                </div>
                                <div class="report__card__subtitle__wrapper">
                                    <p id="report-card-subtitle" class="report__card__subtitle" data-id="" data-name="">예정되어 있던 관세 서한과 유예기간 연장</p>
                                </div>
                                <div class="report__card__inner__box">
                                    <div class="report__card__textbox">
                                        <div class="report__card__info_row">by&nbsp;<span id="report-card-info" class="report__card__info">Author</span></div>
                                        <p id="report-card-timestamp" class="report__card__timestamp">2025-07-08</p>
                                    </div>
                                    <a href="/" id="report-more-btn" class="card__more__btn">자세히 보기</a>
                                </div>
                            `
                        },
                        {
                            id: 3,
                            content: `
                                <div id="report-name-chip" class="report__name__chip">데일리</div>
                                <div class="report__card__title__wrapper">
                                    <p id="report-card-subtitle" class="report__card__title" data-id="" data-name="">뉴욕증시 3대 지수 최고치 마감</p>
                                </div>
                                <div class="report__card__subtitle__wrapper">
                                    <p id="report-card-subtitle" class="report__card__subtitle" data-id="" data-name="">예정되어 있던 관세 서한과 유예기간 연장</p>
                                </div>
                                <div class="report__card__inner__box">
                                    <div class="report__card__textbox">
                                        <div class="report__card__info_row">by&nbsp;<span id="report-card-info" class="report__card__info">Author</span></div>
                                        <p id="report-card-timestamp" class="report__card__timestamp">2025-07-08</p>
                                    </div>
                                    <a href="/" id="report-more-btn" class="card__more__btn">자세히 보기</a>
                                </div>
                            `
                        }
                    ]
                },
                {
                    id: "news",
                    class: "news__card__comp",
                    title: "마감 기사",
                    boxClass: "news__card__box",
                    wrapperClass: "news__card__box__wrapper",
                    itemClass: "news__card__wrapper",
                    itemsClass: "news__card__items",
                    itemBoxClass: "news__card__item__box",
                    itemWrapperClass: "news__card__item__wrapper",
                    items: [
                        {
                            id: 1,
                            content: `
                                <div class="card__img__wrapper"></div>
                                <div class="news__card__item__wrapper">
                                    <div class="news__card__title__wrapper">
                                        <p id="news-card-subtitle" class="news__card__title" data-id="" data-name="">뉴욕증시 3대 지수 최고치 마감</p>
                                    </div>
                                    <div class="news__card__inner__box">
                                        <div class="news__card__textbox">
                                            <div class="news__card__info_row">by&nbsp;<span id="report-card-info" class="report__card__info">source</span></div>
                                            <p id="news-card-timestamp" class="report__card__timestamp">2025-07-08</p>
                                        </div>
                                        <a href="/" id="news-more-btn" class="card__more__btn">자세히 보기</a>
                                    </div>
                                </div>
                            `
                        },
                        {
                            id: 2,
                            content: `
                                <div class="card__img__wrapper"></div>
                                <div class="news__card__item__wrapper">
                                    <div class="news__card__title__wrapper">
                                        <p id="news-card-subtitle" class="news__card__title" data-id="" data-name="">뉴욕증시 3대 지수 최고치 마감</p>
                                    </div>
                                    <div class="news__card__inner__box">
                                        <div class="news__card__textbox">
                                            <div class="news__card__info_row">by&nbsp;<span id="report-card-info" class="report__card__info">source</span></div>
                                            <p id="news-card-timestamp" class="report__card__timestamp">2025-07-08</p>
                                        </div>
                                        <a href="/" id="news-more-btn" class="card__more__btn">자세히 보기</a>
                                    </div>
                                </div>
                            `
                        },
                        {
                            id: 3,
                            content: `
                                <div class="card__img__wrapper"></div>
                                <div class="news__card__item__wrapper">
                                    <div class="news__card__title__wrapper">
                                        <p id="news-card-subtitle" class="news__card__title" data-id="" data-name="">뉴욕증시 3대 지수 최고치 마감</p>
                                    </div>
                                    <div class="news__card__inner__box">
                                        <div class="news__card__textbox">
                                            <div class="news__card__info_row">by&nbsp;<span id="report-card-info" class="report__card__info">source</span></div>
                                            <p id="news-card-timestamp" class="report__card__timestamp">2025-07-08</p>
                                        </div>
                                        <a href="/" id="news-more-btn" class="card__more__btn">자세히 보기</a>
                                    </div>
                                </div>
                            `
                        }
                    ]
                },
                {
                    id: "staff",
                    class: "staff__card__comp",
                    title: "애널리스트 선택",
                    boxClass: "staff__card__box",
                    wrapperClass: "staff__card__box__wrapper",
                    itemClass: "staff__card__wrapper",
                    itemsClass: "staff__card__items",
                    itemBoxClass: "staff__card__item__box",
                    itemWrapperClass: "staff__card__item__wrapper",
                    items: [
                        {
                            id: 1,
                            content: `
                                <div class="staff__card__title__wrapper">
                                    <p id="staff-card-title" class="staff__card__inner__title" data-id="" data-name="">
                                        <span id="staff-name">김이박</span>
                                    </p>
                                </div>
                                <div class="staff__card__inner__box">
                                    <div class="staff__card__textbox">
                                        <p id="staff-card-dep" class="staff__card__timestamp">리서치팀 해외부서</p>
                                    </div>
                                    <a href="/" id="news-more-btn" class="card__more__btn card__btn__flex">자세히 보기</a>
                                </div>
                            `
                        },
                        {
                            id: 2,
                            content: `
                                <div class="staff__card__title__wrapper">
                                    <p id="staff-card-title" class="staff__card__inner__title" data-id="" data-name="">
                                        <span id="staff-name">김이박</span>
                                    </p>
                                </div>
                                <div class="staff__card__inner__box">
                                    <div class="staff__card__textbox">
                                        <p id="staff-card-dep" class="staff__card__timestamp">리서치팀 해외부서</p>
                                    </div>
                                    <a href="/" id="news-more-btn" class="card__more__btn card__btn__flex">자세히 보기</a>
                                </div>
                            `
                        },
                        {
                            id: 3,
                            content: `
                                <div class="staff__card__title__wrapper">
                                    <p id="staff-card-title" class="staff__card__inner__title" data-id="" data-name="">
                                        <span id="staff-name">김이박</span>
                                    </p>
                                </div>
                                <div class="staff__card__inner__box">
                                    <div class="staff__card__textbox">
                                        <p id="staff-card-dep" class="staff__card__timestamp">리서치팀 해외부서</p>
                                    </div>
                                    <a href="/" id="news-more-btn" class="card__more__btn card__btn__flex">자세히 보기</a>
                                </div>
                            `
                        },
                        {
                            id: 4,
                            content: `
                                <div class="staff__card__title__wrapper">
                                    <p id="staff-card-title" class="staff__card__inner__title" data-id="" data-name="">
                                        <span id="staff-name">김이박</span>
                                    </p>
                                </div>
                                <div class="staff__card__inner__box">
                                    <div class="staff__card__textbox">
                                        <p id="staff-card-dep" class="staff__card__timestamp">리서치팀 해외부서</p>
                                    </div>
                                    <a href="/" id="news-more-btn" class="card__more__btn card__btn__flex">자세히 보기</a>
                                </div>
                            `
                        },
                        {
                            id: 5,
                            content: `
                                <div class="staff__card__item__wrapper_c">
                                    <div class="staff__card__title__wrapper_c">
                                        <div class="staff__card__img__wrapper"></div>
                                        <div class="staff__card__info__wrapper_c">
                                            <p id="staff-card-title" class="staff__card__inner__title" data-id="" data-name=""></p>
                                            <div class="staff__card__textbox">
                                                <p id="staff-card-dep" class="staff__card__timestamp_c">리서치팀 해외부서</p>
                                            </div>
                                            <span id="staff-name">김이박</span>
                                        </div>
                                    </div>
                                    <div class="staff__card__inner__box">
                                        <a href="/" id="news-more-btn" class="card__more__btn card__btn__flex">자세히 보기</a>
                                    </div>
                                </div>
                            `
                        },
                        {
                            id: 6,
                            content: `
                                <div class="staff__card__item__wrapper_c">
                                    <div class="staff__card__title__wrapper_c">
                                        <div class="staff__card__img__wrapper"></div>
                                        <div class="staff__card__info__wrapper_c">
                                            <p id="staff-card-title" class="staff__card__inner__title" data-id="" data-name=""></p>
                                            <div class="staff__card__textbox">
                                                <p id="staff-card-dep" class="staff__card__timestamp_c">리서치팀 해외부서</p>
                                            </div>
                                            <span id="staff-name">김이박</span>
                                        </div>
                                    </div>
                                    <div class="staff__card__inner__box">
                                        <a href="/" id="news-more-btn" class="card__more__btn card__btn__flex">자세히 보기</a>
                                    </div>
                                </div>
                            `
                        },
                        {
                            id: 7,
                            content: `
                                <div class="staff__card__item__wrapper_c">
                                    <div class="staff__card__title__wrapper_c">
                                        <div class="staff__card__img__wrapper"></div>
                                        <div class="staff__card__info__wrapper_c">
                                            <p id="staff-card-title" class="staff__card__inner__title" data-id="" data-name=""></p>
                                            <div class="staff__card__textbox">
                                                <p id="staff-card-dep" class="staff__card__timestamp_c">리서치팀 해외부서</p>
                                            </div>
                                            <span id="staff-name">김이박</span>
                                        </div>
                                    </div>
                                    <div class="staff__card__inner__box">
                                        <a href="/" id="news-more-btn" class="card__more__btn card__btn__flex">자세히 보기</a>
                                    </div>
                                </div>
                            `
                        },
                        {
                            id: 8,
                            content: `
                                <div class="staff__card__item__wrapper_c">
                                    <div class="staff__card__title__wrapper_c">
                                        <div class="staff__card__img__wrapper"></div>
                                        <div class="staff__card__info__wrapper_c">
                                            <p id="staff-card-title" class="staff__card__inner__title" data-id="" data-name=""></p>
                                            <div class="staff__card__textbox">
                                                <p id="staff-card-dep" class="staff__card__timestamp_c">리서치팀 해외부서</p>
                                            </div>
                                            <span id="staff-name">김이박</span>
                                        </div>
                                    </div>
                                    <div class="staff__card__inner__box">
                                        <a href="/" id="news-more-btn" class="card__more__btn card__btn__flex">자세히 보기</a>
                                    </div>
                                </div>
                            `
                        }
                    ]
                },
                {
                    id: "cal",
                    class: "cal__card__comp",
                    title: "캘린더",
                    boxClass: "cal__card__box",
                    wrapperClass: "cal__card__box__wrapper",
                    itemClass: "cal__card__wrapper",
                    itemsClass: "cal__card__items",
                    itemBoxClass: "cal__card__item__box",
                    itemWrapperClass: "cal__card__item__wrapper",
                    items: [
                        {
                            id: 1,
                            content: `
                                <div class="cal__card__title__wrapper">
                                    <p id="cal-card-title" class="cal__card__inner__title" data-id="" data-name="">
                                        <span class="cal__nb__date__mo" data-status-current="today">1</span>
                                        <span id="cal__nb__day" class="cal__nb__day__mo">MON</span>
                                    </p>
                                </div>
                                <div class="cal__card__inner__box">
                                    <div class="cal__card__textbox">
                                        <div class="cal__sc__box">
                                            <p class="cal__sc__it__mo__title">한국 시장</p>
                                            <p class="cal__sc__it__mo" data-type="ksp">일정</p>
                                            <p class="cal__sc__it__mo" data-type="ksp">일정</p>
                                            <p class="cal__sc__it__mo" data-type="ksp">일정</p>
                                            <p class="cal__sc__it__mo" data-type="ksp">일정</p>
                                            <p class="cal__sc__it__mo" data-type="ksp">일정</p>
                                            <p class="cal__sc__it__mo" data-type="ksp">일정</p>
                                            <p class="cal__sc__it__mo" data-type="ksp">일정</p>
                                            <p class="cal__sc__it__mo__title cal__sc__it__adjust">미국 시장</p>
                                            <p class="cal__sc__it__mo" data-type="nsd">일정</p>
                                            <p class="cal__sc__it__mo" data-type="nsd">일정</p>
                                            <p class="cal__sc__it__mo" data-type="nsd">일정</p>
                                            <p class="cal__sc__it__mo" data-type="nsd">일정</p>
                                            <p class="cal__sc__it__mo" data-type="nsd">일정</p>
                                        </div>
                                    </div>
                                    <button type="button" id="cal-li-more-btn" class="cal__card__more__btn card__btn__flex keep-style">더 보기</button>
                                </div>
                            `
                        },
                        {
                            id: 2,
                            content: `
                                <div class="cal__card__title__wrapper">
                                    <p id="cal-card-title" class="cal__card__inner__title" data-id="" data-name="">
                                        <span class="cal__nb__date__mo" data-status-current="next-day">2</span>
                                        <span id="cal__nb__day" class="cal__nb__day__mo">TUE</span>
                                    </p>
                                </div>
                                <div class="cal__card__inner__box">
                                    <div class="cal__card__textbox">
                                        <div class="cal__sc__box">
                                            <p class="cal__sc__it__mo__title">한국 시장</p>
                                            <p class="cal__sc__it__mo" data-type="ksp">일정</p>
                                            <p class="cal__sc__it__mo" data-type="ksp">일정</p>
                                            <p class="cal__sc__it__mo" data-type="ksp">일정</p>
                                            <p class="cal__sc__it__mo" data-type="ksp">일정</p>
                                            <p class="cal__sc__it__mo" data-type="ksp">일정</p>
                                            <p class="cal__sc__it__mo" data-type="ksp">일정</p>
                                            <p class="cal__sc__it__mo" data-type="ksp">일정</p>
                                            <p class="cal__sc__it__mo__title cal__sc__it__adjust">미국 시장</p>
                                            <p class="cal__sc__it__mo" data-type="nsd">일정</p>
                                            <p class="cal__sc__it__mo" data-type="nsd">일정</p>
                                            <p class="cal__sc__it__mo" data-type="nsd">일정</p>
                                            <p class="cal__sc__it__mo" data-type="nsd">일정</p>
                                            <p class="cal__sc__it__mo" data-type="nsd">일정</p>
                                        </div>
                                    </div>
                                    <button type="button" id="cal-li-more-btn" class="cal__card__more__btn card__btn__flex keep-style">더 보기</button>
                                </div>
                            `
                        },
                        {
                            id: 3,
                            content: `
                                <div class="cal__card__title__wrapper">
                                    <p id="cal-card-title" class="cal__card__inner__title" data-id="" data-name="">
                                        <span class="cal__nb__date__mo" data-status-current="next-day">3</span>
                                        <span id="cal__nb__day" class="cal__nb__day__mo">WED</span>
                                    </p>
                                </div>
                                <div class="cal__card__inner__box">
                                    <div class="cal__card__textbox">
                                        <div class="cal__sc__box">
                                            <p class="cal__sc__it__mo__title">한국 시장</p>
                                            <p class="cal__sc__it__mo" data-type="ksp">일정</p>
                                            <p class="cal__sc__it__mo" data-type="ksp">일정</p>
                                            <p class="cal__sc__it__mo" data-type="ksp">일정</p>
                                            <p class="cal__sc__it__mo" data-type="ksp">일정</p>
                                            <p class="cal__sc__it__mo" data-type="ksp">일정</p>
                                            <p class="cal__sc__it__mo" data-type="ksp">일정</p>
                                            <p class="cal__sc__it__mo" data-type="ksp">일정</p>
                                            <p class="cal__sc__it__mo__title cal__sc__it__adjust">미국 시장</p>
                                            <p class="cal__sc__it__mo" data-type="nsd">일정</p>
                                            <p class="cal__sc__it__mo" data-type="nsd">일정</p>
                                            <p class="cal__sc__it__mo" data-type="nsd">일정</p>
                                            <p class="cal__sc__it__mo" data-type="nsd">일정</p>
                                            <p class="cal__sc__it__mo" data-type="nsd">일정</p>
                                        </div>
                                    </div>
                                    <button type="button" id="cal-li-more-btn" class="cal__card__more__btn card__btn__flex keep-style">더 보기</button>
                                </div>
                            `
                        }
                    ]
                },
                {
                    id: "li",
                    class: "li__card__comp",
                    title: "원자재 가격",
                    boxClass: "li__card__box",
                    wrapperClass: "li__card__box__wrapper",
                    itemClass: "li__card__wrapper",
                    itemsClass: "li__card__items",
                    itemBoxClass: "li__card__item__box",
                    itemWrapperClass: "li__card__item__wrapper",
                    items: [
                        {
                            id: 0,
                            content: `
                                <div class="li__card__title__box">
                                    <p id="li-card-title" class="li__card__title" data-p-name="">원자재 가격</p>
                                    <p class="li__card__subtitle"><span id="li-card-title" data-p-name="">원자재 가격</span>입니다.</p>
                                </div>
                            `
                        },
                        {
                            id: 1,
                            content: `
                                <div class="li__card__title__wrapper">
                                    <p id="li-card-title" class="li__card__inner__title" data-id="" data-name="">
                                        <span class="" data-status-current="">today</span>
                                        <span id="li__nb" class="li__nb__mo">원자재 가격</span>
                                    </p>
                                    <a href="/" id="" class="li__card__inner__link">시황 확인</a>
                                </div>
                                <div class="li__card__title__wrapper">
                                    <p id="li-card-title" class="li__card__inner__title" data-id="" data-name="">
                                        <span class="" data-status-current="">today</span>
                                        <span id="li__nb" class="li__nb__mo">원자재 가격</span>
                                    </p>
                                    <a href="/" id="" class="li__card__inner__link">시황 확인</a>
                                </div>
                            `
                        }
                    ]
                }
            ];
            break;
            
        case "캘린더":
            baseData.content = "캘린더 정보를 조회했습니다.";
            baseData.exlinks = false;
            baseData.showActionButtons = false;
            baseData.relatedButtons = [];
            baseData.smallButtons = [];
            baseData.calendar = {
                days: [
                    [
                        { date: "1", day: "MON", status: "today", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "2", day: "TUE", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "3", day: "WED", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "4", day: "THU", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "5", day: "FRI", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "6", day: "SAT", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "7", day: "SUN", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] }
                    ],
                    [
                        { date: "1", day: "MON", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "2", day: "TUE", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "3", day: "WED", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "4", day: "THU", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "5", day: "FRI", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "6", day: "SAT", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "7", day: "SUN", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] }
                    ],
                    [
                        { date: "1", day: "MON", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "2", day: "TUE", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "3", day: "WED", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "4", day: "THU", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "5", day: "FRI", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "6", day: "SAT", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "7", day: "SUN", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] }
                    ],
                    [
                        { date: "1", day: "MON", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "2", day: "TUE", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "3", day: "WED", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "4", day: "THU", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "5", day: "FRI", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "6", day: "SAT", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "7", day: "SUN", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] }
                    ]
                ]
            };
            break;
            
        case "최신 리포트":
            baseData.content = "최신 리포트를 조회했습니다.";
            baseData.cards = [
                {
                    id: "report",
                    class: "report__card__comp",
                    title: "최신 리포트",
                    boxClass: "report__card__box",
                    wrapperClass: "report__card__box__wrapper",
                    itemClass: "report__card__wrapper",
                    itemsClass: "report__card__items",
                    itemBoxClass: "report__card__item__box",
                    itemWrapperClass: "report__card__item__wrapper",
                    items: [
                        {
                            id: 1,
                            content: `
                                <div id="report-name-chip" class="report__name__chip">채권/크레딧</div>
                                <div class="report__card__title__wrapper">
                                    <p id="report-card-title" class="report__card__title" data-id="" data-name="">KB Bond</p>
                                </div>
                                <div class="report__card__subtitle__wrapper">
                                    <p id="report-card-subtitle" class="report__card__subtitle" data-id="" data-name="">예정되어 있던 관세 서한과 유예기간 연장</p>
                                </div>
                                <div class="report__card__inner__box">
                                    <div class="report__card__textbox">
                                        <div class="report__card__info_row">by&nbsp;<span id="report-card-info" class="report__card__info">Author</span></div>
                                        <p id="report-card-timestamp" class="report__card__timestamp">2025-07-08</p>
                                    </div>
                                    <a href="/" id="report-more-btn" class="card__more__btn">자세히 보기</a>
                                </div>
                            `
                        },
                        {
                            id: 2,
                            content: `
                                <div id="report-name-chip" class="report__name__chip">모닝코멘트</div>
                                <div class="report__card__title__wrapper">
                                    <p id="report-card-subtitle" class="report__card__title" data-id="" data-name="">KB Bond</p>
                                </div>
                                <div class="report__card__subtitle__wrapper">
                                    <p id="report-card-subtitle" class="report__card__subtitle" data-id="" data-name="">예정되어 있던 관세 서한과 유예기간 연장</p>
                                </div>
                                <div class="report__card__inner__box">
                                    <div class="report__card__textbox">
                                        <div class="report__card__info_row">by&nbsp;<span id="report-card-info" class="report__card__info">Author</span></div>
                                        <p id="report-card-timestamp" class="report__card__timestamp">2025-07-08</p>
                                    </div>
                                    <a href="/" id="report-more-btn" class="card__more__btn">자세히 보기</a>
                                </div>
                            `
                        },
                        {
                            id: 3,
                            content: `
                                <div id="report-name-chip" class="report__name__chip">데일리</div>
                                <div class="report__card__title__wrapper">
                                    <p id="report-card-subtitle" class="report__card__title" data-id="" data-name="">뉴욕증시 3대 지수 최고치 마감</p>
                                </div>
                                <div class="report__card__subtitle__wrapper">
                                    <p id="report-card-subtitle" class="report__card__subtitle" data-id="" data-name="">예정되어 있던 관세 서한과 유예기간 연장</p>
                                </div>
                                <div class="report__card__inner__box">
                                    <div class="report__card__textbox">
                                        <div class="report__card__info_row">by&nbsp;<span id="report-card-info" class="report__card__info">Author</span></div>
                                        <p id="report-card-timestamp" class="report__card__timestamp">2025-07-08</p>
                                    </div>
                                    <a href="/" id="report-more-btn" class="card__more__btn">자세히 보기</a>
                                </div>
                            `
                        }
                    ]
                }
            ];
            break;
            
        case "애널리스트":
            baseData.content = "애널리스트 정보를 조회했습니다.";
            baseData.exlinks = false;
            baseData.showActionButtons = false;
            baseData.relatedButtons = [];
            baseData.smallButtons = [];
            baseData.cards = [
                {
                    id: "staff",
                    class: "staff__card__comp",
                    title: "애널리스트 선택",
                    subtitle: "부서명",
                    boxClass: "staff__card__box",
                    wrapperClass: "staff__card__box__wrapper",
                    itemClass: "staff__card__wrapper",
                    itemsClass: "staff__card__items",
                    itemBoxClass: "staff__card__item__box",
                    itemWrapperClass: "staff__card__item__wrapper",
                    items: [
                        {
                            id: 1,
                            content: `
                                <div class="staff__card__title__wrapper">
                                    <p id="staff-card-title" class="staff__card__inner__title" data-id="" data-name="">
                                        <span id="staff-name">김철수</span>
                                    </p>
                                </div>
                                <div class="staff__card__inner__box">
                                    <div class="staff__card__textbox">
                                        <p id="staff-card-dep" class="staff__card__timestamp">리서치팀 해외부서</p>
                                    </div>
                                    <a href="/" id="news-more-btn" class="card__more__btn card__btn__flex">자세히 보기</a>
                                </div>
                            `
                        },
                        {
                            id: 2,
                            content: `
                                <div class="staff__card__title__wrapper">
                                    <p id="staff-card-title" class="staff__card__inner__title" data-id="" data-name="">
                                        <span id="staff-name">이영희</span>
                                    </p>
                                </div>
                                <div class="staff__card__inner__box">
                                    <div class="staff__card__textbox">
                                        <p id="staff-card-dep" class="staff__card__timestamp">리서치팀 국내부서</p>
                                    </div>
                                    <a href="/" id="news-more-btn" class="card__more__btn card__btn__flex">자세히 보기</a>
                                </div>
                            `
                        },
                        {
                            id: 3,
                            content: `
                                <div class="staff__card__title__wrapper">
                                    <p id="staff-card-title" class="staff__card__inner__title" data-id="" data-name="">
                                        <span id="staff-name">박민수</span>
                                    </p>
                                </div>
                                <div class="staff__card__inner__box">
                                    <div class="staff__card__textbox">
                                        <p id="staff-card-dep" class="staff__card__timestamp">투자전략팀</p>
                                    </div>
                                    <a href="/" id="news-more-btn" class="card__more__btn card__btn__flex">자세히 보기</a>
                                </div>
                            `
                        },
                        {
                            id: 4,
                            content: `
                                <div class="staff__card__title__wrapper">
                                    <p id="staff-card-title" class="staff__card__inner__title" data-id="" data-name="">
                                        <span id="staff-name">정수진</span>
                                    </p>
                                </div>
                                <div class="staff__card__inner__box">
                                    <div class="staff__card__textbox">
                                        <p id="staff-card-dep" class="staff__card__timestamp">경제분석팀</p>
                                    </div>
                                    <a href="/" id="news-more-btn" class="card__more__btn card__btn__flex">자세히 보기</a>
                                </div>
                            `
                        },
                        {
                            id: 5,
                            content: `
                                <div class="staff__card__item__wrapper_c">
                                    <div class="staff__card__title__wrapper_c">
                                        <div class="staff__card__img__wrapper"></div>
                                        <div class="staff__card__info__wrapper_c">
                                            <p id="staff-card-title" class="staff__card__inner__title" data-id="" data-name=""></p>
                                            <div class="staff__card__textbox">
                                                <p id="staff-card-dep" class="staff__card__timestamp_c">리서치팀 해외부서</p>
                                            </div>
                                            <span id="staff-name">최동현</span>
                                        </div>
                                    </div>
                                    <div class="staff__card__inner__box">
                                        <a href="/" id="news-more-btn" class="card__more__btn card__btn__flex">자세히 보기</a>
                                    </div>
                                </div>
                            `
                        },
                        {
                            id: 6,
                            content: `
                                <div class="staff__card__item__wrapper_c">
                                    <div class="staff__card__title__wrapper_c">
                                        <div class="staff__card__img__wrapper"></div>
                                        <div class="staff__card__info__wrapper_c">
                                            <p id="staff-card-title" class="staff__card__inner__title" data-id="" data-name=""></p>
                                            <div class="staff__card__textbox">
                                                <p id="staff-card-dep" class="staff__card__timestamp_c">투자전략팀</p>
                                            </div>
                                            <span id="staff-name">한미영</span>
                                        </div>
                                    </div>
                                    <div class="staff__card__inner__box">
                                        <a href="/" id="news-more-btn" class="card__more__btn card__btn__flex">자세히 보기</a>
                                    </div>
                                </div>
                            `
                        },
                        {
                            id: 7,
                            content: `
                                <div class="staff__card__item__wrapper_c">
                                    <div class="staff__card__title__wrapper_c">
                                        <div class="staff__card__img__wrapper"></div>
                                        <div class="staff__card__info__wrapper_c">
                                            <p id="staff-card-title" class="staff__card__inner__title" data-id="" data-name=""></p>
                                            <div class="staff__card__textbox">
                                                <p id="staff-card-dep" class="staff__card__timestamp_c">경제분석팀</p>
                                            </div>
                                            <span id="staff-name">서준호</span>
                                        </div>
                                    </div>
                                    <div class="staff__card__inner__box">
                                        <a href="/" id="news-more-btn" class="card__more__btn card__btn__flex">자세히 보기</a>
                                    </div>
                                </div>
                            `
                        },
                        {
                            id: 8,
                            content: `
                                <div class="staff__card__item__wrapper_c">
                                    <div class="staff__card__title__wrapper_c">
                                        <div class="staff__card__img__wrapper"></div>
                                        <div class="staff__card__info__wrapper_c">
                                            <p id="staff-card-title" class="staff__card__inner__title" data-id="" data-name=""></p>
                                            <div class="staff__card__textbox">
                                                <p id="staff-card-dep" class="staff__card__timestamp_c">리서치팀 국내부서</p>
                                            </div>
                                            <span id="staff-name">윤서연</span>
                                        </div>
                                    </div>
                                    <div class="staff__card__inner__box">
                                        <a href="/" id="news-more-btn" class="card__more__btn card__btn__flex">자세히 보기</a>
                                    </div>
                                </div>
                            `
                        }
                    ]
                }
            ];
            break;
    }

    return baseData;
};

/**
 * 액션 버튼 그룹을 동적으로 추가하는 함수
 */
window.RebotCore.addActionButtons = function(container) {
    const actionButtonsHTML = `
        <div class="prompt__query__btn__group">
            <button id="prompt-query-btn" class="prompt__query__btn">
                <div class="prompt__query__btn_ic1"></div>
            </button>
            <button id="prompt-query-btn" class="prompt__query__btn">
                <div class="prompt__query__btn_ic2"></div>
            </button>
            <button id="prompt-query-btn" class="prompt__query__btn">
                <div class="prompt__query__btn_ic3"></div>
            </button>
            <button id="prompt-query-btn" class="prompt__query__btn">
                <div class="prompt__query__btn_ic4"></div>
            </button>
            <button id="prompt-query-btn" class="prompt__query__btn">
                <div class="prompt__query__btn_ic5"></div>
            </button>
            <button id="prompt-query-btn-fd" class="prompt__query__btn" data-target="prompt-btn-more">
                <div class="prompt__query__btn_ic6"></div>
            </button>
            
            <div id="prompt-btn-more" class="prompt__btn__more">
                <ul class="prompt__btn__more_ul">
                    <li class="prompt__btn__more_li">피드백</li>
                    <li class="prompt__btn__more_li">다른 메뉴</li>
                </ul>
            </div>
        </div>
    `;
    
    const promptQueryBox = container.querySelector('.prompt__query_box');
    if (promptQueryBox) {
        promptQueryBox.insertAdjacentHTML('beforeend', actionButtonsHTML);
        
        // 액션 버튼 이벤트 바인딩
        this.bindActionButtonEvents(container);
    }
};

/**
 * 액션 버튼 이벤트 바인딩
 */
window.RebotCore.bindActionButtonEvents = function(container) {
    // 더보기 버튼 이벤트
    const moreBtn = container.querySelector('#prompt-query-btn-fd');
    if (moreBtn) {
        moreBtn.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = moreBtn.getAttribute('data-target');
            const target = container.querySelector(`#${targetId}`);
            if (target) {
                target.classList.toggle('active');
            }
        });
    }
    
    // 피드백 및 다른 메뉴 이벤트
    const feedbackBtn = container.querySelector('.prompt__btn__more_li');
    if (feedbackBtn) {
        feedbackBtn.addEventListener('click', (e) => {
            e.preventDefault();
            console.log('피드백 클릭됨');
            // 피드백 모달 열기 등의 동작
        });
    }
    
    const otherMenuBtn = container.querySelectorAll('.prompt__btn__more_li')[1];
    if (otherMenuBtn) {
        otherMenuBtn.addEventListener('click', (e) => {
            e.preventDefault();
            console.log('다른 메뉴 클릭됨');
            // 다른 메뉴 동작
        });
    }
};

/**
 * 복잡한 결과 요소들에 이벤트 바인딩 (퍼블리싱된 구조에 맞게)
 */
window.RebotCore.bindComplexResultEvents = function(container) {
    // 출처 버튼 이벤트
    const exlinksBtn = container.querySelector('#prompt-exlinks-box');
    if (exlinksBtn) {
        exlinksBtn.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = exlinksBtn.getAttribute('data-target');
            const target = document.getElementById(targetId);
            if (target) {
                target.classList.toggle('active');
            }
        });
    }
    
    // 더보기 버튼 이벤트
    const moreBtn = container.querySelector('#prompt-query-btn-fd');
    if (moreBtn) {
        moreBtn.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = moreBtn.getAttribute('data-target');
            const target = container.querySelector(`#${targetId}`);
            if (target) {
                target.classList.toggle('active');
            }
        });
    }
    
    // 관련 질문 버튼 이벤트 (큰 버튼)
    const relatedBtns = container.querySelectorAll('.query__rl__it');
    relatedBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            const question = btn.textContent.trim();
            this.subCallFunc(question);
        });
    });
    
    // 관련 질문 버튼 이벤트 (작은 버튼)
    const smallRelatedBtns = container.querySelectorAll('.query__rl__it__sm');
    smallRelatedBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            const question = btn.textContent.trim();
            this.subCallFunc(question);
        });
    });
    
    // 자세히 보기 버튼 이벤트
    const detailBtns = container.querySelectorAll('.card__more__btn');
    detailBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            console.log('자세히 보기 클릭됨');
        });
    });
    
    // 캘린더 이벤트들
    const calPrevBtn = container.querySelector('#cal-mon-prev');
    if (calPrevBtn) {
        calPrevBtn.addEventListener('click', (e) => {
            e.preventDefault();
            console.log('이전 달 클릭됨');
        });
    }
    
    const calNextBtn = container.querySelector('#cal-mon-next');
    if (calNextBtn) {
        calNextBtn.addEventListener('click', (e) => {
            e.preventDefault();
            console.log('다음 달 클릭됨');
        });
    }
    
    // 캘린더 날짜 클릭 이벤트
    const calDates = container.querySelectorAll('#cal-nb-date');
    calDates.forEach(date => {
        date.addEventListener('click', (e) => {
            e.preventDefault();
            console.log('캘린더 날짜 클릭됨:', date.textContent);
        });
    });
    
    // 캘린더 더보기 버튼
    const calMoreBtn = container.querySelector('#cal-more-btn');
    if (calMoreBtn) {
        calMoreBtn.addEventListener('click', (e) => {
            e.preventDefault();
            console.log('캘린더 더보기 클릭됨');
        });
    }
    
    // 캘린더 카드 더보기 버튼
    const calCardMoreBtns = container.querySelectorAll('#cal-li-more-btn');
    calCardMoreBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            console.log('캘린더 카드 더보기 클릭됨');
        });
    });
    
    // 스크롤 버튼 이벤트
    const scrollBtn = container.querySelector('#sc-btn');
    if (scrollBtn) {
        scrollBtn.addEventListener('click', (e) => {
            e.preventDefault();
            const chatArea = document.getElementById('main-chat-area');
            if (chatArea) {
                chatArea.scrollTop = chatArea.scrollHeight;
            }
        });
    }
    
    // 카드 클릭 이벤트들
    const queryCards = container.querySelectorAll('.query__card__wrapper');
    queryCards.forEach(card => {
        card.addEventListener('click', (e) => {
            e.preventDefault();
            console.log('관련 질문 카드 클릭됨');
        });
    });
    
    const reportCards = container.querySelectorAll('.report__card__wrapper');
    reportCards.forEach(card => {
        card.addEventListener('click', (e) => {
            e.preventDefault();
            console.log('리포트 카드 클릭됨');
        });
    });
    
    const newsCards = container.querySelectorAll('.news__card__wrapper');
    newsCards.forEach(card => {
        card.addEventListener('click', (e) => {
            e.preventDefault();
            console.log('뉴스 카드 클릭됨');
        });
    });
    
    const staffCards = container.querySelectorAll('.staff__card__wrapper');
    staffCards.forEach(card => {
        card.addEventListener('click', (e) => {
            e.preventDefault();
            const staffName = card.querySelector('#staff-name');
            const staffDep = card.querySelector('#staff-card-dep');
            
            if (staffName && staffDep) {
                const name = staffName.textContent.trim();
                const department = staffDep.textContent.trim();
                console.log(`애널리스트 선택: ${name} (${department})`);
                
                // 애널리스트 선택 시 추가 동작
                this.showBotMessage(`${name} 애널리스트의 상세 정보를 조회합니다...`, name);
            } else {
                console.log('애널리스트 카드 클릭됨');
            }
        });
    });
    
    const calCards = container.querySelectorAll('.cal__card__wrapper');
    calCards.forEach(card => {
        card.addEventListener('click', (e) => {
            e.preventDefault();
            console.log('캘린더 카드 클릭됨');
        });
    });
    
    const liCards = container.querySelectorAll('.li__card__wrapper');
    liCards.forEach(card => {
        card.addEventListener('click', (e) => {
            e.preventDefault();
            console.log('원자재 카드 클릭됨');
        });
    });
};

// 전역 함수로 등록 (기존 챗봇 호환성)
window.XSSCheck = window.RebotCore.XSSCheck;
window.fn_chatBotBtn = window.RebotCore.fn_chatBotBtn.bind(window.RebotCore);
window.subCallFunc = window.RebotCore.subCallFunc.bind(window.RebotCore);
window.addActionButtons = window.RebotCore.addActionButtons.bind(window.RebotCore);

// 자동 초기화
$(document).ready(function() {
    window.RebotCore.init();
});
