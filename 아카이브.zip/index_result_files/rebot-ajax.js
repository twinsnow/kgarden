/**
 * Rebot AJAX Utilities
 * 기존 ajax.js의 핵심 기능들을 rebot 프로젝트에 맞게 최적화
 */

window.RebotAjax = {
    
    // 기본 설정
    config: {
        timeout: 30000,
        headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
        }
    },
    
    /**
     * GET 요청
     * @param {string} url - 요청 URL
     * @param {Object} params - 쿼리 파라미터
     * @param {Object} options - 추가 옵션
     * @returns {Promise} - Promise 객체
     */
    get: function(url, params = {}, options = {}) {
        const queryString = this.buildQueryString(params);
        const fullUrl = queryString ? `${url}?${queryString}` : url;
        
        return this.request('GET', fullUrl, null, options);
    },
    
    /**
     * POST 요청
     * @param {string} url - 요청 URL
     * @param {Object} data - 전송할 데이터
     * @param {Object} options - 추가 옵션
     * @returns {Promise} - Promise 객체
     */
    post: function(url, data = {}, options = {}) {
        return this.request('POST', url, data, options);
    },
    
    /**
     * PUT 요청
     * @param {string} url - 요청 URL
     * @param {Object} data - 전송할 데이터
     * @param {Object} options - 추가 옵션
     * @returns {Promise} - Promise 객체
     */
    put: function(url, data = {}, options = {}) {
        return this.request('PUT', url, data, options);
    },
    
    /**
     * DELETE 요청
     * @param {string} url - 요청 URL
     * @param {Object} options - 추가 옵션
     * @returns {Promise} - Promise 객체
     */
    delete: function(url, options = {}) {
        return this.request('DELETE', url, null, options);
    },
    
    /**
     * 기본 요청 함수
     * @param {string} method - HTTP 메서드
     * @param {string} url - 요청 URL
     * @param {Object} data - 전송할 데이터
     * @param {Object} options - 추가 옵션
     * @returns {Promise} - Promise 객체
     */
    request: function(method, url, data = null, options = {}) {
        const config = {
            method: method.toUpperCase(),
            url: url,
            timeout: options.timeout || this.config.timeout,
            headers: { ...this.config.headers, ...options.headers }
        };
        
        // 데이터 처리
        if (data) {
            if (config.headers['Content-Type'] === 'application/json') {
                config.data = JSON.stringify(data);
            } else {
                config.data = data;
            }
        }
        
        return new Promise((resolve, reject) => {
            $.ajax(config)
                .done(function(response) {
                    resolve(response);
                })
                .fail(function(xhr, status, error) {
                    reject({
                        status: xhr.status,
                        statusText: xhr.statusText,
                        error: error,
                        response: xhr.responseText
                    });
                });
        });
    },
    
    /**
     * 쿼리 스트링 생성
     * @param {Object} params - 파라미터 객체
     * @returns {string} - 쿼리 스트링
     */
    buildQueryString: function(params) {
        if (!params || typeof params !== 'object') return '';
        
        const queryParts = [];
        for (const key in params) {
            if (params.hasOwnProperty(key) && params[key] !== null && params[key] !== undefined) {
                queryParts.push(`${encodeURIComponent(key)}=${encodeURIComponent(params[key])}`);
            }
        }
        return queryParts.join('&');
    },
    
    /**
     * 파일 업로드
     * @param {string} url - 업로드 URL
     * @param {FormData} formData - 폼 데이터
     * @param {Object} options - 추가 옵션
     * @returns {Promise} - Promise 객체
     */
    upload: function(url, formData, options = {}) {
        const config = {
            url: url,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            timeout: options.timeout || this.config.timeout,
            headers: options.headers || {}
        };
        
        return new Promise((resolve, reject) => {
            $.ajax(config)
                .done(function(response) {
                    resolve(response);
                })
                .fail(function(xhr, status, error) {
                    reject({
                        status: xhr.status,
                        statusText: xhr.statusText,
                        error: error,
                        response: xhr.responseText
                    });
                });
        });
    },
    
    /**
     * JSONP 요청
     * @param {string} url - 요청 URL
     * @param {Object} params - 쿼리 파라미터
     * @param {Object} options - 추가 옵션
     * @returns {Promise} - Promise 객체
     */
    jsonp: function(url, params = {}, options = {}) {
        const queryString = this.buildQueryString(params);
        const fullUrl = queryString ? `${url}?${queryString}` : url;
        
        return new Promise((resolve, reject) => {
            $.ajax({
                url: fullUrl,
                type: 'GET',
                dataType: 'jsonp',
                timeout: options.timeout || this.config.timeout,
                success: function(response) {
                    resolve(response);
                },
                error: function(xhr, status, error) {
                    reject({
                        status: xhr.status,
                        statusText: xhr.statusText,
                        error: error,
                        response: xhr.responseText
                    });
                }
            });
        });
    },
    
    /**
     * 에러 처리
     * @param {Object} error - 에러 객체
     * @param {Function} callback - 에러 처리 콜백
     */
    handleError: function(error, callback) {
        console.error('AJAX Error:', error);
        
        if (callback && typeof callback === 'function') {
            callback(error);
        } else {
            // 기본 에러 처리
            this.showErrorMessage(error);
        }
    },
    
    /**
     * 에러 메시지 표시
     * @param {Object} error - 에러 객체
     */
    showErrorMessage: function(error) {
        let message = '요청 처리 중 오류가 발생했습니다.';
        
        if (error.status === 404) {
            message = '요청한 리소스를 찾을 수 없습니다.';
        } else if (error.status === 500) {
            message = '서버 오류가 발생했습니다.';
        } else if (error.status === 0) {
            message = '네트워크 연결을 확인해주세요.';
        }
        
        // 향후 모달이나 토스트로 에러 메시지 표시
        console.error(message, error);
    },
    
    /**
     * 요청 인터셉터 설정
     * @param {Function} interceptor - 인터셉터 함수
     */
    setRequestInterceptor: function(interceptor) {
        this.requestInterceptor = interceptor;
    },
    
    /**
     * 응답 인터셉터 설정
     * @param {Function} interceptor - 인터셉터 함수
     */
    setResponseInterceptor: function(interceptor) {
        this.responseInterceptor = interceptor;
    }
};
