const box = document.querySelector('.cal__sc__box');
const btn = document.querySelector('.cal__card__more__btn');
const card = document.querySelector('.cal__card__wrapper');

if (box && btn) {
    if (box.scrollHeight > box.clientHeight) {
        box.classList.add('is-multiline');
        btn.hidden = false;
    }
}

document.querySelectorAll('.cal__card__more__btn').forEach(button => {
  button.addEventListener('click', e => {
    // 버튼이 속한 카드 찾기
    const cardElement = button.closest('.cal__card__wrapper');   // 각 카드의 루트
    if (!cardElement) return;

    const boxElement = cardElement.querySelector('.cal__sc__box'); // 카드 안의 내용 박스
    if (!boxElement) return;

    // 토글 처리
    boxElement.classList.toggle('is-open');
    cardElement.classList.toggle('is-multiline');
    button.textContent = boxElement.classList.contains('is-open') ? '접기' : '더 보기';
  });
});

const dataTargetBtn = document.querySelector('[data-target]');

if(dataTargetBtn){
    dataTargetBtn.addEventListener('click', (e) => {
        e.preventDefault()
        
        const targetId = dataTargetBtn.getAttribute('data-target')
        const selectMenuId = document.getElementById(targetId)

        if (!selectMenuId) return

        if(selectMenuId) {
            selectMenuId.classList.toggle('active')
        }
    })
}

if(dataTargetBtn) {
    document.addEventListener('click', (e) => {
        const selected = dataTargetBtn.getAttribute('data-target') || '';

        if(selected) {
            const clickedMenu = document.getElementById(selected)
            if (clickedMenu) {
                clickedMenu.classList.remove('active')
            }
        }
    })
}
