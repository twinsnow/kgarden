/**
 * Rebot Base64 Utilities
 * 기존 base64.js의 핵심 기능들을 rebot 프로젝트에 맞게 최적화
 */

window.RebotBase64 = {
    
    /**
     * 문자열을 Base64로 인코딩
     * @param {string} str - 인코딩할 문자열
     * @returns {string} - Base64 인코딩된 문자열
     */
    encode: function(str) {
        if (!str) return '';
        
        try {
            // UTF-8 인코딩을 위한 유니코드 처리
            const utf8Bytes = this.stringToUtf8Bytes(str);
            return btoa(String.fromCharCode.apply(null, utf8Bytes));
        } catch (error) {
            console.error('Base64 encoding error:', error);
            return '';
        }
    },
    
    /**
     * Base64를 문자열로 디코딩
     * @param {string} base64 - Base64 문자열
     * @returns {string} - 디코딩된 문자열
     */
    decode: function(base64) {
        if (!base64) return '';
        
        try {
            const binaryString = atob(base64);
            const bytes = new Uint8Array(binaryString.length);
            for (let i = 0; i < binaryString.length; i++) {
                bytes[i] = binaryString.charCodeAt(i);
            }
            return this.utf8BytesToString(bytes);
        } catch (error) {
            console.error('Base64 decoding error:', error);
            return '';
        }
    },
    
    /**
     * 문자열을 UTF-8 바이트 배열로 변환
     * @param {string} str - 문자열
     * @returns {Array} - UTF-8 바이트 배열
     */
    stringToUtf8Bytes: function(str) {
        const bytes = [];
        for (let i = 0; i < str.length; i++) {
            const code = str.charCodeAt(i);
            if (code < 0x80) {
                bytes.push(code);
            } else if (code < 0x800) {
                bytes.push(0xc0 | (code >> 6));
                bytes.push(0x80 | (code & 0x3f));
            } else if (code < 0xd800 || code >= 0xe000) {
                bytes.push(0xe0 | (code >> 12));
                bytes.push(0x80 | ((code >> 6) & 0x3f));
                bytes.push(0x80 | (code & 0x3f));
            } else {
                // 서로게이트 페어 처리
                i++;
                const code2 = str.charCodeAt(i);
                const codePoint = 0x10000 + (((code & 0x3ff) << 10) | (code2 & 0x3ff));
                bytes.push(0xf0 | (codePoint >> 18));
                bytes.push(0x80 | ((codePoint >> 12) & 0x3f));
                bytes.push(0x80 | ((codePoint >> 6) & 0x3f));
                bytes.push(0x80 | (codePoint & 0x3f));
            }
        }
        return bytes;
    },
    
    /**
     * UTF-8 바이트 배열을 문자열로 변환
     * @param {Uint8Array} bytes - UTF-8 바이트 배열
     * @returns {string} - 문자열
     */
    utf8BytesToString: function(bytes) {
        let str = '';
        let i = 0;
        
        while (i < bytes.length) {
            let codePoint;
            
            if (bytes[i] < 0x80) {
                codePoint = bytes[i];
                i++;
            } else if ((bytes[i] & 0xe0) === 0xc0) {
                codePoint = ((bytes[i] & 0x1f) << 6) | (bytes[i + 1] & 0x3f);
                i += 2;
            } else if ((bytes[i] & 0xf0) === 0xe0) {
                codePoint = ((bytes[i] & 0x0f) << 12) | ((bytes[i + 1] & 0x3f) << 6) | (bytes[i + 2] & 0x3f);
                i += 3;
            } else if ((bytes[i] & 0xf8) === 0xf0) {
                codePoint = ((bytes[i] & 0x07) << 18) | ((bytes[i + 1] & 0x3f) << 12) | ((bytes[i + 2] & 0x3f) << 6) | (bytes[i + 3] & 0x3f);
                i += 4;
            } else {
                // 잘못된 바이트 시퀀스
                i++;
                continue;
            }
            
            if (codePoint <= 0xffff) {
                str += String.fromCharCode(codePoint);
            } else {
                // 서로게이트 페어로 변환
                const surrogate1 = 0xd800 + ((codePoint - 0x10000) >> 10);
                const surrogate2 = 0xdc00 + ((codePoint - 0x10000) & 0x3ff);
                str += String.fromCharCode(surrogate1, surrogate2);
            }
        }
        
        return str;
    },
    
    /**
     * 파일을 Base64로 인코딩
     * @param {File} file - 파일 객체
     * @returns {Promise<string>} - Base64 문자열
     */
    encodeFile: function(file) {
        return new Promise((resolve, reject) => {
            if (!file) {
                reject(new Error('File is required'));
                return;
            }
            
            const reader = new FileReader();
            reader.onload = function(e) {
                const base64 = e.target.result.split(',')[1]; // data:image/jpeg;base64, 부분 제거
                resolve(base64);
            };
            reader.onerror = function(error) {
                reject(error);
            };
            reader.readAsDataURL(file);
        });
    },
    
    /**
     * Base64를 Blob으로 변환
     * @param {string} base64 - Base64 문자열
     * @param {string} mimeType - MIME 타입
     * @returns {Blob} - Blob 객체
     */
    base64ToBlob: function(base64, mimeType = 'application/octet-stream') {
        if (!base64) return null;
        
        try {
            const binaryString = atob(base64);
            const bytes = new Uint8Array(binaryString.length);
            
            for (let i = 0; i < binaryString.length; i++) {
                bytes[i] = binaryString.charCodeAt(i);
            }
            
            return new Blob([bytes], { type: mimeType });
        } catch (error) {
            console.error('Base64 to Blob conversion error:', error);
            return null;
        }
    },
    
    /**
     * Base64 문자열 유효성 검사
     * @param {string} str - 검사할 문자열
     * @returns {boolean} - 유효성 여부
     */
    isValid: function(str) {
        if (!str) return false;
        
        try {
            // Base64 패턴 검사
            const base64Pattern = /^[A-Za-z0-9+/]*={0,2}$/;
            if (!base64Pattern.test(str)) return false;
            
            // 길이가 4의 배수인지 확인
            if (str.length % 4 !== 0) return false;
            
            // 실제 디코딩 시도
            atob(str);
            return true;
        } catch (error) {
            return false;
        }
    },
    
    /**
     * URL 안전한 Base64 인코딩
     * @param {string} str - 인코딩할 문자열
     * @returns {string} - URL 안전한 Base64 문자열
     */
    encodeUrlSafe: function(str) {
        return this.encode(str)
            .replace(/\+/g, '-')
            .replace(/\//g, '_')
            .replace(/=/g, '');
    },
    
    /**
     * URL 안전한 Base64 디코딩
     * @param {string} base64 - URL 안전한 Base64 문자열
     * @returns {string} - 디코딩된 문자열
     */
    decodeUrlSafe: function(base64) {
        // 패딩 추가
        while (base64.length % 4) {
            base64 += '=';
        }
        
        // URL 안전 문자를 일반 Base64 문자로 변환
        base64 = base64.replace(/-/g, '+').replace(/_/g, '/');
        
        return this.decode(base64);
    }
};
