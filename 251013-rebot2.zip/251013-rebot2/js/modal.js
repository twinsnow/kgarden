const modal = document.getElementById("modal");
const modalBody = document.getElementById("modalBody");
const modalClose = document.getElementById;("modal-close");


// 이벤트 위임: data-modal-target 가진 요소 클릭 시 동작
document.addEventListener('click', (e) => {
  const btn = e.target.closest('[data-modal-target]');
  if (!btn) return;

  const targetId = btn.dataset.modalTarget;
  const src = document.getElementById(targetId);

  if (!src) {
    console.warn('모달 컨텐츠 소스가 없습니다:', targetId);
    return;
  }

  // 컨텐츠 갈아끼우기
  modalBody.innerHTML = '';
  // <template>이면 .content 사용, hidden div 방식이면 cloneNode(true)
  const node = src.content ? src.content.cloneNode(true) : src.cloneNode(true);
  if (!src.content) node.removeAttribute('hidden'); // hidden div 쓸 때 표시
  modalBody.appendChild(node);

  // 모달 열기
  if (typeof modal.showModal === 'function') {
    modal.showModal();
  } else {
    modal.setAttribute('open', '');
  }

  // 필요하면 컨텐츠 내부 스크립트 초기화
  // initModalContent?.(modalBody);
  
  modalBody.addEventListener('click', (e) => {
    if (e.target.closest('#modal-close')) {
      if (modal.open) modal.close();
      else modal.removeAttribute('open');
    } else if (e.target.closest('#modal-btn-cancel')) {
      if (modal.open) modal.close();
      else modal.removeAttribute('open');
  }})

  modal.addEventListener('click', (e) => {
    const rect = modal.getBoundingClientRect();
    const inDialog =
      e.clientX >= rect.left && e.clientX <= rect.right &&
      e.clientY >= rect.top &&  e.clientY <= rect.bottom;
    if (!inDialog) modal.close();
  });
  
});

// 닫기
document.getElementById('closeBtn')?.addEventListener('click', () => {
  modal.close?.();
  modal.removeAttribute('open');
});

/* function modalControl (openBtnId, modalId, modalBodyId, url) {
  const openBtn = document.getElementById(openBtnId);
  const modal = document.getElementById(modalId);
  const modalBody = document.getElementById(modalBodyId);

  if(!openBtn || !modal || !modalBody) {
    console.error('no element', { openBtn, modal, modalBody })
    return;
  }

  openBtn.addEventListener("click", async () => {
    try {
      if(url) {
        const res = await fetch(url);
        const html = await res.text();
        modalBody.innerHTML = html;



        const innerBoxbm = modalBody.querySelector('#modal-content-bm')
        const innerBoxdl = modalBody.querySelector('#modal-content-dl')
        const targetModal = innerBoxbm || innerBoxdl;

        if (targetModal) {
          openModal(targetModal);
        } else if (targetModal !== innerBoxbm || targetModal !== innerBoxdl) {
          console.warn("모달이 존재하지 않습니다.");
        }
      } else {
        console.error('fetching url wrong')
      }
      
      if (typeof modal.showModal === 'function') {
        modal.showModal();
      } else {
        modal.setAttribute('open', '');
      }
    } catch (err) {
      modalBody.textContent = "데이터 불러오기 실패: " + err.message;
    }
  });

  

}

modalControl(
  "open-fd-modal",
  "modal",
  "modalBody",
  "../modal/feedback.html"
)

modalControl(
  "open-setting-modal",
  "modal",
  "modalBody",
  "../modal/settings.html"
)

modalControl(
  "open-dl-modal",
  "modal",
  "modalBody",
  "../modal/common.html"
)

modalControl(
  "open-bm-modal",
  "modal",
  "modalBody",
  "../modal/common_bm.html"
)



function openModal(el) {
  if(el && el.id == 'modal-content-bm') {
    modal.classList.add('modal__top__adjust')
  } else if (el && el.id == 'modal-content-dl') { 
    modal.classList.add('modal__top__adjust')
  }
  
} */





  /**
 * 설정 모달 창 : 기능 추가 해 주세요 ( 버튼, 디스플레이 모드 )
 */