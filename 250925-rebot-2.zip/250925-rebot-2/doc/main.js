const tarea = document.getElementById('content-chat-input');



function autoResize(el) {
    el.style.height = 'auto';
    el.style.height = `${el.scrollHeight}px`;

    const max = parseInt(getComputedStyle(el).maxHeight);
    el.style.overflowY = (el.scrollHeight > max) ? 'auto' : 'hidden';
}

['input','change','cut','paste'].forEach(evt =>
    tarea.addEventListener(evt, () => autoResize(tarea)));

autoResize(tarea)

const navSdToggle = document.getElementById('sd-toggle-nav')
const navSdMo = document.getElementById('sd-toggle-mo')

const sdbar = document.getElementById('sidebar')
const sdbarOn = document.querySelector('.sidebar__cont_on')
const sdbarOff = document.querySelector('.sidebar__cont_off')

const logoShow = document.getElementById('nav-logo-top')
const logoShowMo = document.getElementById('nav-logo-top-mo')
const sdListToggle = document.getElementById('sd-toggle-list');
const sdList = document.getElementById('sd-list');

const sdMenuLBtn = document.getElementById('open-sd-l-menu');
const sdMenuLBtnA = document.querySelector('.link__menu_btn')

const sdLMenu = document.getElementById('sd-l-menu');
const listLinkStop = document.querySelector('.link-title')

document.querySelectorAll('[data-target]').forEach(btn => {
  btn.addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();

    const targetId = btn.getAttribute('data-target');
    const target = document.getElementById(targetId);
    const toggleIcon = btn.querySelector('.list_toggle_icon')
    if (target && toggleIcon) {
        const isActive = target.classList.toggle('active');
        toggleIcon.src = isActive ? "icons/toggle_ic_i.svg" : "icons/toggle_ic.svg";
        toggleIcon.alt = isActive ? 'on' : 'off'
    }
  });
});




const navIcSize = document.querySelector('.sd__toggle__wrapper')
const navIc = document.querySelector('.nav__icon2')

function openSideMenu(el) {
    el.addEventListener('click', (e) => {
        e.preventDefault();
        const currentStatus = sdbarOn.getAttribute('data-status');
        const nextStatus = currentStatus === 'on'? 'off' : 'on';

        sdbarOn.setAttribute('data-status', nextStatus);
        navSdToggle.setAttribute('data-status', nextStatus);


        if (nextStatus === 'off') {
            sdbarOff.setAttribute('data-status', 'on')
            logoShow.classList.remove('nav__logo_tt')
            logoShow.classList.add('nav__logo_t')
            console.log(logoShow)

            console.log(navIcSize.style.width)
            navIcSize.style.width = '3rem'
            navIcSize.style.textAlign = 'end'
            navIc.src = 'icons/sb_ic.svg'
            navIc.alt = '닫기'
        } else if (nextStatus === 'on') {
            sdbarOff.setAttribute('data-status', 'off' )
            logoShow.classList.remove('nav__logo_t')
            logoShow.classList.add('nav__logo_tt')
            navIcSize.style.width = '7rem'
            navIc.src = 'icons/sd_off_ic.svg'
            navIc.alt = '열기'
        }
    })
}

openSideMenu(navSdToggle);

function openSideMenuMo(el) {
  el.addEventListener('click', (e) => {
    e.preventDefault();

    const curMo = sdbarOn.getAttribute('data-status-mo') || 'off';
    const nextMo = curMo === 'on' ? 'off' : 'on';

    sdbarOn.setAttribute('data-status-mo', nextMo);
    navSdMo?.setAttribute('data-status-mo', nextMo);

    const logoShowMo = document.getElementById('nav-logo-top-mo');
    const navIcMo = document.querySelector('.nav__logo_mo');

    if (nextMo === 'off') {
      console.log(logoShowMo)
      logoShowMo?.classList.add('nav__logo_ttt');
      logoShowMo?.classList.remove('nav__logo__t_mo');
      if (navIcMo && 'alt' in navIcMo) navIcMo.alt = '닫기';
    } else {
      sdbarOn.setAttribute('data-status', 'off');
      logoShowMo?.classList.add('nav__logo__t_mo');
      logoShowMo?.classList.remove('nav__logo_ttt');
      if (navIcMo && 'alt' in navIcMo) navIcMo.alt = '열기';
    }

    const getStatus = document.querySelector('.sidebar__cont_off');
    const tStatus = sdbarOff?.getAttribute('data-status') || 'off';
    const curMoAgain = sdbarOn.getAttribute('data-status-mo');

    if (tStatus === 'on' && curMoAgain === 'off') {
      sdbarOn.setAttribute('data-status', 'off');
    }

    if (sdbarOn.getAttribute('data-status') === 'off' && curMoAgain === 'off') {
      getStatus?.setAttribute('data-status', 'on');
    }
  });
}


openSideMenuMo(navSdMo)

sdMenuLBtn.addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();
})

let currentBtn = null
let currentItemId = null

function openMenuNearButton(btn) {
  const btnRect = btn.getBoundingClientRect();

  const viewportHeight = window.innerHeight;
  const top  = 70;  // 버튼 아래
  const left = 0;
  console.log(top)
  console.log((btnRect.top / viewportHeight)* 10)

  sdLMenu.style.top  = `${top}px`; //70px 0
  sdLMenu.style.left = `${left}px`;

  sdLMenu.hidden = false;
  currentBtn = btn;
  currentItemId = btn.getAttribute('data-target') || null;

  btn.setAttribute('aria-expanded', 'true');
  btn.setAttribute('aria-controls', 'list-menu');
}

function closeMenu() {
  if (sdLMenu.hidden) return;
  sdLMenu.hidden = true;
  if (currentBtn) currentBtn.setAttribute('aria-expanded', 'false');
  currentBtn = null;
  currentItemId = null;
}

document.querySelectorAll('.link__menu_btn').forEach(btn =>
  btn.addEventListener('click', (e) => {
    console.log(sdLMenu)
    const btn = e.target.closest('.link__menu_btn');
    console.log('btn')
    console.log(btn)
    const rect = btn.getBoundingClientRect();
    console.log(rect);
    const li = sdLMenu
    console.log(li)
    if (!btn) return;

    e.preventDefault();
    e.stopPropagation();

    if (currentBtn === btn && !sdLMenu.hidden) {
      closeMenu();
      return;
    }

    openMenuNearButton(btn);
}));

document.addEventListener('click', (e) => {
  if(sdLMenu.hidden) return

  const clickedMenu = e.target.closest('#sd-l-menu')
  const clickedBtn = e.target.closest('.link__menu_btn')

  if (!clickedMenu && !clickedBtn) closeMenu()
})

const modelSelectBtn = document.getElementById('model-select-btn')
const modelSelectMenuId = document.getElementById('model-select-menu')
const modelSelectType = document.getElementById('model-select-type')




modelSelectBtn.addEventListener('click', (e) => {
  console.log(modelSelectBtn)
  e.preventDefault()
  
  const targetId = modelSelectBtn.getAttribute('data-target')
  const selectMenuId = document.getElementById(targetId)

  if (!selectMenuId) return

  console.log(selectMenuId)



  const isActive = selectMenuId.classList.toggle('active')

  if(isActive) {
    modelSelectBtn.setAttribute('data-status', 'btn-on');
  } /* else if(isActive !== 'active') {
    modelSelectBtn.setAttribute('data-status', 'btn-off');
  } */

  checkModelBtn(modelSelectBtn)
})

modelSelectType.addEventListener('click', (e) => {
  e.preventDefault()
})


function checkModelBtn (el) {
  const checkModelStatus = el.getAttribute('data-status')
  const toggleIcon = el.querySelector('.model__icons')

  if (!checkModelStatus) return;
  if(checkModelStatus === 'btn-on') {
    el.classList.add('btn__on')
    toggleIcon.src = "icons/model_active_ic.svg";
    toggleIcon.alt = 'on'
  } else if (checkModelStatus=== 'btn-off') {
    el.classList.remove('btn__on')
    toggleIcon.src = "icons/model_ic.svg";
    toggleIcon.alt = 'off'
  } else {
    console.warn(`Unexpected data-status value. Expected 'btn-on' or 'btn-off'.`);
  }
}

document.addEventListener('click', (e) => {
  const selected = modelSelectBtn.getAttribute('data-status') || '';
  console.log(selected)

  const clickedMenu = document.getElementById('model-select-menu')
  if (clickedMenu) clickedMenu.classList.remove('active')
})

const promptQueryBtn = document.getElementById('prompt-query-btn-fd')

promptQueryBtn.addEventListener('click', (e) => {
  e.preventDefault()
  
  const targetId = promptQueryBtn.getAttribute('data-target')
  const selectMenuId = document.getElementById(targetId)

  if (!selectMenuId) return

  if(selectMenuId) {
    selectMenuId.classList.toggle('active')
  }

})

document.addEventListener('click', (e) => {
  const selected = promptQueryBtn.getAttribute('data-target') || '';
  console.log(selected)

  if(selected) {
    const clickedMenu = document.getElementById(selected)
    clickedMenu.classList.remove('active')
  }
})

const rightPopupClose = document.getElementById('right-menu-close')
const rightPopupMenu = document.getElementById('right-popup-menu')

const rightPopupLinks = document.getElementById('right-popup-links')
const rightLinksBtn = document.getElementById('prompt-exlinks-box')
const rightLinksClose = document.getElementById('right-links-close')




rightPopupClose.addEventListener('click', () => {
  console.log(rightPopupClose)
  if(rightPopupClose !== null) {
    rightPopupMenu.style.display = 'none'
  }
})


rightLinksBtn.addEventListener('click', (e) => {
  e.preventDefault();

  const targetId = rightLinksBtn.getAttribute('data-target');
  const rightLinksId = document.getElementById(targetId);
  if (!rightLinksId) return;

  const isActive = rightLinksId.classList.toggle('active');

  if (isActive) {
    rightLinksId.classList.remove('display-off');
  } else {
    rightLinksId.classList.add('display-off');
  }
});


rightLinksClose.addEventListener('click', () => {
  const targetId = rightLinksBtn.getAttribute('data-target');
  const rightLinksId = document.getElementById(targetId);
  if (!rightLinksId) return;

  rightLinksId.classList.remove('active');
  rightLinksId.classList.add('display-off');
});

/**
 * flexible ta
 */


/**
 * scroll evt
 */
const header = document.querySelector('.js-hide-on-scroll');
let lastY = window.scrollY;
let ticking = false;

function onScroll(){
  const y = window.scrollY;
  const goingDown = y > lastY;
  // 임계치(20px)로 미세 흔들림 방지
  if (Math.abs(y - lastY) > 20){
    header.classList.toggle('is-hidden', goingDown && y > 40);
    lastY = y;
    console.log(header)
  }
  ticking = false;
}

  // 1) 특정 지점에서 바 페이드 아웃
const chipbar = document.getElementById('chipbar');
const sentinel = document.getElementById('chipbar-sentinel');

const io = new IntersectionObserver(([entry]) => {
  // sentinel이 화면에 보일 때는 바를 보이게, 사라지면 바를 숨김
  chipbar.classList.toggle('is-hidden', !entry.isIntersecting);
}, { root: null, threshold: 0 });
io.observe(sentinel);

// 2) 작은 화면에서만 툴팁 잠깐 보여주고 자동 숨김
const tip = document.getElementById('chipbar-tip');
const mq = window.matchMedia('(max-width: 767px)');
let tipShownOnce = false;

function showTipOnce(){
  if (!mq.matches || tipShownOnce) return;
  tip.setAttribute('aria-hidden','false');
  tip.classList.add('is-show');
  tipShownOnce = true;
  // 2.2초 뒤 자동 숨김
  setTimeout(() => {
    tip.classList.remove('is-show');
    tip.setAttribute('aria-hidden','true');
  }, 2200);
}

// 첫 로드/리사이즈 시점
showTipOnce();
mq.addEventListener?.('change', showTipOnce);

// 스크롤하거나 칩바 터치/클릭하면 즉시 숨김
['scroll','touchstart','click'].forEach(evt=>{
  window.addEventListener(evt, () => {
    if (tip.classList.contains('is-show')) {
      tip.classList.remove('is-show');
      tip.setAttribute('aria-hidden','true');
    }
  }, { passive:true });
});