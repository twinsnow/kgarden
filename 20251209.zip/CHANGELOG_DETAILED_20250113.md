# 상세 변경 내역 (2025-01-13)

## 파일: `js/lib/rebot-core.js`

---

## 1. `subCallFunc` 함수 수정

### 위치: 라인 258-289

### 변경 내용: 입력 길이 기반 라우팅 추가

#### BEFORE:
```javascript
window.RebotCore.subCallFunc = function(serviceChk) {
    console.log("서비스 요청:", serviceChk);
    console.log("subCallFunc 호출 스택:", new Error().stack);
    
    // 사용자에게 피드백 제공
    this.showUserFeedback(serviceChk);
    
    // 향후 AI 프롬프트 API 연동을 위한 구조
    if (typeof window.RebotAI !== 'undefined' && window.RebotAI.sendMessage) {
        // AI 프롬프트 연동 (차후 구현)
        window.RebotAI.sendMessage(serviceChk);
    } else {
        // 현재는 기본 동작
        this.handleServiceRequest(serviceChk);
    }
};
```

#### AFTER:
```javascript
window.RebotCore.subCallFunc = function(serviceChk) {
    console.log("서비스 요청:", serviceChk);
    console.log("subCallFunc 호출 스택:", new Error().stack);
    
    // 사용자에게 피드백 제공
    this.showUserFeedback(serviceChk);
    
    // 입력 길이 기준으로 라우팅 결정 (30자 기준)
    // 공백 제거 후 실제 문자 길이로 계산
    const trimmedInput = serviceChk.trim();
    const inputLength = trimmedInput.length;
    const MAX_SERVICE_MATCH_LENGTH = 30; // 서비스 매칭 최대 길이
    
    console.log(`입력 길이: ${inputLength}자 (기준: ${MAX_SERVICE_MATCH_LENGTH}자)`);
    
    // 긴 입력(30자 초과)은 AI 프롬프트로 전달
    if (inputLength > MAX_SERVICE_MATCH_LENGTH) {
        console.log("긴 입력 감지 → AI 프롬프트로 전달");
        this.handleAIQuestion(serviceChk);
        return;
    }
    
    // 짧은 입력(30자 이하)은 기존 서비스 매칭 로직 사용
    // 향후 AI 프롬프트 API 연동을 위한 구조
    if (typeof window.RebotAI !== 'undefined' && window.RebotAI.sendMessage) {
        // AI 프롬프트 연동 (차후 구현)
        window.RebotAI.sendMessage(serviceChk);
    } else {
        // 현재는 기본 동작 (서비스 매칭)
        this.handleServiceRequest(serviceChk);
    }
};
```

---

## 2. `handleServiceRequest` 함수 수정

### 위치: 라인 316-520

### 변경 내용: 
1. 시간 표현 + 초성 패턴 추가
2. 상품명 패턴 우선 체크 추가
3. 종목명 추출 로직을 서비스명 체크보다 먼저 실행

#### 주요 추가/수정 부분:

##### 2-1. 시간 표현 + 초성 패턴 추가 (라인 320-364)

**추가된 코드:**
```javascript
// 0. 초성 입력 우선 처리 (종목 검색 우선)
// "ㅅㅅㅈㅈ 시세" 또는 "지금 ㅅㅅㅈㅈ 시세는?" 같은 패턴에서 초성 부분만 추출
const timeKeywords = ["현재", "지금", "지금은", "오늘"];

// 시간 표현 + 초성 패턴 체크
const timeChosungPattern = new RegExp(`(?:${timeKeywords.join('|')})\\s+([ㄱ-ㅎ]+)\\s*시세[\\s\\?\\!는이가을를]*`, 'i');
const timeChosungMatch = serviceChk.trim().match(timeChosungPattern);
if (timeChosungMatch) {
    const chosungInput = timeChosungMatch[1]; // 초성 부분만 추출
    if (typeof window.KoreanUtils !== 'undefined') {
        // 먼저 기존 시스템 데이터에서 종목 검색
        const stockResult = this.searchStockByInitials(chosungInput);
        if (stockResult) {
            // 여러 종목이 매칭된 경우
            if (stockResult.code === 'MULTIPLE') {
                this.showMultipleStockOptions(chosungInput, stockResult.data);
                return;
            }
            
            // 단일 종목 매칭
            console.log(`[시간 표현 + 초성] 초성 매칭 완료: ${chosungInput} -> ${stockResult.name}`);
            this.showBotMessage(`"${chosungInput}" 초성으로 "${stockResult.name}" 종목을 찾았습니다.`, "초성 검색");
            this.getStockPrice(stockResult.name);
            return;
        }
        
        // 종목이 없으면 일반 키워드 검색 (인덴트 규칙 제외)
        const suggestions = this.getKoreanInitialSuggestions(chosungInput, false);
        if (suggestions.length > 0) {
            const bestMatch = suggestions[0];
            this.showBotMessage(`"${chosungInput}" 초성으로 "${bestMatch.keyword}"를 찾았습니다.`, "초성 검색");
            const matchedRule = this.intentManager.rules.find(rule => rule.keywords.includes(bestMatch.keyword));
            if (matchedRule) {
                this.executeIntentRule(matchedRule, serviceChk);
                return;
            }
        } else {
            this.showBotMessage(`"${chosungInput}" 초성으로 매칭되는 키워드를 찾을 수 없습니다.`, "초성 검색");
            return;
        }
    } else {
        this.showBotMessage(`"${chosungInput}" 초성 입력을 감지했지만 KoreanUtils가 로드되지 않았습니다.`, "초성 검색");
        return;
    }
}
```

##### 2-2. 상품명 패턴 우선 체크 추가 (라인 407-450)

**추가된 코드:**
```javascript
// 0.5. 시간 표현 + 상품명 + 시세 패턴 최우선 체크 (서비스명 체크보다 먼저)
// 패턴: "현재/지금/지금은 + [상품명]시세" 또는 "현재/지금/지금은 + [상품명] + 시세"
// 특수문자(?, ! 등) 허용
// timeKeywords는 이미 위에서 선언됨
const commodityNames = [
    { name: "금", code: "COM@GC" },
    { name: "은", code: "COM@SI" },
    { name: "구리", code: "COM@HG" },
    { name: "원유", code: "NYM@CL" }
];

// 시간 표현 + 상품명 + 시세 패턴 체크 (특수문자 허용)
for (const timeKeyword of timeKeywords) {
    for (const commodity of commodityNames) {
        // 패턴 1: "현재 금시세" 또는 "현재 금시세?" (붙어있음, 특수문자 허용)
        const pattern1 = new RegExp(`${timeKeyword}\\s*${commodity.name}시세[\\s\\?\\!]*`, 'i');
        // 패턴 2: "현재 금 시세" 또는 "현재 금 시세?" (공백 있음, 특수문자 허용)
        const pattern2 = new RegExp(`${timeKeyword}\\s*${commodity.name}\\s*시세[\\s\\?\\!]*`, 'i');
        
        if (pattern1.test(serviceChk) || pattern2.test(serviceChk)) {
            console.log(`[패턴 매칭] "${timeKeyword} ${commodity.name}시세" 감지 → 유가/상품 서비스로 직접 이동`);
            this.searchNo = "";
            this.oilProduct("T", commodity.code);
            return;
        }
    }
}

// 0.5-1. 상품명 + 시세 패턴 체크 (시간 표현 없이, 특수문자 허용)
const commodityPatterns = [
    { pattern: /금\s*시세[\s\?\!]*|금시세[\s\?\!]*/i, name: "금", code: "COM@GC" },
    { pattern: /은\s*시세[\s\?\!]*|은시세[\s\?\!]*/i, name: "은", code: "COM@SI" },
    { pattern: /구리\s*시세[\s\?\!]*|구리시세[\s\?\!]*/i, name: "구리", code: "COM@HG" },
    { pattern: /원유\s*시세[\s\?\!]*|원유시세[\s\?\!]*/i, name: "원유", code: "NYM@CL" }
];

for (const commodity of commodityPatterns) {
    if (commodity.pattern.test(serviceChk)) {
        console.log(`[패턴 매칭] "${commodity.name}" 상품명 패턴 감지 → 유가/상품 서비스로 직접 이동`);
        this.searchNo = "";
        this.oilProduct("T", commodity.code);
        return;
    }
}
```

##### 2-3. 종목명 추출 로직을 서비스명 체크보다 먼저 실행 (라인 452-486)

**변경 전 순서:**
1. 서비스명 체크
2. 종목명 추출

**변경 후 순서:**
1. 종목명 추출 (라인 452-486)
2. 서비스명 체크 (라인 488-494)

**추가된 코드:**
```javascript
// 0.6. 종목명 + 시세 패턴 우선 체크 (서비스명 체크보다 먼저)
// "현재 삼성전자 시세는?" 같은 경우 종목명을 먼저 추출하여 서비스명으로 오인되지 않도록 함
if (/[가-힣a-zA-Z]+.*시세/.test(serviceChk.trim()) || /시세.*[가-힣a-zA-Z]+/.test(serviceChk.trim())) {
    console.log(`[종목명 추출 시도] 입력: "${serviceChk}"`);
    const stockName = this.extractStockNameFromInput(serviceChk);
    console.log(`[종목명 추출 결과] 추출된 종목명: "${stockName}"`);
    if (stockName) {
        // 상품명(금, 은, 구리, 원유)은 종목명으로 인식하지 않음
        const commodityNames = ["금", "은", "구리", "원유"];
        if (commodityNames.includes(stockName)) {
            console.log(`"${stockName}"은 상품명이므로 유가/상품 서비스로 직접 이동 (시간 표현 무관)`);
            // 시간 표현과 관계없이 직접 유가/상품 서비스 호출
            this.searchNo = "";
            // 특정 상품 코드로 상세 조회
            const commodityCodeMap = {
                "금": "COM@GC",
                "은": "COM@SI",
                "구리": "COM@HG",
                "원유": "NYM@CL"
            };
            const commodityCode = commodityCodeMap[stockName] || "";
            if (commodityCode) {
                this.oilProduct("T", commodityCode);
            } else {
                this.oilProduct("", "");
            }
            return;
        } else {
            console.log(`[종목명 추출 성공] "${stockName}" → 종목 시세 조회`);
            this.showBotMessage(`"${stockName}" 시세를 조회하겠습니다...`, "종목 시세");
            this.getStockPrice(stockName);
            return;
        }
    }
}

// 0.7. 서비스명 체크 (종목명이 추출되지 않은 경우에만)
// "금 시세", "은 시세", "유가", "상품" 같은 서비스명이 종목명으로 오인되지 않도록 먼저 체크
if (this.isExactService(serviceChk)) {
    console.log("서비스명 매칭 → 서비스 처리로 이동");
    this.handleExactService(serviceChk);
    return;
}
```

##### 2-4. 종목명 재확인 로직 추가 (라인 505-518)

**추가된 코드:**
```javascript
// 2. 종목명 + 시세 패턴 재확인 (analyzeUserIntent 전에 한 번 더 체크)
// "현재 삼성전자 시세는?" 같은 경우 analyzeUserIntent에서 stock_market으로 분류되기 전에 종목명 추출
if (/[가-힣a-zA-Z]+.*시세/.test(serviceChk.trim()) || /시세.*[가-힣a-zA-Z]+/.test(serviceChk.trim())) {
    const stockName = this.extractStockNameFromInput(serviceChk);
    if (stockName) {
        // 상품명(금, 은, 구리, 원유)은 종목명으로 인식하지 않음
        const commodityNames = ["금", "은", "구리", "원유"];
        if (!commodityNames.includes(stockName)) {
            console.log(`[재확인] 종목명 추출 성공: "${stockName}" → 종목 시세 조회`);
            this.showBotMessage(`"${stockName}" 시세를 조회하겠습니다...`, "종목 시세");
            this.getStockPrice(stockName);
            return;
        }
    }
}
```

---

## 3. `isExactService` 함수 수정

### 위치: 라인 1062-1128

### 변경 내용: 시간 표현 필터링 추가

#### BEFORE:
```javascript
window.RebotCore.isExactService = function(input) {
    // 기존 정확한 매칭 시도
    const normalized = input.replace(/\s*\|\s*/g, '/').replace(/\s+/g, '');
    
    const exactServices = [
        "주식시장", "업종/종목등락", "종목현재가", "글로벌증시",
        "유가/상품", "금리/환율", "KB데일리", "최신리포트",
        "캘린더", "애널리스트"
    ];
    
    // 정규화된 값으로 비교
    const matchResult = exactServices.some(service => {
        const normalizedService = service.replace(/\s*\|\s*/g, '/').replace(/\s+/g, '');
        return normalized === normalizedService || input === service;
    });
    
    // 기존 특별 처리
    if (matchResult || 
        (input.includes("유가") && input.includes("상품")) ||
        (input.includes("금리") && input.includes("환율")) ||
        (input.includes("KB") && input.includes("데일리")) ||
        (input.includes("최신") && input.includes("리포트"))) {
        return true;
    }
    
    // 퍼지 매칭 시도 (임계값 0.7)
    if (typeof window.RebotUtils !== 'undefined') {
        const fuzzyMatch = this.fuzzyMatchService(input, 0.7);
        if (fuzzyMatch) {
            return true;
        }
    }
    
    return false;
};
```

#### AFTER:
```javascript
window.RebotCore.isExactService = function(input) {
    // 시간 표현 키워드 (이런 단어가 포함되면 "금", "은" 같은 한 글자 서비스명 매칭 제외)
    const timeKeywords = ["지금", "현재", "오늘", "지금은", "현재는", "오늘은", "지금의", "현재의", "오늘의"];
    const hasTimeKeyword = timeKeywords.some(keyword => input.includes(keyword));
    
    // 기존 정확한 매칭 시도
    const normalized = input.replace(/\s*\|\s*/g, '/').replace(/\s+/g, '');
    
    const exactServices = [
        "주식시장", "업종/종목등락", "종목현재가", "글로벌증시",
        "유가/상품", "금리/환율", "KB데일리", "최신리포트",
        "캘린더", "애널리스트"
    ];
    
    // 정규화된 값으로 비교
    const matchResult = exactServices.some(service => {
        const normalizedService = service.replace(/\s*\|\s*/g, '/').replace(/\s+/g, '');
        return normalized === normalizedService || input === service;
    });
    
    // 기존 특별 처리 (단, 시간 표현이 포함된 경우 "금", "은" 단독 매칭 제외)
    if (matchResult) {
        return true;
    }
    
    // "유가"와 "상품"이 모두 포함된 경우만 매칭 (시간 표현 무관)
    if (input.includes("유가") && input.includes("상품")) {
        return true;
    }
    
    // "금리"와 "환율"이 모두 포함된 경우만 매칭
    if (input.includes("금리") && input.includes("환율")) {
        return true;
    }
    
    // "KB"와 "데일리"가 모두 포함된 경우만 매칭
    if (input.includes("KB") && input.includes("데일리")) {
        return true;
    }
    
    // "최신"과 "리포트"가 모두 포함된 경우만 매칭
    if (input.includes("최신") && input.includes("리포트")) {
        return true;
    }
    
    // "금", "은" 단독 매칭은 시간 표현이 포함된 경우 제외
    if (hasTimeKeyword) {
        // 시간 표현이 포함된 경우 "금", "은" 단독 매칭 제외
        if (input.trim() === "금" || input.trim() === "은" || 
            input.includes(" 금 ") || input.includes(" 은 ") ||
            input.startsWith("금 ") || input.startsWith("은 ") ||
            input.endsWith(" 금") || input.endsWith(" 은")) {
            console.log(`[서비스 매칭 제외] 시간 표현("${timeKeywords.find(k => input.includes(k))}")이 포함되어 있어 "금"/"은" 매칭 제외`);
            return false;
        }
    }
    
    // 퍼지 매칭 시도 (임계값 0.7)
    if (typeof window.RebotUtils !== 'undefined') {
        const fuzzyMatch = this.fuzzyMatchService(input, 0.7);
        if (fuzzyMatch) {
            return true;
        }
    }
    
    return false;
};
```

---

## 4. `fuzzyMatchService` 함수 수정

### 위치: 라인 1215-1345

### 변경 내용: 시간 표현 필터링 추가

#### BEFORE:
```javascript
window.RebotCore.fuzzyMatchService = function(input, threshold = 0.65) {
    if (!input || typeof window.RebotUtils === 'undefined') {
        return null;
    }
    
    // 서비스 정의 (이름, 패턴, 액션)
    const services = [
        {
            name: "유가/상품",
            patterns: ["유가", "상품", "원유", "금", "은", "구리"],
            action: () => { this.searchNo = ""; this.oilProduct("", ""); }
        },
        // ... 기타 서비스
    ];
    
    let bestMatch = { service: null, score: 0 };
    
    for (const service of services) {
        // 패턴 매칭 점수 계산
        let patternScore = 0;
        let matchedPatterns = 0;
        
        for (const pattern of service.patterns) {
            // 정규화된 유사도 계산
            const similarity = window.RebotUtils.normalizedSimilarity(input, pattern);
            const partialScore = window.RebotUtils.partialMatchScore(input, pattern);
            const combinedScore = Math.max(similarity, partialScore);
            
            if (combinedScore > 0.5) {
                patternScore += combinedScore;
                matchedPatterns++;
            }
        }
        // ... 점수 계산 및 반환
    }
};
```

#### AFTER:
```javascript
window.RebotCore.fuzzyMatchService = function(input, threshold = 0.65) {
    if (!input || typeof window.RebotUtils === 'undefined') {
        return null;
    }
    
    // 시간 표현 키워드 (이런 단어가 포함되면 "금", "은" 같은 한 글자 서비스명 매칭 제외)
    const timeKeywords = ["지금", "현재", "오늘", "지금은", "현재는", "오늘은", "지금의", "현재의", "오늘의"];
    
    // 입력에서 시간 표현 포함 여부 체크
    const hasTimeKeyword = timeKeywords.some(keyword => input.includes(keyword));
    
    // 서비스 정의 (이름, 패턴, 액션)
    const services = [
        {
            name: "유가/상품",
            patterns: ["유가", "상품", "원유", "금", "은", "구리"],
            action: () => { this.searchNo = ""; this.oilProduct("", ""); },
            // 한 글자 패턴 목록 (시간 표현과 충돌 가능)
            singleCharPatterns: ["금", "은"]
        },
        // ... 기타 서비스
    ];
    
    let bestMatch = { service: null, score: 0 };
    
    for (const service of services) {
        // 패턴 매칭 점수 계산
        let patternScore = 0;
        let matchedPatterns = 0;
        
        for (const pattern of service.patterns) {
            // 한 글자 패턴("금", "은")이고 시간 표현이 포함된 경우 제외
            if (service.singleCharPatterns && service.singleCharPatterns.includes(pattern)) {
                if (hasTimeKeyword) {
                    console.log(`[퍼지 매칭 스킵] "${pattern}" 패턴은 시간 표현("${timeKeywords.find(k => input.includes(k))}")이 포함되어 있어 제외`);
                    continue;
                }
                // 한 글자 패턴은 정확한 포함만 허용 (부분 매칭 제외)
                if (!input.includes(pattern) && !input.includes(pattern + " ") && !input.includes(" " + pattern)) {
                    continue;
                }
            }
            
            // 정규화된 유사도 계산
            const similarity = window.RebotUtils.normalizedSimilarity(input, pattern);
            const partialScore = window.RebotUtils.partialMatchScore(input, pattern);
            const combinedScore = Math.max(similarity, partialScore);
            
            if (combinedScore > 0.5) {
                patternScore += combinedScore;
                matchedPatterns++;
            }
        }
        // ... 점수 계산 및 반환
    }
};
```

---

## 5. `extractStockNameFromInput` 함수 수정

### 위치: 라인 1792-1888

### 변경 내용: 시간 표현 + 초성/종목명 패턴 추가, 상품명 필터링 추가

#### BEFORE:
```javascript
window.RebotCore.extractStockNameFromInput = function(input) {
    const trimmedInput = input.trim();
    
    // 패턴 1: "초성 시세" (예: "ㅅㅅㅈㅈ 시세")
    const chosungPattern = /^([ㄱ-ㅎ]+)\s*시세$/;
    const chosungMatch = trimmedInput.match(chosungPattern);
    if (chosungMatch) {
        const chosungInput = chosungMatch[1];
        // 초성으로 종목 검색
        const stockResult = this.searchStockByInitials(chosungInput);
        if (stockResult) {
            return stockResult.name;
        }
        return null;
    }
    
    // "종목명 시세" 패턴
    const stockNamePattern1 = /([가-힣a-zA-Z]+)\s*시세/;
    const match1 = trimmedInput.match(stockNamePattern1);
    if (match1) {
        return match1[1];
    }
    
    // "시세 종목명" 패턴
    const stockNamePattern2 = /시세\s*([가-힣a-zA-Z]+)/;
    const match2 = trimmedInput.match(stockNamePattern2);
    if (match2) {
        return match2[1];
    }
    
    // "종목명" + "시세" 패턴 (공백 없이)
    const stockNamePattern3 = /([가-힣a-zA-Z]+)시세/;
    const match3 = trimmedInput.match(stockNamePattern3);
    if (match3) {
        return match3[1];
    }
    
    return null;
};
```

#### AFTER (전체 코드):
```javascript
window.RebotCore.extractStockNameFromInput = function(input) {
    const trimmedInput = input.trim();
    
    // 상품명 필터링 (금, 은, 구리, 원유는 종목명으로 인식하지 않음)
    const commodityNames = ["금", "은", "구리", "원유"];
    const timeKeywords = ["현재", "지금", "지금은", "오늘"];
    
    // 패턴 1-1: "시간 표현 + 초성 시세" (예: "지금 ㅅㅅㅈㅈ 시세는?")
    const timeChosungPattern = new RegExp(`(?:${timeKeywords.join('|')})\\s+([ㄱ-ㅎ]+)\\s*시세[\\s\\?\\!는이가을를]*`, 'i');
    const timeChosungMatch = trimmedInput.match(timeChosungPattern);
    if (timeChosungMatch) {
        const chosungInput = timeChosungMatch[1];
        // 초성으로 종목 검색
        const stockResult = this.searchStockByInitials(chosungInput);
        if (stockResult) {
            return stockResult.name;
        }
        return null;
    }
    
    // 패턴 1-2: "초성 시세" (예: "ㅅㅅㅈㅈ 시세")
    const chosungPattern = /^([ㄱ-ㅎ]+)\s*시세[\s\?\!는이가을를]*$/;
    const chosungMatch = trimmedInput.match(chosungPattern);
    if (chosungMatch) {
        const chosungInput = chosungMatch[1];
        // 초성으로 종목 검색
        const stockResult = this.searchStockByInitials(chosungInput);
        if (stockResult) {
            return stockResult.name;
        }
        return null;
    }
    
    // 시간 표현 + 종목명 + 시세 패턴 우선 체크
    // "현재 삼성전자 시세는?" 같은 경우 "삼성전자"를 추출
    // timeKeywords는 함수 상단에서 선언됨
    // 패턴: 시간표현 + 공백 + 종목명(한글/영문) + 공백(선택) + 시세 + 조사/특수문자(선택)
    const timeStockPattern = new RegExp(`(?:${timeKeywords.join('|')})\\s+([가-힣a-zA-Z0-9]+)\\s*시세[\\s\\?\\!는이가을를]*`, 'i');
    const timeStockMatch = trimmedInput.match(timeStockPattern);
    if (timeStockMatch) {
        const stockName = timeStockMatch[1];
        console.log(`[종목명 추출] 시간 표현 패턴 매칭: "${stockName}"`);
        // 상품명이면 null 반환 (종목명이 아님)
        if (commodityNames.includes(stockName)) {
            console.log(`[종목명 추출] 상품명으로 판단되어 제외: "${stockName}"`);
            return null;
        }
        console.log(`[종목명 추출] 종목명으로 판단: "${stockName}"`);
        return stockName;
    }
    
    // "종목명 시세" 패턴 (시세 뒤에 다른 문자 허용: "는?", "이?", "가?", "을?", "를?" 등)
    const stockNamePattern1 = /([가-힣a-zA-Z]+)\s*시세[\s\?\!는이가을를]*/;
    const match1 = trimmedInput.match(stockNamePattern1);
    if (match1) {
        const extractedName = match1[1];
        // 시간 표현 키워드는 제외
        if (timeKeywords.includes(extractedName)) {
            return null;
        }
        // 상품명이면 null 반환 (종목명이 아님)
        if (commodityNames.includes(extractedName)) {
            return null;
        }
        return extractedName;
    }
    
    // "시세 종목명" 패턴 (시세 뒤에 다른 문자 허용)
    const stockNamePattern2 = /시세[\s\?\!는이가을를]*\s*([가-힣a-zA-Z]+)/;
    const match2 = trimmedInput.match(stockNamePattern2);
    if (match2) {
        const extractedName = match2[1];
        // 상품명이면 null 반환 (종목명이 아님)
        if (commodityNames.includes(extractedName)) {
            return null;
        }
        return extractedName;
    }
    
    // "종목명" + "시세" 패턴 (공백 없이, 시세 뒤에 다른 문자 허용)
    const stockNamePattern3 = /([가-힣a-zA-Z]+)시세[\s\?\!는이가을를]*/;
    const match3 = trimmedInput.match(stockNamePattern3);
    if (match3) {
        const extractedName = match3[1];
        // 시간 표현 키워드는 제외
        if (timeKeywords.includes(extractedName)) {
            return null;
        }
        // 상품명이면 null 반환 (종목명이 아님)
        if (commodityNames.includes(extractedName)) {
            return null;
        }
        return extractedName;
    }
    
    return null;
};
```

---

## 변경 사항 요약

### 수정된 함수 (5개)
1. `subCallFunc` - 입력 길이 체크 추가
2. `handleServiceRequest` - 초성/상품명/종목명 처리 로직 추가 및 순서 변경
3. `isExactService` - 시간 표현 필터링 추가
4. `fuzzyMatchService` - 시간 표현 필터링 추가
5. `extractStockNameFromInput` - 시간 표현 패턴 및 상품명 필터링 추가

### 추가된 기능
- 입력 길이 기반 라우팅 (30자 기준)
- 시간 표현 필터링 (금/은 오인 방지)
- 상품명 패턴 우선 체크
- 시간 표현 + 초성/종목명 패턴 지원
- 상품명 필터링 (종목명으로 오인 방지)

### 처리 순서 변경
- 기존: 서비스명 체크 → 종목명 추출
- 변경: 종목명 추출 → 서비스명 체크

