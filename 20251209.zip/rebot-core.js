/**
 * Rebot Core Utilities
 * 기존 챗봇의 핵심 기능들을 rebot 프로젝트에 맞게 최적화
 */

// 전역 변수
window.RebotCore = {
    searchNo: "01",
    isInitialized: false,
    currentOilProductCode: null, // 현재 선택된 유가/상품 종목 코드
    currentExchangeCode: null, // 현재 선택된 금리/환율 코드
    
    // 개발/프로덕션 환경 설정
    config: {
        // 수동 설정 (우선순위 높음)
        // window.REBOT_CONFIG = { useSampleData: true }; 로 설정 가능
        // 자동 감지: localhost, 127.0.0.1, file:// 일 때 개발 환경으로 간주
        isDevelopment: function() {
            // 수동 설정이 있으면 우선 사용
            if (window.REBOT_CONFIG && typeof window.REBOT_CONFIG.useSampleData === 'boolean') {
                return window.REBOT_CONFIG.useSampleData;
            }
            
            // 자동 감지: 호스트명 기반
            const hostname = window.location.hostname;
            const protocol = window.location.protocol;
            
            // 개발 환경 체크
            const isDev = 
                hostname === 'localhost' ||
                hostname === '127.0.0.1' ||
                hostname === '' ||
                protocol === 'file:' ||
                hostname.includes('localhost') ||
                hostname.includes('127.0.0.1');
            
            return isDev;
        },
        useSampleData: function() {
            return this.isDevelopment();
        }
    },
    
    // 인덴트 관리 시스템
    intentManager: {
        rules: [], // JSON 규칙들이 로드될 배열
        isLoaded: false,
        lastUpdated: null
    },
    
    // 기존 챗봇 상수들
    MARKET_DATA: [
        { mktClsf: '5', invstClsf: '1', indTypCd: 'KGG01P', marketType: 'KOSPI', koName: '코스피' },
        { mktClsf: '6', invstClsf: '2', indTypCd: 'QGG01P', marketType: 'KOSDAQ', koName: '코스닥' }
    ],
    UPDOWN_CODE: [
        { code:'051', koNm:'자동차', enNm:'KRXAutos' },
        { code:'052', koNm:'반도체', enNm:'KRXSemicon' },
        { code:'053', koNm:'헬스케어', enNm:'KRXHealthCare' },
        { code:'054', koNm:'은행', enNm:'KRXBanks' },
        { code:'056', koNm:'에너지화학', enNm:'KRXEnergy&Cchem' },
        { code:'057', koNm:'철강', enNm:'KRXSteels' },
        { code:'059', koNm:'방송통신', enNm:'KRXMedia&Telecom' },
        { code:'060', koNm:'건설', enNm:'KRXConstruction' },
        { code:'062', koNm:'증권', enNm:'KRXSecurities' },
        { code:'063', koNm:'기계장비', enNm:'KRXMachin.&Equip' },
        { code:'064', koNm:'보험', enNm:'KRXInsurance' },
        { code:'065', koNm:'운송', enNm:'KRXTransportation' }
    ],
    EU_US_CODE: [
        { code : 'SPI@SPX', name : 'S&P 500', img : 'us.png'},
        { code : 'NAS@IXIC', name : '나스닥', img : 'us.png'},
        { code : 'DJI@DJI', name : '다우산업', img : 'us.png'},
        { code : 'XTR@DAX30', name : '독일 DAX30', img : 'de.png'},
        { code : 'PAS@CAC40', name : '프랑스 CAC40', img : 'fr.png'},
        { code : 'LNS@FTSE100', name : '영국 FTSE100', img : 'gb.png'}
    ],
    ASIA_CODE: [
        { code : 'KI.001', name : '한국 코스피', img : 'kr.png'},
        { code : 'QI.001', name : '한국 코스닥', img : 'kr.png'},
        { code : 'NII@NI225', name : '일본 닛케이', img : 'jp.png'},
        { code : 'HSI@HSI', name : '홍콩 항셍', img : 'hk.png'},
        { code : 'SHS@000001', name : '중국 상해종합', img : 'cn.png'},
        { code : 'TWS@TI01', name : '대만 가권', img : 'tw.png'}
    ],
    CODE_DATA: [
        { clsf : '21', code : 'NYM@CL', name : 'WTI', emoji: '🛢'},
        { clsf : '21', code : 'SPT@DU', name : '두바이', emoji: '🛢'},
        { clsf : '21', code : 'IPE@EB', name : '브렌트', emoji: '🛢'},
        { clsf : '22', code : 'COM@GC', name : '금', emoji: '🥇'},
        { clsf : '22', code : 'COM@SI', name : '은', emoji: '🥈'},
        { clsf : '22', code : 'COM@HG', name : '구리', emoji: '🥉'}
    ],
    EXCN_DATA: [
        { type : 'rp', code : '01', name : '원/달러', crncyCd: 'KRW', emoji: '💵' },
        { type : 'rp', code : '02', name : '엔/달러', crncyCd: 'JPY', emoji: '💴' },
        { type : 'rp', code : '03', name : '유로/달러', crncyCd: 'EUR', emoji: '💶' },
        { type : 'cd', code : '61', name : 'CD', emoji: '🏦' },
        { type : 'cd', code : '12', name : '국고3년', emoji: '🏦' },
        { type : 'cd', code : '14', name : '국고10년', emoji: '🏦' }
    ],
    
    // 초기화 함수
    init: function() {
        if (this.isInitialized) {
            return;
        }
        
        // 인덴트 관리 시스템 초기화
        this.initIntentManager();
        
        this.bindEvents();
        this.showWelcomeMessage();
        this.isInitialized = true;
    },
    
    // 환영 메시지 표시
    showWelcomeMessage: function(serviceName = null) {
        const chatArea = document.getElementById('main-chat-area');
        const welcomeDate = document.getElementById('welcome-date');
        
        if (welcomeDate) {
            const today = new Date();
            const year = today.getFullYear();
            const month = String(today.getMonth() + 1).padStart(2, '0');
            const day = String(today.getDate()).padStart(2, '0');
            welcomeDate.textContent = `${year}년 ${month}월 ${day}일`;
        }
        
        if (chatArea) {
            const welcomeMessage = document.createElement('article');
            welcomeMessage.className = 'prompt__wrapper__query';
            welcomeMessage.setAttribute('data-id', '');
            
            // 서비스명이 있으면 해당 서비스명을, 없으면 기본 메시지를 표시
            const titleText = serviceName || 'KB증권 리봇';
            const contentText = serviceName ? 
                `${serviceName} 정보를 조회합니다...` : 
                '안녕하세요! KB증권 리봇입니다. 원하시는 서비스를 선택하거나 질문을 입력해주세요.';
            
            welcomeMessage.innerHTML = `
                <div class="prompt__cont">
                    <div class="prompt__src sr_only" data-role="">
                        query:
                    </div>
                    <div class="prompt__query_box">
                        <div class="prompt__txt_adjust">
                            <div class="prompt__query_title">${titleText}</div>
                            <div class="prompt__model_chosen">
                                rebot thinking
                                <img src="icons/gr_ic.svg" alt="">
                            </div>
                            <div class="prompt__txt">${contentText}</div>
                        </div>
                    </div>
                </div>
            `;
            
            chatArea.appendChild(welcomeMessage);
            
            // sc__btn__wrapper 추가 (중복 방지)
            const existingScBtn = chatArea.querySelector('.sc__btn__wrapper');
            if (!existingScBtn) {
                const scBtnWrapper = document.createElement('div');
                scBtnWrapper.className = 'sc__btn__wrapper';
                scBtnWrapper.innerHTML = `
                    <button type="button" id="sc-btn" class="sc__btn"><div class="sc__dr__ic"></div></button>
                `;
                chatArea.appendChild(scBtnWrapper);
            }
        }
    },
    
    // 이벤트 바인딩
    bindEvents: function() {
        const self = this;
        
        // 채팅 입력 키보드 이벤트
        $(document).ready(function() {
            $("#content-chat-input").keydown(function(event) {
                var chatInData = self.XSSCheck($("#content-chat-input").val(), 0);
                
                if(event.keyCode == 13){
                    if(chatInData == "") {
                        return;
                    }
                    if(self.searchNo != "03"){
                        $(".topbtn__item").css({"background-color":"#ffffff"});
                    }
                    self.fn_chatBotBtn('srch', 'send');
                }
            });
        });
    }
};

/**
 * XSS 보안 처리 함수
 * @param {string} str - 검증할 문자열
 * @param {number} level - 보안 레벨 (0: 기본, 1: HTML 엔티티 변환)
 * @returns {string} - 검증된 문자열
 */
window.RebotCore.XSSCheck = function(str, level) {
    if (!str) return "";
    
    if (level == undefined || level == 0) {
        // 기본 XSS 방지: 특수문자 제거
        str = str.replace(/\<|\>|\"|\'|\%|\;|\(|\)|\&|\+|\-/g,"");
    } else if (level == 1) {
        // HTML 엔티티 변환
        str = str.replace(/\</g, "&lt;");
        str = str.replace(/\>/g, "&gt;");
    }
    return str;
};

/**
 * 챗봇 서비스 버튼 클릭 처리
 * @param {HTMLElement|string} chk - 클릭된 버튼 요소 또는 'srch'
 * @param {string} serviceChk - 서비스 타입
 */
window.RebotCore.fn_chatBotBtn = function(chk, serviceChk) {
    // 버튼 색상 초기화
    if(chk != "srch" || this.searchNo != "03") {
        $(".topbtn__item").css({"background-color":"#ffffff"});
    }
    
    // 버튼 클릭 효과 (노란색 깜박임)
    if(chk != "srch") {
        $(chk).css({"background-color":"#ffcc00"});
        $(chk).animate({"background-color":"#ffffff"}, 500);
    }
    
    // 입력값 검증 및 전송
    if(serviceChk == "send"){
        var inputValue = this.XSSCheck($("#content-chat-input").val(), 0);
        
        if(inputValue == "") {
            $("#content-chat-input").focus();
            return;
        }
        
        // 입력창 초기화
        $("#content-chat-input").val("");
        
        // 서비스 함수 호출
        this.subCallFunc(inputValue);
    } else {
        // 서비스 버튼 클릭 시
        this.subCallFunc(serviceChk);
    }
};

/**
 * 서비스 함수 호출 (AI 프롬프트 연동 준비)
 * @param {string} serviceChk - 서비스 타입 또는 입력값
 */
window.RebotCore.subCallFunc = function(serviceChk) {
    console.log("서비스 요청:", serviceChk);
    console.log("subCallFunc 호출 스택:", new Error().stack);
    
    // 사용자에게 피드백 제공
    this.showUserFeedback(serviceChk);
    
    // 입력 길이 기준으로 라우팅 결정 (30자 기준)
    // 공백 제거 후 실제 문자 길이로 계산
    const trimmedInput = serviceChk.trim();
    const inputLength = trimmedInput.length;
    const MAX_SERVICE_MATCH_LENGTH = 30; // 서비스 매칭 최대 길이
    
    console.log(`입력 길이: ${inputLength}자 (기준: ${MAX_SERVICE_MATCH_LENGTH}자)`);
    
    // 긴 입력(30자 초과)은 AI 프롬프트로 전달
    if (inputLength > MAX_SERVICE_MATCH_LENGTH) {
        console.log("긴 입력 감지 → AI 프롬프트로 전달");
        this.handleAIQuestion(serviceChk);
        return;
    }
    
    // 짧은 입력(30자 이하)은 기존 서비스 매칭 로직 사용
    // 향후 AI 프롬프트 API 연동을 위한 구조
    if (typeof window.RebotAI !== 'undefined' && window.RebotAI.sendMessage) {
        // AI 프롬프트 연동 (차후 구현)
        window.RebotAI.sendMessage(serviceChk);
    } else {
        // 현재는 기본 동작 (서비스 매칭)
        this.handleServiceRequest(serviceChk);
    }
};

/**
 * 사용자 피드백 표시 (퍼블리싱된 구조 사용)
 */
window.RebotCore.showUserFeedback = function(serviceChk) {
    const userMessageHtml = `
        <div class="prompt__cont">
            <div class="prompt__src sr_only" data-role="">
                user said:
            </div>
            <div class="prompt__txt_box">
                <div class="prompt__txt_adjust">
                    <div class="prompt__timestamp">${this.formatTimeWithPeriod()}</div>
                    <div class="prompt__txt">${serviceChk}</div>
                </div>
            </div>
        </div>
    `;
    
    this.addMessageToChat(userMessageHtml, 'sender');
};

/**
 * 서비스 요청 처리 (인덴트 관리 시스템 통합)
 * @param {string} serviceChk - 서비스 타입
 */
window.RebotCore.handleServiceRequest = function(serviceChk) {
    console.log("=== handleServiceRequest 시작 ===");
    console.log("사용자 입력 분석:", serviceChk);
    
    // 0. 초성 입력 우선 처리 (종목 검색 우선)
    // "ㅅㅅㅈㅈ 시세" 또는 "지금 ㅅㅅㅈㅈ 시세는?" 같은 패턴에서 초성 부분만 추출
    const timeKeywords = ["현재", "지금", "지금은", "오늘"];
    
    // 시간 표현 + 초성 패턴 체크
    const timeChosungPattern = new RegExp(`(?:${timeKeywords.join('|')})\\s+([ㄱ-ㅎ]+)\\s*시세[\\s\\?\\!는이가을를]*`, 'i');
    const timeChosungMatch = serviceChk.trim().match(timeChosungPattern);
    if (timeChosungMatch) {
        const chosungInput = timeChosungMatch[1]; // 초성 부분만 추출
        if (typeof window.KoreanUtils !== 'undefined') {
            // 먼저 기존 시스템 데이터에서 종목 검색
            const stockResult = this.searchStockByInitials(chosungInput);
            if (stockResult) {
                // 여러 종목이 매칭된 경우
                if (stockResult.code === 'MULTIPLE') {
                    this.showMultipleStockOptions(chosungInput, stockResult.data);
                    return;
                }
                
                // 단일 종목 매칭
                console.log(`[시간 표현 + 초성] 초성 매칭 완료: ${chosungInput} -> ${stockResult.name}`);
                this.showBotMessage(`"${chosungInput}" 초성으로 "${stockResult.name}" 종목을 찾았습니다.`, "초성 검색");
                this.getStockPrice(stockResult.name);
                return;
            }
            
            // 종목이 없으면 일반 키워드 검색 (인덴트 규칙 제외)
            const suggestions = this.getKoreanInitialSuggestions(chosungInput, false);
            if (suggestions.length > 0) {
                const bestMatch = suggestions[0];
                this.showBotMessage(`"${chosungInput}" 초성으로 "${bestMatch.keyword}"를 찾았습니다.`, "초성 검색");
                const matchedRule = this.intentManager.rules.find(rule => rule.keywords.includes(bestMatch.keyword));
                if (matchedRule) {
                    this.executeIntentRule(matchedRule, serviceChk);
                    return;
                }
            } else {
                this.showBotMessage(`"${chosungInput}" 초성으로 매칭되는 키워드를 찾을 수 없습니다.`, "초성 검색");
                return;
            }
        } else {
            this.showBotMessage(`"${chosungInput}" 초성 입력을 감지했지만 KoreanUtils가 로드되지 않았습니다.`, "초성 검색");
            return;
        }
    }
    
    // 일반 초성 패턴 체크 (시간 표현 없이)
    const chosungMatch = serviceChk.trim().match(/^([ㄱ-ㅎ]+)\s*(시세|시세조회|주가|현재가)?$/);
    if (chosungMatch) {
        const chosungInput = chosungMatch[1]; // 초성 부분만 추출
        if (typeof window.KoreanUtils !== 'undefined') {
            // 먼저 기존 시스템 데이터에서 종목 검색
            const stockResult = this.searchStockByInitials(chosungInput);
            if (stockResult) {
                // 여러 종목이 매칭된 경우
                if (stockResult.code === 'MULTIPLE') {
                    this.showMultipleStockOptions(chosungInput, stockResult.data);
                    return;
                }
                
                // 단일 종목 매칭
                console.log(`초성 매칭 완료: ${chosungInput} -> ${stockResult.name}, 함수 종료`);
                this.showBotMessage(`"${chosungInput}" 초성으로 "${stockResult.name}" 종목을 찾았습니다.`, "초성 검색");
                this.getStockPrice(stockResult.name);
                return;
            }
            
            // 종목이 없으면 일반 키워드 검색 (인덴트 규칙 제외)
            const suggestions = this.getKoreanInitialSuggestions(chosungInput, false);
            if (suggestions.length > 0) {
                const bestMatch = suggestions[0];
                this.showBotMessage(`"${chosungInput}" 초성으로 "${bestMatch.keyword}"를 찾았습니다.`, "초성 검색");
                const matchedRule = this.intentManager.rules.find(rule => rule.keywords.includes(bestMatch.keyword));
                if (matchedRule) {
                    this.executeIntentRule(matchedRule, serviceChk);
                    return;
                }
            } else {
                this.showBotMessage(`"${chosungInput}" 초성으로 매칭되는 키워드를 찾을 수 없습니다.`, "초성 검색");
                return;
            }
        } else {
            this.showBotMessage(`"${chosungInput}" 초성 입력을 감지했지만 KoreanUtils가 로드되지 않았습니다.`, "초성 검색");
            return;
        }
    }
    
    // 0.5. 시간 표현 + 상품명 + 시세 패턴 최우선 체크 (서비스명 체크보다 먼저)
    // 패턴: "현재/지금/지금은 + [상품명]시세" 또는 "현재/지금/지금은 + [상품명] + 시세"
    // 특수문자(?, ! 등) 허용
    // timeKeywords는 이미 위에서 선언됨
    const commodityNames = [
        { name: "금", code: "COM@GC" },
        { name: "은", code: "COM@SI" },
        { name: "구리", code: "COM@HG" },
        { name: "원유", code: "NYM@CL" }
    ];
    
    // 시간 표현 + 상품명 + 시세 패턴 체크 (특수문자 허용)
    for (const timeKeyword of timeKeywords) {
        for (const commodity of commodityNames) {
            // 패턴 1: "현재 금시세" 또는 "현재 금시세?" (붙어있음, 특수문자 허용)
            const pattern1 = new RegExp(`${timeKeyword}\\s*${commodity.name}시세[\\s\\?\\!]*`, 'i');
            // 패턴 2: "현재 금 시세" 또는 "현재 금 시세?" (공백 있음, 특수문자 허용)
            const pattern2 = new RegExp(`${timeKeyword}\\s*${commodity.name}\\s*시세[\\s\\?\\!]*`, 'i');
            
            if (pattern1.test(serviceChk) || pattern2.test(serviceChk)) {
                console.log(`[패턴 매칭] "${timeKeyword} ${commodity.name}시세" 감지 → 유가/상품 서비스로 직접 이동`);
                this.searchNo = "";
                this.oilProduct("T", commodity.code);
                return;
            }
        }
    }
    
    // 0.5-1. 상품명 + 시세 패턴 체크 (시간 표현 없이, 특수문자 허용)
    const commodityPatterns = [
        { pattern: /금\s*시세[\s\?\!]*|금시세[\s\?\!]*/i, name: "금", code: "COM@GC" },
        { pattern: /은\s*시세[\s\?\!]*|은시세[\s\?\!]*/i, name: "은", code: "COM@SI" },
        { pattern: /구리\s*시세[\s\?\!]*|구리시세[\s\?\!]*/i, name: "구리", code: "COM@HG" },
        { pattern: /원유\s*시세[\s\?\!]*|원유시세[\s\?\!]*/i, name: "원유", code: "NYM@CL" }
    ];
    
    for (const commodity of commodityPatterns) {
        if (commodity.pattern.test(serviceChk)) {
            console.log(`[패턴 매칭] "${commodity.name}" 상품명 패턴 감지 → 유가/상품 서비스로 직접 이동`);
            this.searchNo = "";
            this.oilProduct("T", commodity.code);
            return;
        }
    }
    
    // 0.6. 종목명 + 시세 패턴 우선 체크 (서비스명 체크보다 먼저)
    // "현재 삼성전자 시세는?" 같은 경우 종목명을 먼저 추출하여 서비스명으로 오인되지 않도록 함
    if (/[가-힣a-zA-Z]+.*시세/.test(serviceChk.trim()) || /시세.*[가-힣a-zA-Z]+/.test(serviceChk.trim())) {
        console.log(`[종목명 추출 시도] 입력: "${serviceChk}"`);
        const stockName = this.extractStockNameFromInput(serviceChk);
        console.log(`[종목명 추출 결과] 추출된 종목명: "${stockName}"`);
        if (stockName) {
            // 상품명(금, 은, 구리, 원유)은 종목명으로 인식하지 않음
            const commodityNames = ["금", "은", "구리", "원유"];
            if (commodityNames.includes(stockName)) {
                console.log(`"${stockName}"은 상품명이므로 유가/상품 서비스로 직접 이동 (시간 표현 무관)`);
                // 시간 표현과 관계없이 직접 유가/상품 서비스 호출
                this.searchNo = "";
                // 특정 상품 코드로 상세 조회
                const commodityCodeMap = {
                    "금": "COM@GC",
                    "은": "COM@SI",
                    "구리": "COM@HG",
                    "원유": "NYM@CL"
                };
                const commodityCode = commodityCodeMap[stockName] || "";
                if (commodityCode) {
                    this.oilProduct("T", commodityCode);
                } else {
                    this.oilProduct("", "");
                }
                return;
            } else {
                console.log(`[종목명 추출 성공] "${stockName}" → 종목 시세 조회`);
                this.showBotMessage(`"${stockName}" 시세를 조회하겠습니다...`, "종목 시세");
                this.getStockPrice(stockName);
                return;
            }
        }
    }
    
    // 0.7. 서비스명 체크 (종목명이 추출되지 않은 경우에만)
    // "금 시세", "은 시세", "유가", "상품" 같은 서비스명이 종목명으로 오인되지 않도록 먼저 체크
    if (this.isExactService(serviceChk)) {
        console.log("서비스명 매칭 → 서비스 처리로 이동");
        this.handleExactService(serviceChk);
        return;
    }
    
    
    // 1. 인덴트 관리 시스템에서 규칙 확인
    const intentRule = this.checkIntentRules(serviceChk);
    if (intentRule) {
        console.log("인덴트 규칙 매칭:", intentRule);
        this.executeIntentRule(intentRule, serviceChk);
        return;
    }
    
    // 2. 종목명 + 시세 패턴 재확인 (analyzeUserIntent 전에 한 번 더 체크)
    // "현재 삼성전자 시세는?" 같은 경우 analyzeUserIntent에서 stock_market으로 분류되기 전에 종목명 추출
    if (/[가-힣a-zA-Z]+.*시세/.test(serviceChk.trim()) || /시세.*[가-힣a-zA-Z]+/.test(serviceChk.trim())) {
        const stockName = this.extractStockNameFromInput(serviceChk);
        if (stockName) {
            // 상품명(금, 은, 구리, 원유)은 종목명으로 인식하지 않음
            const commodityNames = ["금", "은", "구리", "원유"];
            if (!commodityNames.includes(stockName)) {
                console.log(`[재확인] 종목명 추출 성공: "${stockName}" → 종목 시세 조회`);
                this.showBotMessage(`"${stockName}" 시세를 조회하겠습니다...`, "종목 시세");
                this.getStockPrice(stockName);
                return;
            }
        }
    }
    
    // 3. 기존 AI 스러운 키워드 분석 및 의도 파악
    const intent = this.analyzeUserIntent(serviceChk);
    console.log("의도 분석 결과:", intent);
    
    // 4. 분석된 의도에 따른 처리
    if (intent.type === "stock_market") {
        this.handleStockMarketIntent(intent);
    } else if (intent.type === "exact_service") {
        this.handleExactService(serviceChk);
    } else if (intent.type === "smart_search") {
        this.handleSmartSearch(serviceChk, intent);
    } else {
        // 일반 검색어 입력
        this.generalSearch(serviceChk);
    }
    
    console.log("=== handleServiceRequest 종료 ===");
};

/**
 * 인덴트 관리 시스템 초기화
 */
window.RebotCore.initIntentManager = function() {
    console.log("인덴트 관리 시스템 초기화 중...");
    
    // 기본 규칙 로드
    this.loadDefaultIntentRules();
    
    // 외부 JSON 파일에서 규칙 로드 시도
    this.loadIntentRulesFromFile();
};

/**
 * 기본 인덴트 규칙 로드
 */
window.RebotCore.loadDefaultIntentRules = function() {
    const defaultRules = [
        {
            "id": "stock_minute_chart",
            "name": "분봉 차트 조회",
            "description": "분봉 관련 키워드 감지",
            "keywords": ["분봉", "단기차트", "실시간차트"],
            "priority": 1,
            "action": {
                "type": "function_call",
                "function": "loadStockMarketMinuteData",
                "params": {},
                "message": "분봉 차트를 분석해드리겠습니다.",
                "serviceName": "주식시장 분봉"
            },
            "enabled": true,
            "createdAt": "2025-01-15T00:00:00Z",
            "updatedAt": "2025-01-15T00:00:00Z"
        },
        {
            "id": "stock_kospi",
            "name": "코스피 조회",
            "description": "코스피 관련 키워드 감지",
            "keywords": ["코스피", "kospi", "KOSPI", "대형주"],
            "priority": 1,
            "action": {
                "type": "function_call",
                "function": "loadStockMarketDataByType",
                "params": {
                    "serviceType": "주식시장 코스피",
                    "buttonText": "코스피"
                },
                "message": "코스피 지수 현황을 분석해드리겠습니다.",
                "serviceName": "주식시장 코스피"
            },
            "enabled": true,
            "createdAt": "2025-01-15T00:00:00Z",
            "updatedAt": "2025-01-15T00:00:00Z"
        },
        {
            "id": "stock_kosdaq",
            "name": "코스닥 조회",
            "description": "코스닥 관련 키워드 감지",
            "keywords": ["코스닥", "kosdaq", "KOSDAQ", "중소형주"],
            "priority": 1,
            "action": {
                "type": "function_call",
                "function": "loadStockMarketDataByType",
                "params": {
                    "serviceType": "주식시장 코스닥",
                    "buttonText": "코스닥"
                },
                "message": "코스닥 지수 현황을 분석해드리겠습니다.",
                "serviceName": "주식시장 코스닥"
            },
            "enabled": true,
            "createdAt": "2025-01-15T00:00:00Z",
            "updatedAt": "2025-01-15T00:00:00Z"
        },
        {
            "id": "stock_period_3m",
            "name": "3개월 차트 조회",
            "description": "3개월 기간 관련 키워드 감지",
            "keywords": ["3개월", "3월", "중기", "분기"],
            "priority": 1,
            "action": {
                "type": "function_call",
                "function": "loadStockMarketDataByType",
                "params": {
                    "serviceType": "주식시장 3개월",
                    "buttonText": "3개월"
                },
                "message": "3개월 차트를 분석해드리겠습니다.",
                "serviceName": "주식시장 3개월"
            },
            "enabled": true,
            "createdAt": "2025-01-15T00:00:00Z",
            "updatedAt": "2025-01-15T00:00:00Z"
        },
        {
            "id": "external_api_call",
            "name": "외부 API 호출 예시",
            "description": "특정 키워드로 외부 API 호출",
            "keywords": ["뉴스", "news", "시장뉴스"],
            "priority": 2,
            "action": {
                "type": "api_call",
                "url": "/ajax/getMarketNews.json",
                "method": "POST",
                "params": {
                    "category": "market",
                    "limit": 10
                },
                "message": "시장 뉴스를 조회하겠습니다.",
                "serviceName": "시장 뉴스"
            },
            "enabled": false, // 예시용으로 비활성화
            "createdAt": "2025-01-15T00:00:00Z",
            "updatedAt": "2025-01-15T00:00:00Z"
        }
    ];
    
    this.intentManager.rules = defaultRules;
    this.intentManager.isLoaded = true;
    this.intentManager.lastUpdated = new Date().toISOString();
    
    console.log("기본 인덴트 규칙 로드 완료:", defaultRules.length, "개");
};

/**
 * 외부 JSON 파일에서 인덴트 규칙 로드
 */
window.RebotCore.loadIntentRulesFromFile = function() {
    // 실제 구현 시 JSON 파일에서 로드
    // fetch('/config/intent-rules.json')
    //     .then(response => response.json())
    //     .then(rules => {
    //         this.intentManager.rules = [...this.intentManager.rules, ...rules];
    //         console.log("외부 인덴트 규칙 로드 완료:", rules.length, "개");
    //     })
    //     .catch(error => {
    //         console.log("외부 인덴트 규칙 로드 실패:", error);
    //     });
    
    console.log("외부 인덴트 규칙 로드 시도 (현재는 비활성화)");
};

/**
 * 인덴트 규칙 확인
 */
window.RebotCore.checkIntentRules = function(userInput) {
    if (!this.intentManager.isLoaded || this.intentManager.rules.length === 0) {
        return null;
    }
    
    const normalizedInput = userInput.toLowerCase().trim();
    
    // 우선순위별로 정렬된 규칙 확인
    const sortedRules = this.intentManager.rules
        .filter(rule => rule.enabled)
        .sort((a, b) => a.priority - b.priority);
    
    for (const rule of sortedRules) {
        // 키워드 매칭 확인 (정확한 매칭 우선)
        let matchedKeyword = rule.keywords.find(keyword => 
            normalizedInput.includes(keyword.toLowerCase())
        );
        
        // 정확한 매칭이 없으면 한글 초성 매칭 시도
        if (!matchedKeyword && typeof window.KoreanUtils !== 'undefined') {
            matchedKeyword = rule.keywords.find(keyword => 
                window.KoreanUtils.matchChosung(normalizedInput, keyword)
            );
        }
        
        if (matchedKeyword) {
            console.log(`인덴트 규칙 매칭: ${rule.name} (키워드: ${matchedKeyword})`);
            return {
                ...rule,
                matchedKeyword: matchedKeyword
            };
        }
    }
    
    return null;
};

/**
 * 인덴트 규칙 실행
 */
window.RebotCore.executeIntentRule = function(rule, userInput) {
    console.log("인덴트 규칙 실행:", rule.name);
    
    const action = rule.action;
    
    // 메시지 표시
    if (action.message) {
        this.showBotMessage(action.message, action.serviceName || "KB증권 리봇");
    }
    
    // 액션 타입별 실행
    switch (action.type) {
        case "function_call":
            this.executeFunctionCall(action, userInput);
            break;
            
        case "api_call":
            this.executeApiCall(action, userInput);
            break;
            
        case "redirect":
            this.executeRedirect(action, userInput);
            break;
            
        case "custom":
            this.executeCustomAction(action, userInput);
            break;
            
        default:
            console.warn("알 수 없는 액션 타입:", action.type);
    }
};

/**
 * 함수 호출 실행
 */
window.RebotCore.executeFunctionCall = function(action, userInput) {
    const functionName = action.function;
    const params = action.params || {};
    
    console.log(`함수 호출: ${functionName}`, params);
    
    if (typeof this[functionName] === 'function') {
        try {
            this[functionName](params.serviceType, params.buttonText);
        } catch (error) {
            console.error(`함수 호출 실패: ${functionName}`, error);
            this.showBotMessage("요청 처리 중 오류가 발생했습니다.", "오류");
        }
    } else {
        console.error(`함수를 찾을 수 없습니다: ${functionName}`);
        this.showBotMessage("요청 처리 중 오류가 발생했습니다.", "오류");
    }
};

/**
 * API 호출 실행
 */
window.RebotCore.executeApiCall = function(action, userInput) {
    const url = action.url;
    const method = action.method || 'POST';
    const params = action.params || {};
    
    console.log(`API 호출: ${method} ${url}`, params);
    
    this.ajaxCall(url, params, (data) => {
        console.log("API 호출 성공:", data);
        this.showComplexResult(action.serviceName || "API 결과", data);
    }, (error) => {
        console.error("API 호출 실패:", error);
        this.showBotMessage("데이터 조회 중 오류가 발생했습니다.", "오류");
    });
};

/**
 * 리다이렉트 실행
 */
window.RebotCore.executeRedirect = function(action, userInput) {
    const url = action.url;
    const target = action.target || '_self';
    
    console.log(`리다이렉트: ${url}`);
    
    if (target === '_blank') {
        window.open(url, '_blank');
    } else {
        window.location.href = url;
    }
};

/**
 * 커스텀 액션 실행
 */
window.RebotCore.executeCustomAction = function(action, userInput) {
    console.log("커스텀 액션 실행:", action);
    
    // 커스텀 액션 로직 구현
    if (action.customLogic) {
        try {
            eval(action.customLogic);
        } catch (error) {
            console.error("커스텀 액션 실행 실패:", error);
        }
    }
};

/**
 * 인덴트 규칙 추가 (관리자용)
 */
window.RebotCore.addIntentRule = function(rule) {
    rule.id = rule.id || `rule_${Date.now()}`;
    rule.createdAt = rule.createdAt || new Date().toISOString();
    rule.updatedAt = new Date().toISOString();
    rule.enabled = rule.enabled !== false; // 기본값 true
    
    this.intentManager.rules.push(rule);
    console.log("인덴트 규칙 추가:", rule.name);
    
    return rule.id;
};

/**
 * 인덴트 규칙 업데이트 (관리자용)
 */
window.RebotCore.updateIntentRule = function(ruleId, updates) {
    const ruleIndex = this.intentManager.rules.findIndex(rule => rule.id === ruleId);
    
    if (ruleIndex !== -1) {
        this.intentManager.rules[ruleIndex] = {
            ...this.intentManager.rules[ruleIndex],
            ...updates,
            updatedAt: new Date().toISOString()
        };
        
        console.log("인덴트 규칙 업데이트:", ruleId);
        return true;
    }
    
    console.warn("인덴트 규칙을 찾을 수 없습니다:", ruleId);
    return false;
};

/**
 * 인덴트 규칙 삭제 (관리자용)
 */
window.RebotCore.deleteIntentRule = function(ruleId) {
    const ruleIndex = this.intentManager.rules.findIndex(rule => rule.id === ruleId);
    
    if (ruleIndex !== -1) {
        const deletedRule = this.intentManager.rules.splice(ruleIndex, 1)[0];
        console.log("인덴트 규칙 삭제:", deletedRule.name);
        return true;
    }
    
    console.warn("인덴트 규칙을 찾을 수 없습니다:", ruleId);
    return false;
};

/**
 * 인덴트 규칙 목록 조회 (관리자용)
 */
window.RebotCore.getIntentRules = function() {
    return this.intentManager.rules;
};

/**
 * 인덴트 규칙 내보내기 (관리자용)
 */
window.RebotCore.exportIntentRules = function() {
    const exportData = {
        version: "1.0",
        exportedAt: new Date().toISOString(),
        rules: this.intentManager.rules
    };
    
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = `intent-rules-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    console.log("인덴트 규칙 내보내기 완료");
};

/**
 * 사용자 의도 분석 (AI 스러운 키워드 매칭)
 */
window.RebotCore.analyzeUserIntent = function(input) {
    const normalizedInput = input.toLowerCase().trim();
    
    // 주식시장 관련 키워드 패턴
    const stockPatterns = {
        // 시간 관련
        timeKeywords: ["분봉", "일봉", "주봉", "월봉", "3개월", "6개월", "1년", "단기", "중기", "장기"],
        // 시장 관련
        marketKeywords: ["코스피", "코스닥", "kospi", "kosdaq", "주식시장", "주가", "차트", "시세"],
        // 분석 관련
        analysisKeywords: ["매매동향", "외국인", "기관", "개인", "거래량", "시장분석", "투자동향"],
        // 종목 관련
        stockKeywords: ["삼성전자", "sk하이닉스", "lg화학", "현대차", "naver", "카카오"]
    };
    
    // 의도 분석 로직
    let intent = {
        type: "general_search",
        confidence: 0,
        keywords: [],
        suggestedAction: null
    };
    
    // 패턴 매칭 및 신뢰도 계산
    let confidence = 0;
    let matchedKeywords = [];
    
    // 시간 키워드 매칭
    stockPatterns.timeKeywords.forEach(keyword => {
        if (normalizedInput.includes(keyword)) {
            confidence += 0.3;
            matchedKeywords.push(keyword);
        }
    });
    
    // 시장 키워드 매칭
    stockPatterns.marketKeywords.forEach(keyword => {
        if (normalizedInput.includes(keyword)) {
            confidence += 0.4;
            matchedKeywords.push(keyword);
        }
    });
    
    // 분석 키워드 매칭
    stockPatterns.analysisKeywords.forEach(keyword => {
        if (normalizedInput.includes(keyword)) {
            confidence += 0.2;
            matchedKeywords.push(keyword);
        }
    });
    
    // 종목 키워드 매칭
    stockPatterns.stockKeywords.forEach(keyword => {
        if (normalizedInput.includes(keyword)) {
            confidence += 0.5;
            matchedKeywords.push(keyword);
        }
    });
    
    // 의도 결정
    if (confidence >= 0.3) {
        intent.type = "stock_market";
        intent.confidence = confidence;
        intent.keywords = matchedKeywords;
        intent.suggestedAction = this.suggestStockMarketAction(matchedKeywords);
    } else if (this.isExactService(input)) {
        intent.type = "exact_service";
        intent.confidence = 1.0;
    } else if (this.hasSmartSearchPattern(input)) {
        intent.type = "smart_search";
        intent.confidence = 0.7;
        intent.keywords = matchedKeywords;
    }
    
    return intent;
};

/**
 * 주식시장 의도 처리 (AI 스러운 응답 적용)
 */
window.RebotCore.handleStockMarketIntent = function(intent) {
    console.log("주식시장 의도 감지:", intent);
    
    // AI 스러운 응답 생성
    const aiResponse = this.generateAIResponse(intent, "");
    const enhancedMessage = this.enhanceBotMessage(aiResponse, intent, "");
    
    // 키워드 기반 액션 제안
    const action = intent.suggestedAction;
    
    if (action.type === "minute_chart") {
        this.showBotMessage(enhancedMessage, "주식시장 분봉");
        this.loadStockMarketMinuteData();
    } else if (action.type === "kospi") {
        this.showBotMessage(enhancedMessage, "주식시장 코스피");
        this.loadStockMarketDataByType("주식시장 코스피", "코스피");
    } else if (action.type === "kosdaq") {
        this.showBotMessage(enhancedMessage, "주식시장 코스닥");
        this.loadStockMarketDataByType("주식시장 코스닥", "코스닥");
    } else if (action.type === "period_chart") {
        this.showBotMessage(enhancedMessage, `주식시장 ${action.period}`);
        this.loadStockMarketDataByType(`주식시장 ${action.period}`, action.period);
    } else {
        // 기본 주식시장 정보
        this.showBotMessage(enhancedMessage, "주식시장");
        this.stockMarket("M", "0");
    }
};

/**
 * 주식시장 액션 제안
 */
window.RebotCore.suggestStockMarketAction = function(keywords) {
    // 분봉 관련
    if (keywords.some(k => ["분봉", "단기"].includes(k))) {
        return { type: "minute_chart", period: "분봉" };
    }
    
    // 기간 관련
    if (keywords.some(k => ["3개월"].includes(k))) {
        return { type: "period_chart", period: "3개월" };
    }
    if (keywords.some(k => ["6개월"].includes(k))) {
        return { type: "period_chart", period: "6개월" };
    }
    if (keywords.some(k => ["1년", "장기"].includes(k))) {
        return { type: "period_chart", period: "1년" };
    }
    
    // 시장 관련
    if (keywords.some(k => ["코스피", "kospi"].includes(k))) {
        return { type: "kospi" };
    }
    if (keywords.some(k => ["코스닥", "kosdaq"].includes(k))) {
        return { type: "kosdaq" };
    }
    
    // 기본 주식시장
    return { type: "general_stock" };
};

/**
 * 정확한 서비스명 체크 (퍼지 매칭 포함)
 */
window.RebotCore.isExactService = function(input) {
    // 시간 표현 키워드 (이런 단어가 포함되면 "금", "은" 같은 한 글자 서비스명 매칭 제외)
    const timeKeywords = ["지금", "현재", "오늘", "지금은", "현재는", "오늘은", "지금의", "현재의", "오늘의"];
    const hasTimeKeyword = timeKeywords.some(keyword => input.includes(keyword));
    
    // 기존 정확한 매칭 시도
    const normalized = input.replace(/\s*\|\s*/g, '/').replace(/\s+/g, '');
    
    const exactServices = [
        "주식시장", "업종/종목등락", "종목현재가", "글로벌증시",
        "유가/상품", "금리/환율", "KB데일리", "최신리포트",
        "캘린더", "애널리스트"
    ];
    
    // 정규화된 값으로 비교
    const matchResult = exactServices.some(service => {
        const normalizedService = service.replace(/\s*\|\s*/g, '/').replace(/\s+/g, '');
        return normalized === normalizedService || input === service;
    });
    
    // 기존 특별 처리 (단, 시간 표현이 포함된 경우 "금", "은" 단독 매칭 제외)
    if (matchResult) {
        return true;
    }
    
    // "유가"와 "상품"이 모두 포함된 경우만 매칭 (시간 표현 무관)
    if (input.includes("유가") && input.includes("상품")) {
        return true;
    }
    
    // "금리"와 "환율"이 모두 포함된 경우만 매칭
    if (input.includes("금리") && input.includes("환율")) {
        return true;
    }
    
    // "KB"와 "데일리"가 모두 포함된 경우만 매칭
    if (input.includes("KB") && input.includes("데일리")) {
        return true;
    }
    
    // "최신"과 "리포트"가 모두 포함된 경우만 매칭
    if (input.includes("최신") && input.includes("리포트")) {
        return true;
    }
    
    // "금", "은" 단독 매칭은 시간 표현이 포함된 경우 제외
    if (hasTimeKeyword) {
        // 시간 표현이 포함된 경우 "금", "은" 단독 매칭 제외
        if (input.trim() === "금" || input.trim() === "은" || 
            input.includes(" 금 ") || input.includes(" 은 ") ||
            input.startsWith("금 ") || input.startsWith("은 ") ||
            input.endsWith(" 금") || input.endsWith(" 은")) {
            console.log(`[서비스 매칭 제외] 시간 표현("${timeKeywords.find(k => input.includes(k))}")이 포함되어 있어 "금"/"은" 매칭 제외`);
            return false;
        }
    }
    
    // 퍼지 매칭 시도 (임계값 0.7)
    if (typeof window.RebotUtils !== 'undefined') {
        const fuzzyMatch = this.fuzzyMatchService(input, 0.7);
        if (fuzzyMatch) {
            return true;
        }
    }
    
    return false;
};

/**
 * 정확한 서비스 처리 (퍼지 매칭 포함)
 */
window.RebotCore.handleExactService = function(serviceChk) {
    console.log("handleExactService 호출됨:", serviceChk);
    
    // 먼저 퍼지 매칭 시도 (임계값 0.65)
    if (typeof window.RebotUtils !== 'undefined') {
        const fuzzyMatch = this.fuzzyMatchService(serviceChk, 0.65);
        if (fuzzyMatch && fuzzyMatch.service) {
            console.log(`[퍼지 매칭 실행] ${fuzzyMatch.service.name} (점수: ${fuzzyMatch.score.toFixed(2)})`);
            fuzzyMatch.service.action.call(this);
            return;
        }
    }
    
    // 기존 정확한 매칭 로직
    const normalized = serviceChk.replace(/\s*\|\s*/g, '/').replace(/\s+/g, '');
    console.log("정규화된 서비스명:", normalized);
    
    if(serviceChk == "주식시장" || normalized == "주식시장"){
        this.searchNo = "";
        this.stockMarket("M","0");
    }else if(serviceChk == "업종/종목등락" || normalized == "업종/종목등락" || 
             serviceChk == "업종 | 종목 등락" || 
             (serviceChk.includes("업종") && serviceChk.includes("종목") && serviceChk.includes("등락"))){
        console.log("업종/종목 등락 서비스 호출됨");
        this.searchNo = "";
        this.typeUpDown("", "K");
    }else if(serviceChk == "종목현재가" || normalized == "종목현재가"){
        this.searchNo = "03";
        this.stockPrice("F", "");
    }else if(serviceChk == "글로벌증시"){
        this.searchNo = "";
        var toHours = new Date().getHours();
        var code = (0 <= toHours && toHours < 12) ? "us" : "asia";
        this.globalMarket("", code);
    }else if(serviceChk == "유가/상품" || normalized == "유가/상품" || 
             serviceChk == "유가 및 상품" || serviceChk.includes("유가") && serviceChk.includes("상품")){
        this.searchNo = "";
        this.oilProduct("", "");
    }else if(serviceChk == "금리/환율" || normalized == "금리/환율" || 
             serviceChk == "금리 및 환율" || (serviceChk.includes("금리") && serviceChk.includes("환율"))){
        this.searchNo = "";
        this.exchange("", "");
    }else if(serviceChk == "KB데일리" || normalized == "KB데일리" || 
             serviceChk == "KB 데일리" || (serviceChk.includes("KB") && serviceChk.includes("데일리"))){
        this.searchNo = "";
        this.kbDaily("", "first");
    }else if(serviceChk == "최신리포트" || normalized == "최신리포트" || 
             serviceChk == "최신 리포트" || (serviceChk.includes("최신") && serviceChk.includes("리포트"))){
        this.searchNo = "";
        this.todayReport();
    }else if(serviceChk == "캘린더"){
        this.searchNo = "";
        this.calendar("", "");
    }else if(serviceChk == "애널리스트"){
        this.searchNo = "";
        this.analyst("", "");
    }
};

/**
 * 스마트 검색 패턴 체크
 */
window.RebotCore.hasSmartSearchPattern = function(input) {
    const smartPatterns = [
        /^\d+$/,  // 숫자만
        /[가-힣]{2,4}$/,  // 한국어 2-4글자
        /^[A-Z]{2,6}$/,  // 영문 대문자 2-6글자 (종목코드)
        /^[ㄱ-ㅎ]+$/,  // 한글 초성만
        /^[ㄱ-ㅎㅏ-ㅣ]+$/,  // 한글 초성 + 모음
        /[가-힣a-zA-Z]+.*시세/,  // 종목명 + 시세 패턴
        /시세.*[가-힣a-zA-Z]+/  // 시세 + 종목명 패턴
    ];
    
    return smartPatterns.some(pattern => pattern.test(input.trim()));
};

/**
 * 퍼지 매칭으로 서비스 찾기
 * @param {string} input - 사용자 입력
 * @param {number} threshold - 임계값 (0.0 ~ 1.0, 기본값 0.65)
 * @returns {Object|null} - 매칭된 서비스 정보 { service, score } 또는 null
 */
window.RebotCore.fuzzyMatchService = function(input, threshold = 0.65) {
    if (!input || typeof window.RebotUtils === 'undefined') {
        return null;
    }
    
    // 시간 표현 키워드 (이런 단어가 포함되면 "금", "은" 같은 한 글자 서비스명 매칭 제외)
    const timeKeywords = ["지금", "현재", "오늘", "지금은", "현재는", "오늘은", "지금의", "현재의", "오늘의"];
    
    // 입력에서 시간 표현 포함 여부 체크
    const hasTimeKeyword = timeKeywords.some(keyword => input.includes(keyword));
    
    // 서비스 정의 (이름, 패턴, 액션)
    const services = [
        {
            name: "주식시장",
            patterns: ["주식시장", "주식", "시장", "코스피", "코스닥"],
            action: () => { this.searchNo = ""; this.stockMarket("M", "0"); }
        },
        {
            name: "업종/종목등락",
            patterns: ["업종", "종목", "등락", "상승", "하락", "업종등락", "종목등락"],
            action: () => { this.searchNo = ""; this.typeUpDown("", "K"); }
        },
        {
            name: "종목현재가",
            patterns: ["종목현재가", "현재가", "주가", "시세"],
            action: () => { this.searchNo = "03"; this.stockPrice("F", ""); }
        },
        {
            name: "글로벌증시",
            patterns: ["글로벌증시", "글로벌", "세계증시", "해외증시"],
            action: () => {
                this.searchNo = "";
                const toHours = new Date().getHours();
                const code = (0 <= toHours && toHours < 12) ? "us" : "asia";
                this.globalMarket("", code);
            }
        },
        {
            name: "유가/상품",
            patterns: ["유가", "상품", "원유", "금", "은", "구리"],
            action: () => { this.searchNo = ""; this.oilProduct("", ""); },
            // 한 글자 패턴 목록 (시간 표현과 충돌 가능)
            singleCharPatterns: ["금", "은"]
        },
        {
            name: "금리/환율",
            patterns: ["금리", "환율", "금리환율", "원달러", "엔달러", "유로달러"],
            action: () => { this.searchNo = ""; this.exchange("", ""); }
        },
        {
            name: "KB데일리",
            patterns: ["KB데일리", "KB", "데일리", "일일", "daily"],
            action: () => { this.searchNo = ""; this.kbDaily("", "first"); }
        },
        {
            name: "최신리포트",
            patterns: ["최신리포트", "최신", "리포트", "보고서", "report"],
            action: () => { this.searchNo = ""; this.todayReport(); }
        },
        {
            name: "캘린더",
            patterns: ["캘린더", "달력", "일정", "calendar"],
            action: () => { this.searchNo = ""; this.calendar("", ""); }
        },
        {
            name: "애널리스트",
            patterns: ["애널리스트", "분석가", "analyst"],
            action: () => { this.searchNo = ""; this.analyst("", ""); }
        }
    ];
    
    let bestMatch = { service: null, score: 0 };
    
    for (const service of services) {
        // 패턴 매칭 점수 계산
        let patternScore = 0;
        let matchedPatterns = 0;
        
        for (const pattern of service.patterns) {
            // 한 글자 패턴("금", "은")이고 시간 표현이 포함된 경우 제외
            if (service.singleCharPatterns && service.singleCharPatterns.includes(pattern)) {
                if (hasTimeKeyword) {
                    console.log(`[퍼지 매칭 스킵] "${pattern}" 패턴은 시간 표현("${timeKeywords.find(k => input.includes(k))}")이 포함되어 있어 제외`);
                    continue;
                }
                // 한 글자 패턴은 정확한 포함만 허용 (부분 매칭 제외)
                if (!input.includes(pattern) && !input.includes(pattern + " ") && !input.includes(" " + pattern)) {
                    continue;
                }
            }
            
            // 정규화된 유사도 계산
            const similarity = window.RebotUtils.normalizedSimilarity(input, pattern);
            const partialScore = window.RebotUtils.partialMatchScore(input, pattern);
            const combinedScore = Math.max(similarity, partialScore);
            
            if (combinedScore > 0.5) {
                patternScore += combinedScore;
                matchedPatterns++;
            }
        }
        
        // 패턴 점수 평균화
        const avgPatternScore = matchedPatterns > 0 ? patternScore / matchedPatterns : 0;
        
        // 전체 유사도 계산 (서비스 이름과 직접 비교)
        const nameSimilarity = window.RebotUtils.normalizedSimilarity(input, service.name);
        
        // 최종 점수 = 패턴 매칭 점수 * 0.7 + 이름 유사도 * 0.3
        let finalScore = avgPatternScore * 0.7 + nameSimilarity * 0.3;
        
        // 키워드 포함 보너스
        if (service.patterns.some(p => input.includes(p))) {
            finalScore += 0.1;
        }
        
        if (finalScore > bestMatch.score && finalScore >= threshold) {
            bestMatch = { service, score: Math.min(finalScore, 1.0) };
        }
    }
    
    return bestMatch.score >= threshold ? bestMatch : null;
};

/**
 * 스마트 검색 처리
 */
window.RebotCore.handleSmartSearch = function(input, intent) {
    console.log("스마트 검색 처리:", input, intent);
    
    // 초성 입력은 handleServiceRequest에서 이미 처리됨
    
    // 한글 초성 + 모음 입력된 경우
    if (/^[ㄱ-ㅎㅏ-ㅣ]+$/.test(input.trim())) {
        if (typeof window.KoreanUtils !== 'undefined') {
            const suggestions = this.getKoreanInitialSuggestions(input);
            if (suggestions.length > 0) {
                const bestMatch = suggestions[0];
                this.showBotMessage(`"${input}"로 "${bestMatch.keyword}"를 찾았습니다.`, "초성 검색");
                const matchedRule = this.intentManager.rules.find(rule => rule.keywords.includes(bestMatch.keyword));
                if (matchedRule) {
                    this.executeIntentRule(matchedRule, input);
                    return;
                }
            } else {
                this.showBotMessage(`"${input}"로 매칭되는 키워드를 찾을 수 없습니다.`, "초성 검색");
                return;
            }
        } else {
            this.showBotMessage(`"${input}" 초성 입력을 감지했지만 KoreanUtils가 로드되지 않았습니다.`, "초성 검색");
            return;
        }
    }
    
    // 종목명 + 시세 패턴 처리
    if (/[가-힣a-zA-Z]+.*시세/.test(input.trim()) || /시세.*[가-힣a-zA-Z]+/.test(input.trim())) {
        const stockName = this.extractStockNameFromInput(input);
        if (stockName) {
            this.showBotMessage(`"${stockName}" 시세를 조회하겠습니다...`, "종목 시세");
            this.getStockPrice(stockName);
            return;
        }
    }
    
    // 숫자만 입력된 경우 (종목코드 가능성)
    if (/^\d+$/.test(input.trim())) {
        this.showBotMessage(`종목코드 "${input}"를 검색하겠습니다...`, "종목 검색");
        this.searchStockByCode(input);
    }
    // 한국어 2-4글자 (종목명 가능성)
    else if (/[가-힣]{2,4}$/.test(input.trim())) {
        this.showBotMessage(`종목명 "${input}"을 검색하겠습니다...`, "종목 검색");
        this.searchStockByName(input);
    }
    // 영문 대문자 (종목코드 가능성)
    else if (/^[A-Z]{2,6}$/.test(input.trim())) {
        this.showBotMessage(`종목코드 "${input}"를 검색하겠습니다...`, "종목 검색");
        this.searchStockByCode(input);
    }
    else {
        this.generalSearch(input);
    }
};

/**
 * 종목코드로 검색
 */
window.RebotCore.searchStockByCode = function(code) {
    // 종목코드 검색 로직 (실제 API 연동 가능)
    this.showBotMessage(`종목코드 ${code}에 대한 정보를 조회합니다...`, "종목 검색");
    // 실제 구현 시 종목 API 호출
};

/**
 * 종목명으로 검색
 */
window.RebotCore.searchStockByName = function(name) {
    // 종목명 검색 로직 (실제 API 연동 가능)
    this.showBotMessage(`종목명 ${name}에 대한 정보를 조회합니다...`, "종목 검색");
    // 실제 구현 시 종목 API 호출
};

/**
 * 한글 초성 제안 생성
 */
window.RebotCore.getKoreanInitialSuggestions = function(input, includeIntentRules = true) {
    if (typeof window.KoreanUtils === 'undefined') {
        console.warn('KoreanUtils가 로드되지 않았습니다.');
        return [];
    }
    
    // 기존 시스템의 종목 데이터에서 키워드 추출
    let allKeywords = [];
    
    // h_KSPKSDCODE에서 종목명 추출 (항상 포함)
    if (typeof window.h_KSPKSDCODE !== 'undefined') {
        const stockNames = window.h_KSPKSDCODE.map(stock => stock[1]);
        allKeywords.push(...stockNames);
    }
    
    // 인덴트 규칙에서 키워드 추출 (옵션에 따라)
    if (includeIntentRules) {
        this.intentManager.rules.forEach(rule => {
            if (rule.enabled && rule.keywords) {
                allKeywords.push(...rule.keywords);
            }
        });
    }
    
    // 중복 제거
    const uniqueKeywords = [...new Set(allKeywords)];
    
    // KoreanUtils를 사용하여 제안 생성
    return window.KoreanUtils.getChosungSuggestions(input, uniqueKeywords);
};

/**
 * 여러 종목 옵션 표시
 */
window.RebotCore.showMultipleStockOptions = function(initials, stocks) {
    console.log(`"${initials}" 초성으로 ${stocks.length}개 종목이 매칭되었습니다.`);
    
    // 버튼 HTML 생성 (onclick 제거, bindComplexResultEvents에서 처리)
    let buttonsHtml = '';
    stocks.forEach((stock, index) => {
        buttonsHtml += `
            <div class="query__rl__btn__wrapper__sm">
                <button type="button" class="query__rl__it__sm" data-stock-name="${stock.name}" data-stock-code="${stock.code}">
                    ${stock.name} (${stock.code})
                </button>
            </div>
        `;
    });
    
    const messageHtml = `
        <div class="prompt__txt">
            "${initials}" 초성으로 ${stocks.length}개 종목이 매칭되었습니다.<br>
            원하는 종목을 선택해주세요:
        </div>
        <div id="query-rl-btn-sm" class="query__rl__btn__sm">
            ${buttonsHtml}
        </div>
    `;
    
    // 복합 결과 표시
    this.showComplexResult("종목 선택", {
        content: messageHtml,
        showActionButtons: false,
        exlinks: false,
        relatedButtons: [],
        smallButtons: []
    });
};

/**
 * 종목 옵션에서 선택된 종목 처리
 */
window.RebotCore.selectStockFromOptions = function(stockName) {
    console.log(`선택된 종목: ${stockName}`);
    this.showBotMessage(`"${stockName}" 시세를 조회하겠습니다...`, "종목 시세");
    this.getStockPrice(stockName);
};

/**
 * 차트 기간 버튼 클릭 처리
 */
window.RebotCore.handleChartPeriodClick = function(period, container) {
    console.log(`=== 차트 기간 버튼 클릭 시작 ===`);
    console.log(`클릭된 기간: ${period}`);
    console.log(`컨테이너:`, container);
    
    // 컨테이너에서 종목명과 종목코드 추출
    const titleElement = container.querySelector('.prompt__query_title');
    console.log(`제목 요소:`, titleElement);
    
    if (!titleElement) {
        console.log('종목명을 찾을 수 없습니다.');
        return;
    }
    
    const titleText = titleElement.textContent.trim();
    console.log(`제목 텍스트: "${titleText}"`);
    
    // "삼성전자 시세" -> "삼성전자"
    const stockName = titleText.replace(' 시세', '');
    console.log(`추출된 종목명: "${stockName}"`);
    
    console.log(`차트 기간 조회: ${stockName} - ${period}`);
    
    // 종목코드 조회
    const stockCode = this.getStockCodeByName(stockName);
    console.log(`조회된 종목코드: ${stockCode}`);
    
    if (!stockCode) {
        this.showBotMessage(`"${stockName}" 종목코드를 찾을 수 없습니다.`, "차트 조회");
        return;
    }
    
    // 차트 조회 메시지 표시
    this.showBotMessage(`"${stockName}" ${period} 차트를 조회하겠습니다...`, "차트 조회");
    
    // 차트 API 호출 (현재는 샘플 데이터 사용)
    this.callChartAPI(stockCode, stockName, period);
    console.log(`=== 차트 기간 버튼 클릭 완료 ===`);
};

/**
 * 차트 API 호출
 */
window.RebotCore.callChartAPI = function(stockCode, stockName, period) {
    console.log(`차트 API 호출: ${stockCode} (${stockName}) - ${period}`);
    
    // 기간별 API 파라미터 설정
    const periodMapping = {
        "분봉": "1",      // 1일
        "3개월": "90",    // 90일
        "6개월": "180",   // 180일
        "1년": "365"      // 365일
    };
    
    const apiPeriod = periodMapping[period] || "1";
    
    const payload = {
        stockCode: stockCode,
        marketType: "0",
        chartYn: "Y",
        period: apiPeriod,
        isUniv: "true"
    };
    
    console.log(`차트 API 페이로드:`, payload);
    
    // 실제 API 호출 (현재는 샘플 데이터 사용, 실제 구현에서는 ajaxCall 사용)
    this.ajaxCall({
        url: '/api/getChatBotStockChart.json',
        method: 'POST',
        data: payload,
        success: (response) => {
            console.log(`차트 API 응답:`, response);
            this.showChartResult(stockCode, stockName, period, response);
        },
        error: (error) => {
            console.log(`차트 API 오류:`, error);
            // 오류 시 샘플 데이터 사용
            const chartData = this.getSampleChartData(stockCode, period);
            this.showChartResult(stockCode, stockName, period, chartData);
        }
    });
};

/**
 * 샘플 차트 데이터 생성
 */
window.RebotCore.getSampleChartData = function(stockCode, period) {
    const baseData = {
        stockCode: stockCode,
        period: period,
        chartUrl: `https://chart.example.com/chart?code=${stockCode}&period=${period}`,
        currentPrice: "95,100",
        change: "+3,500",
        changeRate: "+3.82%",
        volume: "17,880,518",
        amount: "1,677,869"
    };
    
    // 기간별 특화 데이터
    switch(period) {
        case "분봉":
            return {
                ...baseData,
                description: "실시간 분봉 차트",
                timeRange: "최근 1일"
            };
        case "3개월":
            return {
                ...baseData,
                description: "3개월 일봉 차트",
                timeRange: "최근 3개월"
            };
        case "6개월":
            return {
                ...baseData,
                description: "6개월 일봉 차트", 
                timeRange: "최근 6개월"
            };
        case "1년":
            return {
                ...baseData,
                description: "1년 일봉 차트",
                timeRange: "최근 1년"
            };
        default:
            return baseData;
    }
};

/**
 * 차트 결과 표시
 */
window.RebotCore.showChartResult = function(stockCode, stockName, period, data) {
    console.log(`차트 결과 표시: ${stockName} ${period}`, data);
    
    // API 응답 데이터 처리
    let chartData = data;
    
    // API 응답이 있는 경우 실제 데이터 사용
    if (data && data.response) {
        const response = data.response;
        chartData = {
            chartUrl: response.chartUrl || `https://chart.example.com/chart?code=${stockCode}&period=${period}`,
            currentPrice: this.formatNumber(response.last || response.currentPrice),
            change: response.change || "+0",
            changeRate: response.changeRate || "+0.00%",
            volume: this.formatNumber(response.volume),
            amount: this.formatNumber(response.amount),
            timeRange: this.getTimeRangeDescription(period),
            description: this.getPeriodDescription(period),
            high: this.formatNumber(response.high),
            low: this.formatNumber(response.low),
            openPrice: this.formatNumber(response.open),
            preClose: this.formatNumber(response.preClose)
        };
    }
    
    // 변화량 색상 설정
    const isUp = chartData.change && chartData.change.startsWith('+');
    const changeColor = isUp ? '#e74c3c' : '#3498db';
    const changeIcon = isUp ? '▲' : '▽';
    
    const chartHtml = `
        <div class="chatOutTd">
            <span>
                ${chartData.chartUrl ? `
                    <a id="chatBotChart" href="javascript:void(0)">
                        <img src="${chartData.chartUrl}" width="400px" height="250px" alt="${stockName} ${period} 차트">
                    </a>
                ` : ''}
                <br>
                <li class="font_B">${stockName} ${period} 차트</li>
                <li class="font_B c_rd" style="color: ${changeColor}">
                    <span class="f18">${chartData.currentPrice}</span> ${changeIcon}${chartData.change} ${chartData.changeRate}
                </li>
                <br>
                - 기간: ${chartData.timeRange}<br>
                ${chartData.high ? `- 고가/저가: ${chartData.high} / ${chartData.low}<br>` : ''}
                ${chartData.openPrice ? `- 시가/전일: ${chartData.openPrice} / ${chartData.preClose}<br>` : ''}
                - 거래량: ${chartData.volume}<br>
                - 거래대금: ${chartData.amount}백만<br>
                - 설명: ${chartData.description}<br>
                ----------------------
            </span>
        </div>
    `;
    
    // 복합 결과 표시 (차트 기간 버튼 포함)
    this.showComplexResult(`${stockName} ${period} 차트`, {
        content: chartHtml,
        showActionButtons: false,
        exlinks: false,
        relatedButtons: [],
        smallButtons: [
            "분봉",
            "3개월", 
            "6개월",
            "1년"
        ]
    });
};

/**
 * 기간별 시간 범위 설명
 */
window.RebotCore.getTimeRangeDescription = function(period) {
    const descriptions = {
        "분봉": "최근 1일",
        "3개월": "최근 3개월",
        "6개월": "최근 6개월",
        "1년": "최근 1년"
    };
    return descriptions[period] || "기간 미지정";
};

/**
 * 기간별 설명
 */
window.RebotCore.getPeriodDescription = function(period) {
    const descriptions = {
        "분봉": "실시간 분봉 차트",
        "3개월": "3개월 일봉 차트",
        "6개월": "6개월 일봉 차트",
        "1년": "1년 일봉 차트"
    };
    return descriptions[period] || "차트 정보";
};

/**
 * 기존 시스템 데이터를 활용한 종목 검색
 */
window.RebotCore.searchStockByInitials = function(initials) {
    console.log(`초성 검색 시작: "${initials}"`);
    
    if (typeof window.KoreanUtils === 'undefined' || typeof window.h_KSPKSDCODE === 'undefined') {
        console.log('KoreanUtils 또는 h_KSPKSDCODE가 로드되지 않음');
        return null;
    }
    
    console.log(`h_KSPKSDCODE 데이터 개수: ${window.h_KSPKSDCODE.length}`);
    
    // 원본 데이터에서 초성 매칭 검색
    const matches = [];
    
    for (const stock of window.h_KSPKSDCODE) {
        const stockCode = stock[0];
        const stockName = stock[1];
        
        // 한글 종목명만 처리 (영문 종목명 제외)
        if (stockName && /[가-힣]/.test(stockName)) {
            const stockChosung = window.KoreanUtils.extractChosung(stockName);
            
            if (window.KoreanUtils.matchChosung(initials, stockName)) {
                const confidence = window.KoreanUtils.calculateChosungConfidence(initials, stockChosung);
                matches.push({
                    code: stockCode,
                    name: stockName,
                    chosung: stockChosung,
                    confidence: confidence,
                    data: stock
                });
            }
        }
    }
    
    // 신뢰도 순으로 정렬
    matches.sort((a, b) => b.confidence - a.confidence);
    
    if (matches.length === 0) {
        console.log(`"${initials}" 초성으로 매칭되는 종목을 찾을 수 없습니다.`);
        return null;
    } else if (matches.length === 1) {
        const bestMatch = matches[0];
        console.log(`원본 데이터에서 단일 매칭 발견: ${bestMatch.name} (${bestMatch.code}) - 신뢰도: ${bestMatch.confidence}`);
        return bestMatch;
    } else {
        console.log(`원본 데이터에서 ${matches.length}개 매칭 발견:`, matches.slice(0, 5).map(m => `${m.name}(${m.confidence})`));
        return {
            code: 'MULTIPLE',
            name: 'MULTIPLE_MATCH',
            data: matches,
            confidence: matches[0].confidence
        };
    }
};

/**
 * 입력에서 종목명 추출
 */
window.RebotCore.extractStockNameFromInput = function(input) {
    const trimmedInput = input.trim();
    
    // 상품명 필터링 (금, 은, 구리, 원유는 종목명으로 인식하지 않음)
    const commodityNames = ["금", "은", "구리", "원유"];
    const timeKeywords = ["현재", "지금", "지금은", "오늘"];
    
    // 패턴 1-1: "시간 표현 + 초성 시세" (예: "지금 ㅅㅅㅈㅈ 시세는?")
    const timeChosungPattern = new RegExp(`(?:${timeKeywords.join('|')})\\s+([ㄱ-ㅎ]+)\\s*시세[\\s\\?\\!는이가을를]*`, 'i');
    const timeChosungMatch = trimmedInput.match(timeChosungPattern);
    if (timeChosungMatch) {
        const chosungInput = timeChosungMatch[1];
        // 초성으로 종목 검색
        const stockResult = this.searchStockByInitials(chosungInput);
        if (stockResult) {
            return stockResult.name;
        }
        return null;
    }
    
    // 패턴 1-2: "초성 시세" (예: "ㅅㅅㅈㅈ 시세")
    const chosungPattern = /^([ㄱ-ㅎ]+)\s*시세[\s\?\!는이가을를]*$/;
    const chosungMatch = trimmedInput.match(chosungPattern);
    if (chosungMatch) {
        const chosungInput = chosungMatch[1];
        // 초성으로 종목 검색
        const stockResult = this.searchStockByInitials(chosungInput);
        if (stockResult) {
            return stockResult.name;
        }
        return null;
    }
    
    // 시간 표현 + 종목명 + 시세 패턴 우선 체크
    // "현재 삼성전자 시세는?" 같은 경우 "삼성전자"를 추출
    // timeKeywords는 함수 상단에서 선언됨
    // 패턴: 시간표현 + 공백 + 종목명(한글/영문) + 공백(선택) + 시세 + 조사/특수문자(선택)
    const timeStockPattern = new RegExp(`(?:${timeKeywords.join('|')})\\s+([가-힣a-zA-Z0-9]+)\\s*시세[\\s\\?\\!는이가을를]*`, 'i');
    const timeStockMatch = trimmedInput.match(timeStockPattern);
    if (timeStockMatch) {
        const stockName = timeStockMatch[1];
        console.log(`[종목명 추출] 시간 표현 패턴 매칭: "${stockName}"`);
        // 상품명이면 null 반환 (종목명이 아님)
        if (commodityNames.includes(stockName)) {
            console.log(`[종목명 추출] 상품명으로 판단되어 제외: "${stockName}"`);
            return null;
        }
        console.log(`[종목명 추출] 종목명으로 판단: "${stockName}"`);
        return stockName;
    }
    
    // "종목명 시세" 패턴 (시세 뒤에 다른 문자 허용: "는?", "이?", "가?", "을?", "를?" 등)
    const stockNamePattern1 = /([가-힣a-zA-Z]+)\s*시세[\s\?\!는이가을를]*/;
    const match1 = trimmedInput.match(stockNamePattern1);
    if (match1) {
        const extractedName = match1[1];
        // 시간 표현 키워드는 제외
        if (timeKeywords.includes(extractedName)) {
            return null;
        }
        // 상품명이면 null 반환 (종목명이 아님)
        if (commodityNames.includes(extractedName)) {
            return null;
        }
        return extractedName;
    }
    
    // "시세 종목명" 패턴 (시세 뒤에 다른 문자 허용)
    const stockNamePattern2 = /시세[\s\?\!는이가을를]*\s*([가-힣a-zA-Z]+)/;
    const match2 = trimmedInput.match(stockNamePattern2);
    if (match2) {
        const extractedName = match2[1];
        // 상품명이면 null 반환 (종목명이 아님)
        if (commodityNames.includes(extractedName)) {
            return null;
        }
        return extractedName;
    }
    
    // "종목명" + "시세" 패턴 (공백 없이, 시세 뒤에 다른 문자 허용)
    const stockNamePattern3 = /([가-힣a-zA-Z]+)시세[\s\?\!는이가을를]*/;
    const match3 = trimmedInput.match(stockNamePattern3);
    if (match3) {
        const extractedName = match3[1];
        // 시간 표현 키워드는 제외
        if (timeKeywords.includes(extractedName)) {
            return null;
        }
        // 상품명이면 null 반환 (종목명이 아님)
        if (commodityNames.includes(extractedName)) {
            return null;
        }
        return extractedName;
    }
    
    return null;
};

/**
 * 종목 시세 조회
 */
window.RebotCore.getStockPrice = function(stockName) {
    console.log(`종목 시세 조회: ${stockName}`);
    
    // 종목명을 종목코드로 변환 (실제 구현에서는 종목명-코드 매핑 테이블 사용)
    const stockCode = this.getStockCodeByName(stockName);
    
    if (!stockCode) {
        this.showBotMessage(`"${stockName}" 종목을 찾을 수 없습니다. 정확한 종목명을 입력해주세요.`, "종목 시세");
        return;
    }
    
    // API 호출
    this.callStockPriceAPI(stockCode, stockName);
};

/**
 * 종목명으로 종목코드 조회
 */
window.RebotCore.getStockCodeByName = function(stockName) {
    // 기존 시스템의 종목 데이터 활용
    if (typeof window.h_KSPKSDCODE !== 'undefined') {
        // h_KSPKSDCODE에서 종목명으로 검색
        for (let i = 0; i < window.h_KSPKSDCODE.length; i++) {
            const stockData = window.h_KSPKSDCODE[i];
            const stockCode = stockData[0];
            const stockNameInData = stockData[1];
            
            // 정확한 매칭
            if (stockNameInData === stockName) {
                return stockCode;
            }
            
            // 부분 매칭 (대소문자 무시)
            const lowerStockName = stockName.toLowerCase();
            const lowerDataName = stockNameInData.toLowerCase();
            if (lowerDataName.includes(lowerStockName) || lowerStockName.includes(lowerDataName)) {
                return stockCode;
            }
        }
    }
    
    // 주요 종목명-코드 매핑 테이블 (백업)
    const stockMapping = {
        "삼성전자": "005930",
        "sk하이닉스": "000660",
        "lg화학": "051910",
        "현대차": "005380",
        "naver": "035420",
        "카카오": "035720",
        "lg전자": "066570",
        "삼성바이오로직스": "207940",
        "셀트리온": "068270",
        "sk텔레콤": "017670",
        "kt": "030200",
        "lg": "003550",
        "현대모비스": "012330",
        "기아": "000270",
        "포스코": "005490",
        "sk": "034730",
        "한국전력": "015760",
        "삼성물산": "028260",
        "lg생활건강": "051900",
        "현대중공업": "009540"
    };
    
    // 정확한 매칭
    if (stockMapping[stockName]) {
        return stockMapping[stockName];
    }
    
    // 부분 매칭 (대소문자 무시)
    const lowerStockName = stockName.toLowerCase();
    for (const [key, value] of Object.entries(stockMapping)) {
        if (key.toLowerCase().includes(lowerStockName) || lowerStockName.includes(key.toLowerCase())) {
            return value;
        }
    }
    
    return null;
};

/**
 * 종목 시세 API 호출
 */
window.RebotCore.callStockPriceAPI = function(stockCode, stockName) {
    const payload = {
        stockCode: stockCode,
        marketType: "0",
        chartYn: "Y",
        period: "1",
        isUniv: "true"
    };
    
    console.log(`종목 시세 API 호출: ${stockCode} (${stockName})`, payload);
    
    // 실제 API 호출 (현재는 샘플 데이터 사용)
    this.showStockPriceResult(stockCode, stockName, this.getSampleStockPriceData(stockCode));
};

/**
 * 샘플 종목 시세 데이터 (실제 구현에서는 API 응답 사용)
 */
window.RebotCore.getSampleStockPriceData = function(stockCode) {
    // 삼성전자 샘플 데이터 (기존 스타일에 맞게 업데이트)
    if (stockCode === "005930") {
        return {
            "response": {
                "last": "95100",
                "change": "3500",
                "volume": "17880518",
                "amount": "1677869",
                "limitDown": "64200",
                "prevSign": "2",
                "indexCode": "KGS09P",
                "preSign": "2",
                "time": "150500",
                "tradeStop": "N",
                "marketType": "",
                "indexName": "코스피 전기 전자",
                "faceValue": "100",
                "forLastHoldingsRate": "51.96",
                "stockCode": "005930",
                "index": "38383.02",
                "lowTime": "090316",
                "aHourTotBidSize": "224128",
                "aggregateValue": "562365602",
                "prevMarketOpenPrice": "92300",
                "highTime": "143048",
                "eps": "4950",
                "preVolume": "35545235",
                "aHourToAskSize": null,
                "totBidSize": "538240",
                "change2": "1118.76",
                "ask": "95100",
                "low": "92100",
                "highest52Weeks": "96000",
                "paidinCap": "",
                "limitUp": "119000",
                "bidChgVol": "538239",
                "forLastHoldings": "3075753056",
                "lowest52Weeks": "49900",
                "totAskSize": "795491",
                "lowestPrDate": "20241114",
                "expExecPr": "0",
                "bid": "95000",
                "viActingPr": "",
                "chartUrl": "https://rc.kbsec.com/chartImgFiles/202510/chart_005930_1_20251015150500162.png",
                "forPrevHoldingsRate": "51.96",
                "preClose": "91600",
                "issuedQty": "5919637922",
                "chgRate": "3.82",
                "expExecQty": "0",
                "per": "13.36",
                "highestPrDate": "20251014",
                "perSec": "2",
                "prcType": "1",
                "forPrevHoldings": "3075753056",
                "high": "95300"
            },
            "message": "OK",
            "osGbn": "KR",
            "status": "200",
            "tp": "130000.00",
            "recomm": "Buy",
            "itemCode": "005930"
        };
    }
    
    // SK하이닉스 샘플 데이터
    if (stockCode === "000660") {
        return {
            "response": {
                "last": "125000",
                "change": "-2000",
                "volume": "8500000",
                "amount": "1062500",
                "limitDown": "85000",
                "prevSign": "2",
                "indexCode": "KGS09P",
                "preSign": "2",
                "time": "150500",
                "tradeStop": "N",
                "marketType": "",
                "indexName": "코스피 전기 전자",
                "faceValue": "100",
                "forLastHoldingsRate": "45.2",
                "stockCode": "000660",
                "index": "38383.02",
                "lowTime": "090316",
                "aHourTotBidSize": "224128",
                "aggregateValue": "562365602",
                "prevMarketOpenPrice": "127000",
                "highTime": "143048",
                "eps": "3200",
                "preVolume": "35545235",
                "aHourToAskSize": null,
                "totBidSize": "538240",
                "change2": "-1118.76",
                "ask": "125000",
                "low": "124000",
                "highest52Weeks": "150000",
                "paidinCap": "",
                "limitUp": "165000",
                "bidChgVol": "538239",
                "forLastHoldings": "3075753056",
                "lowest52Weeks": "85000",
                "totAskSize": "795491",
                "lowestPrDate": "20241114",
                "expExecPr": "0",
                "bid": "124900",
                "viActingPr": "",
                "chartUrl": "https://rc.kbsec.com/chartImgFiles/202510/chart_000660_1_20251015150500162.png",
                "forPrevHoldingsRate": "45.2",
                "preClose": "127000",
                "issuedQty": "5919637922",
                "chgRate": "-1.57",
                "expExecQty": "0",
                "per": "39.06",
                "highestPrDate": "20251014",
                "perSec": "2",
                "prcType": "1",
                "forPrevHoldings": "3075753056",
                "high": "127500"
            },
            "message": "OK",
            "osGbn": "KR",
            "status": "200",
            "tp": "150000.00",
            "recomm": "Buy",
            "itemCode": "000660"
        };
    }
    
    // 기본 샘플 데이터
    return {
        "response": {
            "last": "50000",
            "change": "1000",
            "volume": "1000000",
            "amount": "50000",
            "high": "51000",
            "low": "49000",
            "preClose": "49000",
            "prevMarketOpenPrice": "49500",
            "limitUp": "64000",
            "limitDown": "35000",
            "chgRate": "2.04",
            "stockCode": stockCode,
            "time": "150500",
            "chartUrl": "https://rc.kbsec.com/chartImgFiles/202510/chart_" + stockCode + "_1_20251015150500162.png"
        },
        "message": "OK",
        "status": "200",
        "tp": "60000.00",
        "recomm": "Hold"
    };
};

/**
 * 종목 시세 결과 표시 (기존 스타일 적용)
 */
window.RebotCore.showStockPriceResult = function(stockCode, stockName, data) {
    const response = data.response;
    
    if (!response) {
        this.showBotMessage(`"${stockName}" 시세 정보를 가져올 수 없습니다.`, "종목 시세");
        return;
    }
    
    // 시세 정보 포맷팅
    const currentPrice = this.formatNumber(response.last);
    const change = this.formatNumber(response.change);
    const changeRate = response.chgRate ? `${response.chgRate}%` : '0%';
    const volume = this.formatNumber(response.volume);
    const high = this.formatNumber(response.high);
    const low = this.formatNumber(response.low);
    const preClose = this.formatNumber(response.preClose);
    const openPrice = this.formatNumber(response.prevMarketOpenPrice || response.preClose);
    const limitUp = this.formatNumber(response.limitUp);
    const limitDown = this.formatNumber(response.limitDown);
    const amount = response.amount ? (parseInt(response.amount) / 100000000).toFixed(0) : '0';
    
    // 등락 표시
    const isUp = parseInt(response.change) > 0;
    const changeIcon = isUp ? '▲' : '▼';
    const changeColor = isUp ? '#e74c3c' : '#3498db';
    
    // 기존 스타일에 맞는 HTML 생성
    const stockPriceHtml = `
        <div class="chatOutTd">
            <span>
                ${response.chartUrl ? `
                    <a id="chatBotChart" href="javascript:void(0)">
                        <img src="${response.chartUrl}" width="230px" height="150px" alt="${stockName} 차트">
                    </a>
                ` : ''}
                <br>
                <li class="font_B">${stockName} (${stockCode})</li>
                <li class="font_B c_rd">
                    <span class="f18">${currentPrice}</span> ${changeIcon}${change} +${changeRate}
                </li>
                - 고가/저가 : ${high} / ${low}<br>
                - 시가/전일 : ${openPrice} / ${preClose}<br>
                - 상한/하한 : ${limitUp} / ${limitDown}<br>
                - 거래량/대금 : ${volume} / ${amount}백만<br>
                ----------------------<br>
                ${data.recomm ? `- 투자의견 : ${data.recomm}<br>` : ''}
                ${data.tp ? `- 목표가 : ${this.formatNumber(data.tp)}원<br>` : ''}
                ----------------------
            </span>
        </div>
    `;
    
    // 복합 결과 표시 (차트 기간 버튼 포함)
    this.showComplexResult(stockName + " 시세", {
        content: stockPriceHtml,
        showActionButtons: false,
        exlinks: false,
        relatedButtons: [],
        smallButtons: [
            "분봉",
            "3개월", 
            "6개월",
            "1년"
        ]
    });
};

/**
 * 숫자 포맷팅 (천 단위 콤마)
 */
window.RebotCore.formatNumber = function(num) {
    if (!num) return '0';
    return parseInt(num).toLocaleString();
};

/**
 * 시간 포맷팅 (오전/오후 포함, 초까지)
 * @param {string} time - 시간 문자열 (예: "150501", "15:05:01"). 없으면 현재 시간 사용
 * @returns {string} 포맷된 시간 문자열 (예: "오후 15:05:01")
 */
window.RebotCore.formatTimeWithPeriod = function(time) {
    let formattedTime;
    
    if (time) {
        // 전달받은 시간이 있는 경우
        if (time.length === 6) {
            // "150501" 형식
            formattedTime = `${time.substring(0,2)}:${time.substring(2,4)}:${time.substring(4,6)}`;
        } else if (time.length === 4) {
            // "1505" 형식
            formattedTime = `${time.substring(0,2)}:${time.substring(2,4)}:00`;
        } else {
            formattedTime = time;
        }
    } else {
        // 현재 시간 사용 (초까지)
        const now = new Date();
        const hours = now.getHours().toString().padStart(2, '0');
        const minutes = now.getMinutes().toString().padStart(2, '0');
        const seconds = now.getSeconds().toString().padStart(2, '0');
        formattedTime = `${hours}:${minutes}:${seconds}`;
    }
    
    // 현재 시간에 따라 오전/오후 결정
    const currentHour = new Date().getHours();
    const timePrefix = currentHour < 12 ? '오전' : '오후';
    
    return `${timePrefix} ${formattedTime}`;
};

/**
 * AI 스러운 응답 생성기
 */
window.RebotCore.generateAIResponse = function(intent, userInput) {
    const responses = {
        stock_market: {
            minute_chart: [
                "분봉 차트를 분석해드리겠습니다.",
                "실시간 분봉 데이터를 조회하고 있습니다.",
                "단기 차트 패턴을 확인해보겠습니다."
            ],
            kospi: [
                "코스피 지수 현황을 분석해드리겠습니다.",
                "코스피 시장 동향을 조회하고 있습니다.",
                "대형주 중심의 코스피 정보를 확인해보겠습니다."
            ],
            kosdaq: [
                "코스닥 지수 현황을 분석해드리겠습니다.",
                "코스닥 시장 동향을 조회하고 있습니다.",
                "중소형주 중심의 코스닥 정보를 확인해보겠습니다."
            ],
            period_chart: [
                "해당 기간의 차트를 분석해드리겠습니다.",
                "기간별 시장 동향을 조회하고 있습니다.",
                "투자 관점에서 분석해보겠습니다."
            ]
        },
        smart_search: {
            stock_code: [
                "종목코드를 분석하여 정보를 조회하겠습니다.",
                "해당 종목의 상세 정보를 확인해보겠습니다.",
                "종목 분석을 진행하겠습니다."
            ],
            stock_name: [
                "종목명을 기반으로 검색하겠습니다.",
                "해당 종목의 시장 정보를 조회하겠습니다.",
                "종목 분석을 시작하겠습니다."
            ]
        }
    };
    
    let responseType = intent.type;
    let actionType = intent.suggestedAction ? intent.suggestedAction.type : 'general';
    
    if (responseType === 'stock_market' && responses.stock_market[actionType]) {
        const possibleResponses = responses.stock_market[actionType];
        return possibleResponses[Math.floor(Math.random() * possibleResponses.length)];
    } else if (responseType === 'smart_search') {
        if (/^\d+$/.test(userInput.trim())) {
            const possibleResponses = responses.smart_search.stock_code;
            return possibleResponses[Math.floor(Math.random() * possibleResponses.length)];
        } else if (/[가-힣]{2,4}$/.test(userInput.trim())) {
            const possibleResponses = responses.smart_search.stock_name;
            return possibleResponses[Math.floor(Math.random() * possibleResponses.length)];
        }
    }
    
    return "요청하신 정보를 조회하겠습니다.";
};

/**
 * 컨텍스트 기반 추천 시스템
 */
window.RebotCore.generateContextualSuggestions = function(intent, userInput) {
    const suggestions = {
        stock_market: {
            minute_chart: ["3개월 차트", "6개월 차트", "코스피", "코스닥", "매매동향"],
            kospi: ["코스닥", "분봉", "3개월", "매매동향", "외국인 매매"],
            kosdaq: ["코스피", "분봉", "3개월", "매매동향", "기관 매매"],
            period_chart: ["분봉", "다른 기간", "코스피", "코스닥", "매매동향"]
        },
        smart_search: {
            stock_code: ["종목 분석", "차트 보기", "뉴스 검색", "관련 종목"],
            stock_name: ["종목 분석", "차트 보기", "뉴스 검색", "관련 종목"]
        }
    };
    
    let responseType = intent.type;
    let actionType = intent.suggestedAction ? intent.suggestedAction.type : 'general';
    
    if (suggestions[responseType] && suggestions[responseType][actionType]) {
        return suggestions[responseType][actionType];
    }
    
    return ["주식시장", "종목현재가", "업종/종목등락", "글로벌증시"];
};

/**
 * 학습 기반 키워드 확장
 */
window.RebotCore.expandKeywords = function(input) {
    const keywordMap = {
        // 주식시장 관련
        "주식": ["주식시장", "주가", "차트", "시세"],
        "시장": ["주식시장", "코스피", "코스닥"],
        "차트": ["분봉", "일봉", "주봉", "월봉"],
        "분석": ["매매동향", "외국인", "기관", "개인"],
        
        // 시간 관련
        "단기": ["분봉", "일봉"],
        "중기": ["3개월", "6개월"],
        "장기": ["1년", "월봉"],
        
        // 시장 관련
        "대형주": ["코스피"],
        "중소형주": ["코스닥"],
        "kospi": ["코스피"],
        "kosdaq": ["코스닥"]
    };
    
    const expandedKeywords = [input];
    
    // 키워드 확장
    Object.keys(keywordMap).forEach(key => {
        if (input.toLowerCase().includes(key.toLowerCase())) {
            expandedKeywords.push(...keywordMap[key]);
        }
    });
    
    return [...new Set(expandedKeywords)]; // 중복 제거
};

/**
 * 사용자 행동 패턴 분석
 */
window.RebotCore.analyzeUserPattern = function(userInput, timestamp) {
    // 간단한 패턴 분석 (실제로는 더 복잡한 로직 가능)
    const patterns = {
        timeOfDay: this.getTimePattern(timestamp),
        inputLength: userInput.length,
        inputType: this.getInputType(userInput),
        frequency: this.getUserFrequency(userInput)
    };
    
    return patterns;
};

/**
 * 시간대별 패턴 분석
 */
window.RebotCore.getTimePattern = function(timestamp) {
    const hour = new Date(timestamp).getHours();
    
    if (hour >= 9 && hour <= 15) {
        return "market_hours"; // 장중
    } else if (hour >= 6 && hour < 9) {
        return "pre_market"; // 장전
    } else if (hour > 15 && hour <= 18) {
        return "after_market"; // 장후
    } else {
        return "off_hours"; // 장외
    }
};

/**
 * 입력 타입 분석
 */
window.RebotCore.getInputType = function(input) {
    if (/^\d+$/.test(input)) return "numeric";
    if (/[가-힣]/.test(input)) return "korean";
    if (/[A-Za-z]/.test(input)) return "english";
    if (/[!@#$%^&*()]/.test(input)) return "special";
    return "mixed";
};

/**
 * 사용자 빈도 분석 (간단한 구현)
 */
window.RebotCore.getUserFrequency = function(input) {
    // 실제로는 사용자별 입력 히스토리를 저장해야 함
    return "normal"; // normal, frequent, rare
};

/**
 * AI 스러운 응답 개선
 */
window.RebotCore.enhanceBotMessage = function(message, intent, userInput) {
    const timePattern = this.getTimePattern(Date.now());
    const contextualMessage = this.addContextualInfo(message, timePattern, intent);
    
    return contextualMessage;
};

/**
 * 컨텍스트 정보 추가
 */
window.RebotCore.addContextualInfo = function(message, timePattern, intent) {
    let enhancedMessage = message;
    
    // 시간대별 컨텍스트 추가
    if (timePattern === "market_hours" && intent.type === "stock_market") {
        enhancedMessage += "\n<br>현재 장중이므로 실시간 데이터를 제공합니다.";
    } else if (timePattern === "pre_market" && intent.type === "stock_market") {
        enhancedMessage += "\n<br>장전 시간이므로 전일 종가 기준 정보를 제공합니다.";
    } else if (timePattern === "after_market" && intent.type === "stock_market") {
        enhancedMessage += "\n<br>장후 시간이므로 당일 종가 기준 정보를 제공합니다.";
    }
    
    return enhancedMessage;
};

/**
 * AJAX 호출 함수
 */
window.RebotCore.ajaxCall = function(url, params, callback, errorCallback) {
    console.log("API 호출:", url, params);
    
    fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(params)
    })
    .then(response => response.json())
    .then(data => {
        console.log("API 응답:", data);
        if (callback) callback(data);
    })
    .catch(error => {
        console.error("API 오류:", error);
        if (errorCallback) {
            errorCallback(error);
        } else {
        this.showBotMessage("❌ 데이터 조회 중 오류가 발생했습니다.");
        }
    });
};

/**
 * 주식시장 정보 조회
 */
window.RebotCore.stockMarket = function(typeChk, valueChk) {
    this.showBotMessage("주식시장 정보를 조회합니다...", "주식시장");
    
    // 임시 플래그: 샘플 데이터 사용 여부 (개발/테스트용)
    const USE_SAMPLE_DATA = true;
    
    if (USE_SAMPLE_DATA) {
        // 샘플 데이터 사용
        console.log("주식시장 샘플 데이터 사용");
        this.loadStockMarketSampleData();
    } else {
        // 실제 API 호출 (기존 방식)
    const params = {
        mktClsf: this.MARKET_DATA[0].mktClsf,
        invstClsf: this.MARKET_DATA[0].invstClsf,
        indTypCd: this.MARKET_DATA[0].indTypCd
    };
    
    this.ajaxCall("/ajax/getChatBotCospiCosdaqChart.json", params, (data) => {
        if (data && data.response) {
            const marketData = this.MARKET_DATA[0];
                // 복잡한 결과 구조로 표시
                this.showComplexResult("주식시장", data);
        } else {
                // 복잡한 결과 구조로 표시
                this.showComplexResult("주식시장", null);
            }
        });
    }
};

/**
 * 주식시장 샘플 데이터 로드
 */
window.RebotCore.loadStockMarketSampleData = function() {
    // 샘플 데이터를 직접 정의 (JSON 파일 로드 대신)
    const sampleData = {
        chartData: {
            chartUrl: "/chartImgFiles/202510/chart_KGG01P_1_20251015094201841.png",
            currentPrice: "3601.30",
            change: "39.49",
            changeRate: "+1.11%",
            trend: "up"
        },
        tradingData: {
            foreign: "122",
            institution: "1442", 
            individual: "-1653"
        },
        realTimeData: [
            {
                dt: "20251015",
                opnPrc: "360257",
                tm: "94200",
                bDyCmprClsf: "2",
                lwPrc: "360257",
                bDyCmprR: "114",
                dlTwAmt: "5791000000",
                clsPrc: "360257",
                bDyCmpr: "4076",
                vlm: "593000",
                hghPrc: "360257"
            },
            {
                dt: "20251015",
                opnPrc: "360191",
                tm: "94150",
                bDyCmprClsf: "2",
                lwPrc: "360191",
                bDyCmprR: "113",
                dlTwAmt: "11863000000",
                clsPrc: "360191",
                bDyCmpr: "4010",
                vlm: "755000",
                hghPrc: "360191"
            }
        ]
    };
    
    // 복잡한 결과 구조로 표시
    this.showComplexResult("주식시장", sampleData);
};

/**
 * 분봉 버튼 클릭 시 샘플 데이터 로드
 */
window.RebotCore.loadStockMarketMinuteData = function() {
    // 분봉 클릭 시 3가지 API 데이터를 시뮬레이션
    const minuteData = {
        // 1. 실시간 차트 데이터
        realTimeChart: {
            chartUrl: "/chartImgFiles/202510/chart_KGG01P_1_20251015102310481.png",
            currentPrice: "3612.92",
            change: "51.11",
            changeRate: "+1.43%",
            trend: "up",
            record1: [
                {
                    dt: "20251015",
                    opnPrc: "361292",
                    tm: "102310",
                    bDyCmprClsf: "2",
                    lwPrc: "361292",
                    bDyCmprR: "143",
                    dlTwAmt: "3517000000",
                    clsPrc: "361292",
                    bDyCmpr: "5111",
                    vlm: "122000",
                    hghPrc: "361292"
                },
                {
                    dt: "20251015",
                    opnPrc: "361247",
                    tm: "102300",
                    bDyCmprClsf: "2",
                    lwPrc: "361247",
                    bDyCmprR: "142",
                    dlTwAmt: "4851000000",
                    clsPrc: "361247",
                    bDyCmpr: "5066",
                    vlm: "133000",
                    hghPrc: "361247"
                }
            ]
        },
        // 2. 일별 차트 데이터
        dailyChart: {
            chartUrl: "/chartImgFiles/202510/chart_KGG01P_1_20251015102310481.png",
            record1: [
                {
                    dt: "20251015",
                    opnPrc: "361292",
                    tm: "",
                    bDyCmprClsf: "2",
                    lwPrc: "361292",
                    bDyCmprR: "143",
                    dlTwAmt: "3517000000",
                    clsPrc: "361292",
                    bDyCmpr: "5111",
                    vlm: "122000",
                    hghPrc: "361292"
                }
            ]
        },
        // 3. 매매동향 데이터
        tradingTrend: {
            foreign: "263",
            institution: "2347",
            individual: "-2654",
            detail: {
                invstTrustCmpny: "339",
                fndSbtrtNtm: "730",
                tm: "102300",
                invstBnkCrdtVlt: "1",
                insrCmpny: "41",
                scrtCmpny: "919",
                etcCorp: "42",
                fgnr: "263",
                bnk: "-14",
                ogn: "2347",
                clsPrcIndxP2: "3612.92",
                prvOFnd: "330",
                indv: "-2654",
                ntnLcltGroup: "0"
            }
        }
    };
    
    // 복잡한 결과 구조로 표시
    this.showComplexResult("주식시장 분봉", minuteData);
};

/**
 * 분봉 버튼 클릭 처리
 */
window.RebotCore.handleMinuteButtonClick = function(buttonText) {
    console.log("주식시장 버튼 클릭:", buttonText);
    
    // 버튼별로 다른 서비스 타입 설정
    let serviceType = "주식시장";
    if (buttonText === "분봉") {
        serviceType = "주식시장 분봉";
    } else if (buttonText === "3개월") {
        serviceType = "주식시장 3개월";
    } else if (buttonText === "6개월") {
        serviceType = "주식시장 6개월";
    } else if (buttonText === "1년") {
        serviceType = "주식시장 1년";
    } else if (buttonText === "코스피") {
        serviceType = "주식시장 코스피";
    } else if (buttonText === "코스닥") {
        serviceType = "주식시장 코스닥";
    }
    
    // 해당 서비스 타입으로 데이터 로드
    this.loadStockMarketDataByType(serviceType, buttonText);
};

/**
 * 주식시장 데이터 타입별 로드
 */
window.RebotCore.loadStockMarketDataByType = function(serviceType, buttonText) {
    // 기본 데이터 구조
    const baseData = {
        chartData: {
            chartUrl: "/chartImgFiles/202510/chart_KGG01P_1_20251015094201841.png",
            currentPrice: "3601.30",
            change: "39.49",
            changeRate: "+1.11%",
            trend: "up"
        },
        tradingData: {
            foreign: "122",
            institution: "1442", 
            individual: "-1653"
        }
    };
    
    // 버튼별로 다른 데이터 설정
    if (buttonText === "분봉") {
        baseData.chartData.chartUrl = "/chartImgFiles/202510/chart_KGG01P_1_20251015102310481.png";
        baseData.chartData.currentPrice = "3612.92";
        baseData.chartData.change = "51.11";
        baseData.chartData.changeRate = "+1.43%";
        baseData.tradingData.foreign = "263";
        baseData.tradingData.institution = "2347";
        baseData.tradingData.individual = "-2654";
    } else if (buttonText === "3개월") {
        baseData.chartData.chartUrl = "/chartImgFiles/202510/chart_KGG01P_3_20251015102310481.png";
        baseData.chartData.currentPrice = "3580.15";
        baseData.chartData.change = "18.34";
        baseData.chartData.changeRate = "+0.51%";
        baseData.tradingData.foreign = "189";
        baseData.tradingData.institution = "1123";
        baseData.tradingData.individual = "-1312";
    } else if (buttonText === "6개월") {
        baseData.chartData.chartUrl = "/chartImgFiles/202510/chart_KGG01P_6_20251015102310481.png";
        baseData.chartData.currentPrice = "3520.45";
        baseData.chartData.change = "-41.36";
        baseData.chartData.changeRate = "-1.16%";
        baseData.tradingData.foreign = "-156";
        baseData.tradingData.institution = "987";
        baseData.tradingData.individual = "-831";
    } else if (buttonText === "1년") {
        baseData.chartData.chartUrl = "/chartImgFiles/202510/chart_KGG01P_12_20251015102310481.png";
        baseData.chartData.currentPrice = "3456.78";
        baseData.chartData.change = "-105.03";
        baseData.chartData.changeRate = "-2.95%";
        baseData.tradingData.foreign = "-234";
        baseData.tradingData.institution = "756";
        baseData.tradingData.individual = "-522";
    } else if (buttonText === "코스피") {
        baseData.chartData.chartUrl = "/chartImgFiles/202510/chart_KOSPI_1_20251015102310481.png";
        baseData.chartData.currentPrice = "2601.23";
        baseData.chartData.change = "15.67";
        baseData.chartData.changeRate = "+0.61%";
        baseData.tradingData.foreign = "89";
        baseData.tradingData.institution = "456";
        baseData.tradingData.individual = "-545";
        
        // 코스피 API 호출 (기존 API 유지)
        this.callStockMarketAPI("KGG01P", "5", "1");
        
    } else if (buttonText === "코스닥") {
        baseData.chartData.chartUrl = "/chartImgFiles/202510/chart_KOSDAQ_1_20251015102310481.png";
        baseData.chartData.currentPrice = "789.45";
        baseData.chartData.change = "8.92";
        baseData.chartData.changeRate = "+1.14%";
        baseData.tradingData.foreign = "67";
        baseData.tradingData.institution = "234";
        baseData.tradingData.individual = "-301";
        
        // 코스닥 API 호출 (기존 API 유지)
        this.callStockMarketAPI("QGG01P", "6", "2");
    }
    
    // 복잡한 결과 구조로 표시
    this.showComplexResult(serviceType, baseData);
};

/**
 * 주식시장 API 호출 (코스피/코스닥 버튼용)
 */
window.RebotCore.callStockMarketAPI = function(isCd, mktClsf, trndMktClsf) {
    console.log("주식시장 API 호출:", { isCd, mktClsf, trndMktClsf });
    
    // 1차 호출: getChatBotCospiCosdaqChart.json (chartYn: "Y", isCd: "")
    const params1 = {
        chartYn: "Y",
        dataStrtDt: "20251015",
        dyWkMmMTClsf: "T",
        isCd: "",
        mktClsf: mktClsf,
        mnTkIndx: "",
        period: "1",
        rqsDataKey: mktClsf
    };
    
    this.ajaxCall("/ajax/getChatBotCospiCosdaqChart.json", params1, 
        (response) => {
            console.log("1차 API 호출 성공:", response);
            
            // 2차 호출: getChatBotCospiCosdaqChart.json (chartYn: "", isCd: 실제값)
            const params2 = {
                chartYn: "",
                dataStrtDt: "20251015",
                dyWkMmMTClsf: "D",
                isCd: isCd,
                mktClsf: mktClsf,
                mnTkIndx: "",
                period: "1",
                rqsDataKey: mktClsf
            };
            
            this.ajaxCall("/ajax/getChatBotCospiCosdaqChart.json", params2,
                (response2) => {
                    console.log("2차 API 호출 성공:", response2);
                    
                    // 3차 호출: getChatBotInvstrTrdTrnd.json
                    const params3 = {
                        mktClsf: trndMktClsf,
                        indTypCd: isCd,
                        amtQClsf: "1",
                        inqCnt: "1"
                    };
                    
                    this.ajaxCall("/ajax/getChatBotInvstrTrdTrnd.json", params3,
                        (response3) => {
                            console.log("3차 API 호출 성공:", response3);
                            // 모든 API 호출 완료 - 실제 데이터로 업데이트 가능
                        },
                        (error) => {
                            console.log("3차 API 호출 실패:", error);
                        }
                    );
                },
                (error) => {
                    console.log("2차 API 호출 실패:", error);
                }
            );
        },
        (error) => {
            console.log("1차 API 호출 실패:", error);
        }
    );
};

/**
 * 업종/종목 등락 정보 조회
 * @param {string} typeChk - 타입 체크
 * @param {string} valueChk - K:KRX 업종, C:코스피/코스닥 종목
 */
window.RebotCore.typeUpDown = function(typeChk, valueChk) {
        this.showBotMessage("업종/종목 등락 정보를 조회합니다...", "업종 | 종목 등락");
    
    // KRX 업종 등락 조회
    if (valueChk == "K") {
        // 개발 환경이면 샘플 데이터 사용, 프로덕션 환경이면 API 호출
        const useSample = this.config.useSampleData();
        
        if (useSample && window.updownSectorSample && window.updownSectorSample.updownSectorSample) {
            // 개발 환경: 샘플 데이터 사용
            console.log("[개발 모드] 샘플 데이터 사용");
            const upData = window.updownSectorSample.updownSectorSample.apis[0].response;
            const downData = window.updownSectorSample.updownSectorSample.apis[1].response;
            
            // 약간의 딜레이를 추가하여 실제 API처럼 보이게
            setTimeout(() => {
                this.displayUpDownSectorData(upData, downData);
            }, 500);
        } else {
            // 프로덕션 환경: 실제 API 호출
            console.log("[프로덕션 모드] API 호출");
            const params1 = { infoClsf: "5", upDownKndCd: "1", isCnt: "5" }; // 상승
            const params2 = { infoClsf: "5", upDownKndCd: "2", isCnt: "5" }; // 하락
            
            // 두 API를 병렬로 호출
            Promise.all([
                this.ajaxCall("/ajax/getRiseUpSectorQuotations.json", params1, 
                    (data) => data, 
                    (error) => { console.error("상승 업종 조회 실패:", error); return null; }),
                this.ajaxCall("/ajax/getRiseUpSectorQuotations.json", params2,
                    (data) => data,
                    (error) => { console.error("하락 업종 조회 실패:", error); return null; })
            ]).then(([upData, downData]) => {
                this.displayUpDownSectorData(upData, downData);
            });
        }
    } 
    // 코스피/코스닥 종목 등락 조회
    else if (valueChk == "C") {
        const stockParams = [
            { infoClsf: "0", upDownKndCd: "1" }, // 코스피 상승
            { infoClsf: "0", upDownKndCd: "2" }, // 코스피 하락
            { infoClsf: "1", upDownKndCd: "1" }, // 코스닥 상승
            { infoClsf: "1", upDownKndCd: "2" }  // 코스닥 하락
        ];
        
        // 4개 API를 병렬로 호출
        Promise.all(
            stockParams.map(params => 
                this.ajaxCall("/ajax/getUpCompanyQuotations.json", params,
                    (data) => data,
                    (error) => { console.error("종목 등락 조회 실패:", error); return null; })
            )
        ).then(([kosUpData, kosDownData, nasUpData, nasDownData]) => {
            this.displayUpDownStockData([
                { name: "코스피", upDown: "상승", type: "K", data: kosUpData },
                { name: "코스피", upDown: "하락", type: "K", data: kosDownData },
                { name: "코스닥", upDown: "상승", type: "Q", data: nasUpData },
                { name: "코스닥", upDown: "하락", type: "Q", data: nasDownData }
            ]);
        });
    }
};

/**
 * 업종 등락 데이터 표시
 */
window.RebotCore.displayUpDownSectorData = function(upData, downData) {
    let html = "<h3>KRX 업종 등락률 랭킹</h3>";
    
    // 상승 업종 TOP5
    html += "<div class='updown-section'>";
    html += "<strong>KRX 등락률 상승 업종 TOP5</strong><br>";
    const upRecords = upData?.response?.record1 || [];
    if (upRecords.length > 0) {
        upRecords.forEach((item, idx) => {
            const codeInfo = this.UPDOWN_CODE.find(code => code.code == item.cd);
            const name = codeInfo?.koNm || item.indTypNm || '';
            const len = 10 - Math.round(window.RebotUtils.lengthEUCKR(name));
            const rate = window.RebotUtils.parseComrR(item.upDwnR, item.bDyCmprSmbl);
            html += `${idx + 1}. ${window.RebotUtils.addEnd(name, len, '　')}${rate}%<br>`;
        });
    } else {
        html += "*해당 업종이 없습니다.<br>";
    }
    html += "</div><br>";
    
    // 하락 업종 TOP5
    html += "<div class='updown-section'>";
    html += "<strong>KRX 등락률 하락 업종 TOP5</strong><br>";
    const downRecords = downData?.response?.record1 || [];
    if (downRecords.length > 0) {
        downRecords.forEach((item, idx) => {
            const codeInfo = this.UPDOWN_CODE.find(code => code.code == item.cd);
            const name = codeInfo?.koNm || item.indTypNm || '';
            const len = 10 - Math.round(window.RebotUtils.lengthEUCKR(name));
            const rate = window.RebotUtils.parseComrR(item.upDwnR, item.bDyCmprSmbl);
            html += `${idx + 1}. ${window.RebotUtils.addEnd(name, len, '　')}${rate}%<br>`;
        });
    } else {
        html += "*해당 업종이 없습니다.<br>";
    }
    html += "</div>";
    
    this.showBotMessage(html, "KRX 업종 등락");
};

/**
 * 종목 등락 데이터 표시
 */
window.RebotCore.displayUpDownStockData = function(resultArray) {
    let html = "<h3>코스피/코스닥'S 등락률 랭킹</h3>";
    
    resultArray.forEach((result, idx) => {
        if (idx === 0 || idx === 2) {
            // 상승 섹션
            html += this.makeUpDownHtml(result);
        } else {
            // 하락 섹션
            html += "<br>" + this.makeUpDownHtml(result);
        }
    });
    
    this.showBotMessage(html, "종목 등락");
};

/**
 * 종목 등락 HTML 생성
 */
window.RebotCore.makeUpDownHtml = function(resData) {
    const stockCode = window.h_KSPKSDCODE;
    let masterCode = [];
    const rankData = resData.data?.response?.record1 || resData.data || [];
    let html = `<div class='updown-section'><strong>${resData.name} 등락률 ${resData.upDown} 종목 TOP5</strong><br>`;
    
    // 해당 시장의 종목 코드만 필터링
    for (let i = 0; i < stockCode.length; i++) {
        if (stockCode[i][2] == resData.type) {
            masterCode.push(stockCode[i]);
        }
    }
    
    let cnt = 0;
    if (rankData.length > 0) {
        for (let i = 0; i < rankData.length; i++) {
            if (cnt > 4) break;
            
            for (let j = 0; j < masterCode.length; j++) {
                if (rankData[i].isCd == masterCode[j][0]) {
                    cnt++;
                    const stockName = masterCode[j][1].trim();
                    const stockLen = 10 - Math.round(window.RebotUtils.lengthEUCKR(stockName));
                    const rate = window.RebotUtils.parseComrR(rankData[i].upDownCmprR, rankData[i].bDyCmprSmbl);
                    html += `${cnt}. ${window.RebotUtils.addEnd(stockName, stockLen, '　')}${rate}%<br>`;
                    break;
                }
            }
        }
    } else {
        html += "*해당 종목이 없습니다.<br>";
    }
    html += "</div>";
    
    return html;
};

/**
 * 종목현재가 조회
 */
window.RebotCore.stockPrice = function(typeChk, valueChk) {
        this.showBotMessage("종목현재가를 조회합니다. 종목명을 입력해주세요.", "종목현재가");
    
    // 종목명 입력 대기 상태
    this.searchNo = "03";
};

/**
 * 글로벌증시 정보 조회
 * @param {string} typeChk - 타입 체크 (T: 탭 전환, L: 리스트)
 * @param {string} valueChk - 지역 (us: 미국/유럽, asia: 아시아, list: 전체 리스트)
 */
window.RebotCore.globalMarket = function(typeChk, valueChk) {
        this.showBotMessage("글로벌증시 정보를 조회합니다...", "글로벌증시");
    
    // 지역 결정 (기본값: 시간에 따라 자동)
    let region = valueChk || "asia";
    if (!valueChk) {
        const toHours = new Date().getHours();
        region = (0 <= toHours && toHours < 12) ? "us" : "asia";
    }
    
    // 개발 환경이면 샘플 데이터 사용, 프로덕션 환경이면 API 호출
    const useSample = this.config.useSampleData();
    
    if (useSample && window.getWorldIndexSample && window.getWorldIndexSample.response) {
        // 개발 환경: 샘플 데이터 사용
        console.log("[개발 모드] 글로벌증시 샘플 데이터 사용");
        setTimeout(() => {
            this.displayGlobalMarketData(window.getWorldIndexSample, region);
        }, 500);
    } else {
        // 프로덕션 환경: 실제 API 호출
        console.log("[프로덕션 모드] 글로벌증시 API 호출");
    const params = {
            region: region
    };
    
    this.ajaxCall("/ajax/getWorldIndex.json", params, (data) => {
            this.displayGlobalMarketData(data, region);
    }, (error) => {
            console.error("글로벌증시 조회 실패:", error);
            this.showBotMessage("글로벌증시 정보를 조회하는 중 오류가 발생했습니다.", "글로벌증시");
        });
    }
};

/**
 * 글로벌증시 데이터 표시
 */
window.RebotCore.displayGlobalMarketData = function(data, region) {
    const records = data?.response?.record1 || [];
    
    // 국가별로 데이터 분류
    const asiaIndices = [];
    const usEuIndices = [];
    
    records.forEach(item => {
        const country = item.ntnNm || '';
        if (['한국', '일본', '홍콩', '중국', '대만'].includes(country)) {
            asiaIndices.push(item);
        } else if (['미국', '독일', '영국', '프랑스', '유로존'].includes(country)) {
            usEuIndices.push(item);
        }
    });
    
    // 지역에 따라 표시할 데이터 결정
    const displayData = (region === 'asia') ? asiaIndices : usEuIndices;
    const regionTitle = (region === 'asia') ? '아시아 주요지수' : '미국/유럽 주요지수';
    
    // HTML 생성
    let html = `<div class="global-market-section">`;
    html += `<h3>${regionTitle}</h3>`;
    
    if (displayData.length > 0) {
        displayData.forEach(item => {
            // 국가 이미지 경로 결정
            const countryImg = this.getCountryImage(item.ntnNm);
            
            // 날짜 포맷팅 (11/05)
            const dateStr = item.dt ? this.formatDateForDisplay(item.dt) : '';
            
            // 현재가 포맷팅 (콤마 추가, 소수점 처리)
            const priceNum = parseFloat(item.nowPrc || 0);
            const price = window.RebotUtils.addComma(priceNum.toFixed(2));
            
            // 등락률 포맷팅 (cmprr은 이미 100배 값, 예: -301 -> -3.01%)
            const rateNum = parseFloat(item.cmprr || 0) / 100;
            const rate = Math.abs(rateNum).toFixed(2);
            const rateSign = rateNum >= 0 ? '+' : '-';
            
            // 등락률 색상 결정 (상승: 빨강, 하락: 파랑)
            const rateColor = rateNum >= 0 ? '#c00' : '#00c';
            
            html += `<div class="global-index-item">`;
            html += `<div class="global-index-header">`;
            html += `<img src="${countryImg}" alt="${item.ntnNm}" width="20" height="15">`;
            html += `<strong>${item.ntnNm} ${item.indxNm}</strong>`;
            if (dateStr) {
                html += `<span class="date-badge">(${dateStr})</span>`;
            }
            html += `</div>`;
            html += `<div class="global-index-price">`;
            html += `<span class="price">${price}</span>`;
            html += `<span class="rate" style="color: ${rateColor};">${rateSign}${rate}%</span>`;
            html += `</div>`;
            html += `</div>`;
        });
    } else {
        html += `<p>해당 지역의 지수 데이터가 없습니다.</p>`;
    }
    
    // 시간 표시
    const currentTime = this.formatTimeWithPeriod();
    html += `<div class="global-market-time">${currentTime}</div>`;
    
    html += `</div>`;
    
    // 버튼 영역 (기존 스타일 사용)
    const buttonHtml = `
        <div id="query-rl-btn-sm" class="query__rl__btn__sm">
            <div class="query__rl__btn__wrapper__sm">
                <button type="button" class="query__rl__it__sm region-btn" data-region="us" data-role="">미국/유럽</button>
            </div>
            <div class="query__rl__btn__wrapper__sm">
                <button type="button" class="query__rl__it__sm region-btn" data-region="asia" data-role="">아시아</button>
            </div>
            <div class="query__rl__btn__wrapper__sm">
                <button type="button" class="query__rl__it__sm news-btn" data-role="">뉴욕증시 마감기사 모아보기</button>
            </div>
        </div>
    `;
    
    // HTML 메시지로 표시 (showBotMessage 대신 직접 HTML 표시)
    const botMessageHtml = `
        <div class="prompt__cont">
            <div class="prompt__src sr_only" data-role="">
                query:
            </div>
            <div class="prompt__query_box">
                <div class="prompt__txt_adjust">
                    <div class="prompt__query_title">글로벌증시</div>
                    <div class="prompt__model_chosen">
                        rebot thinking
                        <img src="icons/gr_ic.svg" alt="">
                    </div>
                </div>
            </div>
            <div class="chatOutTd">
                <span>
                    ${html}
                </span>
            </div>
            ${buttonHtml}
        </div>
    `;
    
    this.addMessageToChat(botMessageHtml, 'query');
    
    // 버튼 클릭 이벤트 바인딩
    setTimeout(() => {
        const self = this;
        
        // 지역 전환 버튼
        const regionButtons = document.querySelectorAll('.region-btn');
        regionButtons.forEach(btn => {
            btn.addEventListener('click', function(e) {
                const newRegion = this.getAttribute('data-region');
                self.globalMarket("T", newRegion);
            });
        });
        
        // 뉴욕증시 마감기사 버튼
        const newsButtons = document.querySelectorAll('.news-btn');
        newsButtons.forEach(btn => {
            btn.addEventListener('click', function(e) {
                self.showMarketNewsList();
            });
        });
    }, 100);
};

/**
 * 뉴욕증시 마감기사 목록 조회
 */
window.RebotCore.showMarketNewsList = function() {
    this.showBotMessage("뉴욕증시 마감기사를 조회합니다...", "뉴욕증시 마감기사");
    
    // 날짜 키 생성 (YYYYMMDDHHMMSS 형태)
    const now = new Date();
    const today = this.formatDateToYYYYMMDD(now);
    
    // 5일 전 날짜 계산
    const fiveDaysAgo = new Date(now);
    fiveDaysAgo.setDate(fiveDaysAgo.getDate() - 5);
    const fromDate = this.formatDateToYYYYMMDD(fiveDaysAgo);
    
    const fromKey = fromDate + "0530000000"; // 5일 전 05:30:00
    const toKey = today + "0745000000"; // 오늘 07:45:00
    
    const params = {
        fromKey: fromKey,
        rvrsOrdr: "2",
        src: "05",
        srchChar: "뉴욕증시",
        toKey: toKey
    };
    
    // 개발 환경이면 샘플 데이터 사용, 프로덕션 환경이면 API 호출
    const useSample = this.config.useSampleData();
    
    if (useSample && window.getMarketNewsDetailInfoListSample && window.getMarketNewsDetailInfoListSample.response) {
        // 개발 환경: 샘플 데이터 사용
        console.log("[개발 모드] 뉴욕증시 마감기사 샘플 데이터 사용");
        setTimeout(() => {
            this.displayMarketNewsList(window.getMarketNewsDetailInfoListSample);
        }, 500);
    } else {
        // 프로덕션 환경: 실제 API 호출
        console.log("[프로덕션 모드] 뉴욕증시 마감기사 API 호출");
        this.ajaxCall("/ajax/getMarketNewsDetailInfoList.json", params, (data) => {
            this.displayMarketNewsList(data);
        }, (error) => {
            console.error("뉴욕증시 마감기사 조회 실패:", error);
            this.showBotMessage("뉴욕증시 마감기사를 조회하는 중 오류가 발생했습니다.", "뉴욕증시 마감기사");
        });
    }
};

/**
 * 뉴욕증시 마감기사 목록 표시
 */
window.RebotCore.displayMarketNewsList = function(data) {
    const newsList = data?.response || [];
    
    if (newsList.length === 0) {
        this.showBotMessage("뉴욕증시 마감기사가 없습니다.", "뉴욕증시 마감기사");
        return;
    }
    
    let html = `<ul class="market-news-list">`;
    
    newsList.forEach((news, idx) => {
        // 날짜 포맷팅 (MM/DD)
        const dateStr = news.dt ? this.formatDateForDisplay(news.dt) : '';
        
        // 제목
        const title = news.title || '제목 없음';
        
        // 상세보기 링크 URL 생성
        const detailUrl = `https://rc.kbsec.com/m.html?t=2&id=${news.mrkStUntyKey || ''}`;
        
        html += `<li>`;
        if (dateStr) {
            html += `[${dateStr}] `;
        }
        html += `${title}`;
        html += `<br>`;
        html += `<a href="javascript:void(0)" onclick="window.RebotCore.linkOpen('${detailUrl}');">`;
        html += `<img src="/images/web/webchatbot_link.png" width="66px" height="19px" alt="상세보기">`;
        html += `</a>`;
        html += `</li>`;
        if (idx < newsList.length - 1) {
            html += `<br>`;
        }
    });
    
    html += `</ul>`;
    
    // HTML 메시지로 표시
    const botMessageHtml = `
        <div class="prompt__cont">
            <div class="prompt__src sr_only" data-role="">
                query:
            </div>
            <div class="prompt__query_box">
                <div class="prompt__txt_adjust">
                    <div class="prompt__query_title">뉴욕증시 마감기사</div>
                    <div class="prompt__model_chosen">
                        rebot thinking
                        <img src="icons/gr_ic.svg" alt="">
                    </div>
                </div>
            </div>
            <div class="chatOutBox">
                <div class="chatOutTd">
                    <span>
                        ${html}
                    </span>
                    <span class="fr mt5 ml10 c_6" style="font-size:9px">${this.formatTimeWithPeriod()}</span>
                </div>
                <div style="clear:both"></div>
            </div>
            <div class="prompt__txt_box">
                <div class="prompt__txt_adjust">
                    <div class="prompt__timestamp">${this.formatTimeWithPeriod()}</div>
                </div>
            </div>
        </div>
    `;
    
    this.addMessageToChat(botMessageHtml, 'query');
};

/**
 * 날짜를 YYYYMMDD 형식으로 변환
 */
window.RebotCore.formatDateToYYYYMMDD = function(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}${month}${day}`;
};

/**
 * 시간 키를 포맷팅 (HHMMSS -> HH:MM)
 */
window.RebotCore.formatTimeFromKey = function(timeKey) {
    if (!timeKey || timeKey.length < 6) return '';
    const hour = timeKey.substring(0, 2);
    const minute = timeKey.substring(2, 4);
    return `${hour}:${minute}`;
};

/**
 * 링크 열기 함수 (기존 챗봇 호환성)
 */
window.RebotCore.linkOpen = function(url) {
    if (!url) return;
    
    // 새 창에서 열기
    window.open(url, '_blank', 'noopener,noreferrer');
    
    // 또는 같은 창에서 열기
    // window.location.href = url;
};

/**
 * 국가별 이미지 경로 반환
 */
window.RebotCore.getCountryImage = function(countryName) {
    const countryMap = {
        '한국': '/images/web/kr.png',
        '일본': '/images/web/jp.png',
        '홍콩': '/images/web/hk.png',
        '중국': '/images/web/cn.png',
        '대만': '/images/web/tw.png',
        '미국': '/images/web/us.png',
        '독일': '/images/web/de.png',
        '영국': '/images/web/gb.png',
        '프랑스': '/images/web/fr.png',
        '유로존': '/images/web/eu.png'
    };
    return countryMap[countryName] || '/images/web/default.png';
};

/**
 * 날짜 포맷팅 (YYYYMMDD -> MM/DD)
 */
window.RebotCore.formatDateForDisplay = function(dateStr) {
    if (!dateStr || dateStr.length !== 8) return '';
    const month = dateStr.substring(4, 6);
    const day = dateStr.substring(6, 8);
    return `${month}/${day}`;
};


/**
 * 유가/상품 정보 조회
 * @param {string} typeChk - 타입 체크 (T: 특정 종목 조회)
 * @param {string} valueChk - 종목 코드 (빈 값이면 전체 조회)
 */
window.RebotCore.oilProduct = function(typeChk, valueChk) {
        this.showBotMessage("유가/상품 정보를 조회합니다...", "유가 및 상품");
    
    // 특정 종목 조회인 경우 (typeChk: "T" - 종목, "D" - 기간)
    if (valueChk && valueChk !== "") {
        // 기간 선택인 경우 (period: 3, 6, 12)
        if (typeChk === "D") {
            // 현재 선택된 종목 코드를 유지하면서 기간만 변경
            const currentCode = this.currentOilProductCode || "NYM@CL";
            const clsf = this.getClsfFromCode(currentCode);
    
    const params = {
                cd: currentCode,
                chartYn: "Y",
                clsf: clsf,
                period: valueChk
            };
            
            const useSample = this.config.useSampleData();
            if (useSample && window.getGdsFtsMarketPriceDetailSample && window.getGdsFtsMarketPriceDetailSample[currentCode]) {
                console.log("[개발 모드] 유가/상품 상세 샘플 데이터 사용");
                setTimeout(() => {
                    const sampleData = window.getGdsFtsMarketPriceDetailSample[currentCode];
                    // 차트 URL에 period 반영
                    if (sampleData.response.chartUrl) {
                        sampleData.response.chartUrl = sampleData.response.chartUrl.replace(/_3_/, `_${valueChk}_`);
                    }
                    this.displayOilProductDetail(currentCode, sampleData, valueChk);
                }, 500);
            } else {
                console.log("[프로덕션 모드] 유가/상품 상세 API 호출");
    this.ajaxCall("/ajax/getGdsFtsMarketPrice.json", params, (data) => {
                    this.displayOilProductDetail(currentCode, data, valueChk);
    }, (error) => {
                    console.error("유가/상품 상세 조회 실패:", error);
                });
            }
            return;
        }
        
        // 종목 선택인 경우
        this.currentOilProductCode = valueChk; // 현재 선택된 종목 저장
        const clsf = this.getClsfFromCode(valueChk);
        
        const params = {
            cd: valueChk,
            chartYn: "Y",
            clsf: clsf,
            period: "3" // 기본값 3개월
        };
        
        // 개발 환경이면 샘플 데이터 사용, 프로덕션 환경이면 API 호출
        const useSample = this.config.useSampleData();
        
        if (useSample && window.getGdsFtsMarketPriceDetailSample && window.getGdsFtsMarketPriceDetailSample[valueChk]) {
            console.log("[개발 모드] 유가/상품 상세 샘플 데이터 사용");
            setTimeout(() => {
                this.displayOilProductDetail(valueChk, window.getGdsFtsMarketPriceDetailSample[valueChk], "3");
            }, 500);
        } else {
            console.log("[프로덕션 모드] 유가/상품 상세 API 호출");
            this.ajaxCall("/ajax/getGdsFtsMarketPrice.json", params, (data) => {
                this.displayOilProductDetail(valueChk, data, "3");
            }, (error) => {
                console.error("유가/상품 상세 조회 실패:", error);
            });
        }
        return;
    }
    
    // 전체 조회 (유가 + 상품)
    const params1 = { cd: "", chartYn: "", clsf: "21", period: "" }; // 유가
    const params2 = { cd: "", chartYn: "", clsf: "22", period: "" }; // 상품
    
    // 개발 환경이면 샘플 데이터 사용, 프로덕션 환경이면 API 호출
    const useSample = this.config.useSampleData();
    
    if (useSample && window.getGdsFtsMarketPriceSample && window.getGdsFtsMarketPriceSample.oil && window.getGdsFtsMarketPriceSample.commodity) {
        // 개발 환경: 샘플 데이터 사용
        console.log("[개발 모드] 유가/상품 샘플 데이터 사용");
        setTimeout(() => {
            this.displayOilProductData(window.getGdsFtsMarketPriceSample.oil, window.getGdsFtsMarketPriceSample.commodity);
        }, 500);
    } else {
        // 프로덕션 환경: 실제 API 호출
        console.log("[프로덕션 모드] 유가/상품 API 호출");
        Promise.all([
            this.ajaxCall("/ajax/getGdsFtsMarketPrice.json", params1, 
                (data) => data, 
                (error) => { console.error("유가 조회 실패:", error); return null; }),
            this.ajaxCall("/ajax/getGdsFtsMarketPrice.json", params2,
                (data) => data,
                (error) => { console.error("상품 조회 실패:", error); return null; })
        ]).then(([oilData, commodityData]) => {
            this.displayOilProductData(oilData, commodityData);
        });
    }
};

/**
 * 유가/상품 데이터 표시
 */
window.RebotCore.displayOilProductData = function(oilData, commodityData) {
    const oilRecords = oilData?.response?.record1 || [];
    const commodityRecords = commodityData?.response?.record1 || [];
    
    // CODE_DATA에서 이모지 매칭
    const getEmoji = (code) => {
        const codeInfo = this.CODE_DATA.find(item => item.code === code);
        return codeInfo?.emoji || '';
    };
    
    // CODE_DATA에서 이름 매칭
    const getName = (code, defaultName) => {
        const codeInfo = this.CODE_DATA.find(item => item.code === code);
        return codeInfo?.name || defaultName;
    };
    
    let html = '';
    
    // 유가 데이터 표시 (WTI, 두바이, 브렌트 순서로 정렬)
    const oilOrder = ['NYM@CL', 'SPT@DU', 'IPE@EB']; // WTI, 두바이, 브렌트
    oilOrder.forEach(code => {
        const item = oilRecords.find(r => r.cd === code);
        if (!item) return;
        
        const emoji = getEmoji(item.cd);
        const name = getName(item.cd, item.isNm);
        const dateStr = item.dt ? this.formatDateForDisplay(item.dt) : '';
        const price = parseFloat(item.nowPrc || 0).toFixed(2);
        const rate = parseFloat(item.cmprr || 0);
        const rateStr = (rate >= 0 ? '+' : '') + rate.toFixed(2);
        const rateColor = rate >= 0 ? '#c00' : '#00c';
        
        html += `${emoji} <font class="font_B">${name}</font>`;
        if (dateStr) {
            html += ` (${dateStr})`;
        }
        html += `<br>`;
        html += `${price}           <span style="color: ${rateColor};">${rateStr}%</span><br><br>`;
    });
    
    // 상품 데이터 표시 (금, 은만)
    const commodityOrder = ['COM@GC', 'COM@SI']; // 금, 은
    commodityOrder.forEach(code => {
        const item = commodityRecords.find(r => r.cd === code);
        if (!item) return;
        
        const emoji = getEmoji(item.cd);
        const name = getName(item.cd, item.isNm);
        const dateStr = item.dt ? this.formatDateForDisplay(item.dt) : '';
        const price = parseFloat(item.nowPrc || 0).toFixed(2);
        const rate = parseFloat(item.cmprr || 0);
        const rateStr = (rate >= 0 ? '+' : '') + rate.toFixed(2);
        const rateColor = rate >= 0 ? '#c00' : '#00c';
        
        html += `${emoji} <font class="font_B">${name}</font>`;
        if (dateStr) {
            html += ` (${dateStr})`;
        }
        html += `<br>`;
        html += `${price}           <span style="color: ${rateColor};">${rateStr}%</span><br><br>`;
    });
    
    // 버튼 영역 (기존 스타일 사용)
    const buttonHtml = `
        <div id="query-rl-btn-sm" class="query__rl__btn__sm">
            <div class="query__rl__btn__wrapper__sm">
                <button type="button" class="query__rl__it__sm" data-role="" onclick="window.RebotCore.oilProduct('T', 'NYM@CL');">WTI</button>
            </div>
            <div class="query__rl__btn__wrapper__sm">
                <button type="button" class="query__rl__it__sm" data-role="" onclick="window.RebotCore.oilProduct('T', 'SPT@DU');">두바이</button>
            </div>
            <div class="query__rl__btn__wrapper__sm">
                <button type="button" class="query__rl__it__sm" data-role="" onclick="window.RebotCore.oilProduct('T', 'IPE@EB');">브렌트</button>
            </div>
            <div class="query__rl__btn__wrapper__sm">
                <button type="button" class="query__rl__it__sm" data-role="" onclick="window.RebotCore.oilProduct('T', 'COM@GC');">금</button>
            </div>
            <div class="query__rl__btn__wrapper__sm">
                <button type="button" class="query__rl__it__sm" data-role="" onclick="window.RebotCore.oilProduct('T', 'COM@SI');">은</button>
            </div>
            <div class="query__rl__btn__wrapper__sm">
                <button type="button" class="query__rl__it__sm" data-role="" onclick="window.RebotCore.oilProduct('T', 'COM@HG');">구리</button>
            </div>
        </div>
    `;
    
    // HTML 메시지로 표시
    const currentTime = this.formatTimeWithPeriod();
    const botMessageHtml = `
        <div class="prompt__cont">
            <div class="prompt__src sr_only" data-role="">
                query:
            </div>
            <div class="prompt__query_box">
                <div class="prompt__txt_adjust">
                    <div class="prompt__query_title">유가 및 상품</div>
                    <div class="prompt__model_chosen">
                        rebot thinking
                        <img src="icons/gr_ic.svg" alt="">
                    </div>
                </div>
            </div>
            <div class="chatOutBox">
                <div class="chatOutTd">
                    <span>
                        ${html}
                    </span>
                    <span class="fr mt5 ml10 c_6" style="font-size:9px">${currentTime}</span>
                </div>
                ${buttonHtml}
                <div style="clear:both"></div>
            </div>
            <div class="prompt__txt_box">
                <div class="prompt__txt_adjust">
                    <div class="prompt__timestamp">${currentTime}</div>
                </div>
            </div>
        </div>
    `;
    
    this.addMessageToChat(botMessageHtml, 'query');
};

/**
 * 유가/상품 상세 정보 표시 (특정 종목 클릭 시)
 * @param {string} code - 종목 코드
 * @param {Object} data - API 응답 데이터
 * @param {string} period - 기간 (3, 6, 12)
 */
window.RebotCore.displayOilProductDetail = function(code, data, period = "3") {
    const record = data?.response?.record1?.[0];
    if (!record) {
        this.showBotMessage(`${code} 상세 정보를 찾을 수 없습니다.`, "유가 및 상품");
        return;
    }
    
    // CODE_DATA에서 이모지와 이름 매칭
    const codeInfo = this.CODE_DATA.find(item => item.code === code);
    const emoji = codeInfo?.emoji || '';
    const name = codeInfo?.name || record.isNm;
    
    // 차트 이미지 URL
    const chartUrl = data?.response?.chartUrl || '';
    const fullChartUrl = chartUrl.startsWith('http') ? chartUrl : `https://rc.kbsec.com${chartUrl}`;
    
    // 날짜 포맷팅
    const dateStr = record.dt ? this.formatDateForDisplay(record.dt) : '';
    
    // 가격 및 등락 정보
    const price = parseFloat(record.nowPrc || 0).toFixed(2);
    const cmpr = parseFloat(record.cmpr || 0);
    const rate = parseFloat(record.cmprr || 0);
    const rateStr = (rate >= 0 ? '+' : '') + rate.toFixed(2);
    const rateColor = rate >= 0 ? '#c00' : '#00c';
    const arrow = cmpr >= 0 ? '△' : '▽';
    const cmprStr = Math.abs(cmpr).toFixed(2);
    
    let html = '';
    
    // 차트 이미지
    if (chartUrl) {
        html += `<a id="chatBotChart" href="javascript:void(0)">`;
        html += `<img src="${fullChartUrl}" width="230px" height="150px" alt="${name} 차트">`;
        html += `</a><br><br>`;
    }
    
    // 상품 정보
    html += `<font class="font_B">${name}</font>`;
    if (dateStr) {
        html += ` (${dateStr})`;
    }
    html += `<br>`;
    html += `${price} ${arrow}${cmprStr} <span style="color: ${rateColor};">${rateStr}%</span>`;
    
    // 기간 선택 버튼 (상단)
    const periodButtonHtml = `
        <div id="query-rl-btn-sm" class="query__rl__btn__sm">
            <div class="query__rl__btn__wrapper__sm">
                <button type="button" class="query__rl__it__sm" data-role="" onclick="window.RebotCore.oilProduct('D', '3');">3개월</button>
            </div>
            <div class="query__rl__btn__wrapper__sm">
                <button type="button" class="query__rl__it__sm" data-role="" onclick="window.RebotCore.oilProduct('D', '6');">6개월</button>
            </div>
            <div class="query__rl__btn__wrapper__sm">
                <button type="button" class="query__rl__it__sm" data-role="" onclick="window.RebotCore.oilProduct('D', '9');">9개월</button>
            </div>
            <div class="query__rl__btn__wrapper__sm">
                <button type="button" class="query__rl__it__sm" data-role="" onclick="window.RebotCore.oilProduct('D', '12');">1년</button>
            </div>
        </div>
    `;
    
    // 종목 선택 버튼 (하단)
    const productButtonHtml = `
        <div id="query-rl-btn-sm" class="query__rl__btn__sm">
            <div class="query__rl__btn__wrapper__sm">
                <button type="button" class="query__rl__it__sm" data-role="" onclick="window.RebotCore.oilProduct('T', 'NYM@CL');">WTI</button>
            </div>
            <div class="query__rl__btn__wrapper__sm">
                <button type="button" class="query__rl__it__sm" data-role="" onclick="window.RebotCore.oilProduct('T', 'SPT@DU');">두바이</button>
            </div>
            <div class="query__rl__btn__wrapper__sm">
                <button type="button" class="query__rl__it__sm" data-role="" onclick="window.RebotCore.oilProduct('T', 'IPE@EB');">브렌트</button>
            </div>
            <div class="query__rl__btn__wrapper__sm">
                <button type="button" class="query__rl__it__sm" data-role="" onclick="window.RebotCore.oilProduct('T', 'COM@GC');">금</button>
            </div>
            <div class="query__rl__btn__wrapper__sm">
                <button type="button" class="query__rl__it__sm" data-role="" onclick="window.RebotCore.oilProduct('T', 'COM@SI');">은</button>
            </div>
            <div class="query__rl__btn__wrapper__sm">
                <button type="button" class="query__rl__it__sm" data-role="" onclick="window.RebotCore.oilProduct('T', 'COM@HG');">구리</button>
            </div>
        </div>
    `;
    
    // HTML 메시지로 표시
    const currentTime = this.formatTimeWithPeriod();
    const botMessageHtml = `
        <div class="prompt__cont">
            <div class="prompt__src sr_only" data-role="">
                query:
            </div>
            <div class="prompt__query_box">
                <div class="prompt__txt_adjust">
                    <div class="prompt__query_title">유가 및 상품</div>
                    <div class="prompt__model_chosen">
                        rebot thinking
                        <img src="icons/gr_ic.svg" alt="">
                    </div>
                </div>
            </div>
            <div class="chatOutBox">
                <div class="chatOutTd">
                    <span>
                        ${html}
                    </span>
                    <span class="fr mt5 ml10 c_6" style="font-size:9px">${currentTime}</span>
                </div>
                ${periodButtonHtml}
                ${productButtonHtml}
                <div style="clear:both"></div>
            </div>
            <div class="prompt__txt_box">
                <div class="prompt__txt_adjust">
                    <div class="prompt__timestamp">${currentTime}</div>
                </div>
            </div>
        </div>
    `;
    
    this.addMessageToChat(botMessageHtml, 'query');
};

/**
 * 종목 코드로 clsf 반환 (21: 유가, 22: 상품)
 */
window.RebotCore.getClsfFromCode = function(code) {
    const oilCodes = ['NYM@CL', 'SPT@DU', 'IPE@EB'];
    return oilCodes.includes(code) ? '21' : '22';
};

/**
 * 금리/환율 정보 조회
 * @param typeChk - D: 기간 버튼 클릭, T: 금리/환율 버튼 클릭
 * @param valueChk - "": 최초 조회, "01"/"02"/"03": 환율 코드, "61"/"12"/"14": 금리 코드
 */
window.RebotCore.exchange = function(typeChk, valueChk) {
        this.showBotMessage("금리/환율 정보를 조회합니다...", "금리 및 환율");
    
    // 최초 조회인 경우
    if (!valueChk || valueChk === "") {
        const useSample = this.config.useSampleData();
        
        if (useSample && window.getNowAndDtCrncyRPrcss01 && window.getNowAndDtCrncyRPrcss02 && 
            window.getNowAndDtCrncyRPrcss03 && window.getMainScrtMrktTrndDy) {
            console.log("[개발 모드] 금리/환율 샘플 데이터 사용");
            setTimeout(() => {
                this.displayExchangeData(
                    window.getNowAndDtCrncyRPrcss01,
                    window.getNowAndDtCrncyRPrcss02,
                    window.getNowAndDtCrncyRPrcss03,
                    window.getMainScrtMrktTrndDy
                );
            }, 500);
        } else {
            console.log("[프로덕션 모드] 금리/환율 API 호출");
            // 환율 3개 API 동시 호출
            const today = new Date();
            const endDate = this.formatDateToYYYYMMDD(today);
            const startDate = new Date(today);
            startDate.setDate(startDate.getDate() - 30);
            const strtDate = this.formatDateToYYYYMMDD(startDate);
            
            Promise.all([
                this.ajaxCall("/ajax/getNowAndDtCrncyRPrcss.json", { crncyRTyp: "01" }, (data) => data, (error) => { console.error("원/달러 조회 실패:", error); return null; }),
                this.ajaxCall("/ajax/getNowAndDtCrncyRPrcss.json", { crncyRTyp: "02" }, (data) => data, (error) => { console.error("엔/달러 조회 실패:", error); return null; }),
                this.ajaxCall("/ajax/getNowAndDtCrncyRPrcss.json", { crncyRTyp: "03" }, (data) => data, (error) => { console.error("유로/달러 조회 실패:", error); return null; }),
                this.ajaxCall("/ajax/getMainScrtMrktTrndDy.json", { chartYn: "", dataClsf2: "", end_date: endDate, period: "", strt_date: strtDate }, (data) => data, (error) => { console.error("금리 조회 실패:", error); return null; })
            ]).then(([data1, data2, data3, data4]) => {
                this.displayExchangeData(data1, data2, data3, data4);
            });
        }
        return;
    }
    
    // 버튼 클릭 시 상세 조회
    if (valueChk && valueChk !== "") {
        if (typeChk === "D") {
            // 기간 선택인 경우 (period: 3, 6, 12)
            const currentCode = this.currentExchangeCode || "61"; // 기본값 CD
            const today = new Date();
            const endDate = this.formatDateToYYYYMMDD(today);
            const startDate = new Date(today);
            startDate.setDate(startDate.getDate() - 30);
            const strtDate = this.formatDateToYYYYMMDD(startDate);
            
            // 금리 항목인지 확인
            const isRate = ["61", "12", "14"].includes(currentCode);
            
            if (isRate) {
                // 금리 기간 선택
    const params = {
                    chartYn: "Y",
                    dataClsf2: currentCode,
                    end_date: endDate,
                    period: valueChk,
                    strt_date: strtDate
                };
                
                const useSample = this.config.useSampleData();
                if (useSample && window.getMainScrtMrktTrndDy) {
                    console.log("[개발 모드] 금리 상세 샘플 데이터 사용");
                    setTimeout(() => {
                        const sampleData = JSON.parse(JSON.stringify(window.getMainScrtMrktTrndDy)); // 깊은 복사
                        // 차트 URL에 period 반영
                        if (sampleData.response && sampleData.response.chartUrl) {
                            // period 패턴이 있는 경우 교체 (예: chart_61_3_xxx.png -> chart_61_6_xxx.png)
                            const chartUrl = sampleData.response.chartUrl;
                            // period 값이 URL에 포함된 경우 교체
                            sampleData.response.chartUrl = chartUrl.replace(/_(\d+)_/, `_${valueChk}_`);
                        }
                        this.displayExchangeDetail(currentCode, sampleData, valueChk);
                    }, 500);
                } else {
                    console.log("[프로덕션 모드] 금리 상세 API 호출");
                    this.ajaxCall("/ajax/getMainScrtMrktTrndDy.json", params, (data) => {
                        this.displayExchangeDetail(currentCode, data, valueChk);
                    }, (error) => {
                        console.error("금리 상세 조회 실패:", error);
                    });
                }
            } else {
                // 환율 기간 선택
                const crncyRTyp = currentCode; // "01", "02", "03"
                const params = {
                    chartYn: "Y",
                    crncyRTyp: crncyRTyp,
                    period: valueChk
                };
                
                const useSample = this.config.useSampleData();
                if (useSample) {
                    let sampleData = null;
                    if (crncyRTyp === "01" && window.getNowAndDtCrncyRPrcss01) {
                        sampleData = JSON.parse(JSON.stringify(window.getNowAndDtCrncyRPrcss01));
                    } else if (crncyRTyp === "02" && window.getNowAndDtCrncyRPrcss02) {
                        sampleData = JSON.parse(JSON.stringify(window.getNowAndDtCrncyRPrcss02));
                    } else if (crncyRTyp === "03" && window.getNowAndDtCrncyRPrcss03) {
                        sampleData = JSON.parse(JSON.stringify(window.getNowAndDtCrncyRPrcss03));
                    }
                    
                    if (sampleData) {
                        console.log("[개발 모드] 환율 상세 샘플 데이터 사용");
                        setTimeout(() => {
                            // 차트 URL에 period 반영
                            if (sampleData.response && sampleData.response.chartUrl) {
                                const chartUrl = sampleData.response.chartUrl;
                                sampleData.response.chartUrl = chartUrl.replace(/_(\d+)_/, `_${valueChk}_`);
                            }
                            this.displayExchangeDetail(currentCode, sampleData, valueChk);
                        }, 500);
                        return;
                    }
                }
                
                console.log("[프로덕션 모드] 환율 상세 API 호출");
    this.ajaxCall("/ajax/getNowAndDtCrncyRPrcss.json", params, (data) => {
                    this.displayExchangeDetail(currentCode, data, valueChk);
    }, (error) => {
                    console.error("환율 상세 조회 실패:", error);
                });
            }
            return;
        } else if (typeChk === "T") {
            // 항목 선택인 경우
            this.currentExchangeCode = valueChk;
            const today = new Date();
            const endDate = this.formatDateToYYYYMMDD(today);
            const startDate = new Date(today);
            startDate.setDate(startDate.getDate() - 30);
            const strtDate = this.formatDateToYYYYMMDD(startDate);
            
            // 금리 항목인지 확인
            const isRate = ["61", "12", "14"].includes(valueChk);
            
            if (isRate) {
                // 금리 상세 조회
                const params = {
                    chartYn: "Y",
                    dataClsf2: valueChk,
                    end_date: endDate,
                    period: "3", // 기본값 3개월
                    strt_date: strtDate
                };
                
                const useSample = this.config.useSampleData();
                if (useSample && window.getMainScrtMrktTrndDy) {
                    console.log("[개발 모드] 금리 상세 샘플 데이터 사용");
                    setTimeout(() => {
                        this.displayExchangeDetail(valueChk, window.getMainScrtMrktTrndDy, "3");
                    }, 500);
                } else {
                    console.log("[프로덕션 모드] 금리 상세 API 호출");
                    this.ajaxCall("/ajax/getMainScrtMrktTrndDy.json", params, (data) => {
                        this.displayExchangeDetail(valueChk, data, "3");
                    }, (error) => {
                        console.error("금리 상세 조회 실패:", error);
                    });
                }
            } else {
                // 환율 상세 조회 (차트 포함)
                const crncyRTyp = valueChk; // "01", "02", "03"
                const params = {
                    chartYn: "Y",
                    crncyRTyp: crncyRTyp,
                    period: "3" // 기본값 3개월
                };
                
                const useSample = this.config.useSampleData();
                if (useSample) {
                    let sampleData = null;
                    if (crncyRTyp === "01" && window.getNowAndDtCrncyRPrcss01) {
                        sampleData = window.getNowAndDtCrncyRPrcss01;
                    } else if (crncyRTyp === "02" && window.getNowAndDtCrncyRPrcss02) {
                        sampleData = window.getNowAndDtCrncyRPrcss02;
                    } else if (crncyRTyp === "03" && window.getNowAndDtCrncyRPrcss03) {
                        sampleData = window.getNowAndDtCrncyRPrcss03;
                    }
                    
                    if (sampleData) {
                        console.log("[개발 모드] 환율 상세 샘플 데이터 사용");
                        setTimeout(() => {
                            this.displayExchangeDetail(valueChk, sampleData, "3");
                        }, 500);
                        return;
                    }
                }
                
                console.log("[프로덕션 모드] 환율 상세 API 호출");
                this.ajaxCall("/ajax/getNowAndDtCrncyRPrcss.json", params, (data) => {
                    this.displayExchangeDetail(valueChk, data, "3");
                }, (error) => {
                    console.error("환율 상세 조회 실패:", error);
                });
            }
            return;
        }
    }
};

/**
 * 금리/환율 데이터 표시
 */
window.RebotCore.displayExchangeData = function(data1, data2, data3, data4) {
    if (!data1 || !data2 || !data3 || !data4) {
        console.error("금리/환율 데이터 불완전");
        this.showBotMessage("금리/환율 정보를 조회하는 중 오류가 발생했습니다.", "금리 및 환율");
        return;
    }
    
    let html = '';
    
    // 금리 데이터 처리 (getMainScrtMrktTrndDy)
    if (data4.response && data4.response.record1 && data4.response.record1.length > 0) {
        const resData = data4.response.record1[0];
        const dateStr = resData.dt ? this.formatDateForDisplay(resData.dt) : '';
        
        // 금리: amt1=CD, amt2=국고3년, amt3=국고10년
        // EXCN_DATA 인덱스: 3=CD(61), 4=국고3년(12), 5=국고10년(14)
        const rateData = [
            { amt: resData.amt1, bdyRt: resData.bdyRt1, code: "61", name: "CD" },
            { amt: resData.amt2, bdyRt: resData.bdyRt2, code: "12", name: "국고3년" },
            { amt: resData.amt3, bdyRt: resData.bdyRt3, code: "14", name: "국고10년" }
        ];
        
        rateData.forEach((rate, index) => {
            const price = rate.amt ? (Number(rate.amt) / 100).toFixed(2) + "%" : "0.00%";
            const bp = rate.bdyRt ? Number(rate.bdyRt).toFixed() : "0";
            const bpStr = bp >= 0 ? ` ${bp} bp` : `${bp} bp`;
            
            html += `🏦 <font class="font_B">${rate.name}</font> (${dateStr})<br>`;
            html += `${price}${bpStr}`;
            if (index < 2) html += `<br><br>`;
        });
    }
    
    // 환율 데이터 처리
    const exchangeData = [
        { data: data1, index: 0 }, // 원/달러
        { data: data2, index: 1 }, // 엔/달러
        { data: data3, index: 2 }  // 유로/달러
    ];
    
    exchangeData.forEach((exch, idx) => {
        if (!exch.data || !exch.data.response) return;
        
        const res = exch.data.response;
        const dateStr = res.dt ? this.formatDateForDisplay(res.dt) : '';
        
        // 가격 포맷팅
        let price = "0.00";
        if (res.nowPrc) {
            if (idx === 0) {
                // 원/달러: 100배 값 (144575 -> 1445.75)
                price = (Number(res.nowPrc) / 100).toFixed(2);
            } else if (idx === 1) {
                // 엔/달러: 그대로 (153 -> 153.00)
                price = Number(res.nowPrc).toFixed(2);
            } else {
                // 유로/달러: 100배 값 (087 -> 0.87)
                price = (Number(res.nowPrc) / 100).toFixed(2);
            }
        }
        
        // 등락률 포맷팅 (upDwnR는 100배 값, 예: 055 -> 0.55%, -010 -> -0.10%)
        let rate = "0.00";
        let rateSign = "";
        if (res.upDwnR) {
            const rateNum = Number(res.upDwnR) / 100;
            rate = Math.abs(rateNum).toFixed(2);
            rateSign = rateNum >= 0 ? "+" : "-";
        }
        
        const excnInfo = this.EXCN_DATA[idx];
        const emoji = excnInfo ? excnInfo.emoji : "💵";
        const name = excnInfo ? excnInfo.name : "환율";
        
        html += `<br><br>${emoji} <font class="font_B">${name}</font> (${dateStr})<br>`;
        html += `${price}　　${rateSign}${rate}%`;
    });
    
    // 버튼 HTML (query__rl__btn__sm 스타일 적용)
    const rateButtonHtml = `
        <div id="query-rl-btn-sm" class="query__rl__btn__sm">
            <div class="query__rl__btn__wrapper__sm">
                <button type="button" class="query__rl__it__sm" data-role="" onclick="window.RebotCore.exchange('T', '61');">CD</button>
            </div>
            <div class="query__rl__btn__wrapper__sm">
                <button type="button" class="query__rl__it__sm" data-role="" onclick="window.RebotCore.exchange('T', '12');">국고3년</button>
            </div>
            <div class="query__rl__btn__wrapper__sm">
                <button type="button" class="query__rl__it__sm" data-role="" onclick="window.RebotCore.exchange('T', '14');">국고10년</button>
            </div>
        </div>
    `;
    
    const exchangeButtonHtml = `
        <div id="query-rl-btn-sm" class="query__rl__btn__sm">
            <div class="query__rl__btn__wrapper__sm">
                <button type="button" class="query__rl__it__sm" data-role="" onclick="window.RebotCore.exchange('T', '01');">원/달러</button>
            </div>
            <div class="query__rl__btn__wrapper__sm">
                <button type="button" class="query__rl__it__sm" data-role="" onclick="window.RebotCore.exchange('T', '02');">엔/달러</button>
            </div>
            <div class="query__rl__btn__wrapper__sm">
                <button type="button" class="query__rl__it__sm" data-role="" onclick="window.RebotCore.exchange('T', '03');">유로/달러</button>
            </div>
        </div>
    `;
    
    // HTML 메시지로 표시
    const currentTime = this.formatTimeWithPeriod();
    const botMessageHtml = `
        <div class="prompt__cont">
            <div class="prompt__src sr_only" data-role="">
                query:
            </div>
            <div class="prompt__query_box">
                <div class="prompt__txt_adjust">
                    <div class="prompt__query_title">금리 및 환율</div>
                    <div class="prompt__model_chosen">
                        rebot thinking
                        <img src="icons/gr_ic.svg" alt="">
                    </div>
                </div>
            </div>
            <div class="chatOutTd">
                <span>
                    ${html}
                </span>
            </div>
            ${rateButtonHtml}
            ${exchangeButtonHtml}
        </div>
    `;
    
    this.addMessageToChat(botMessageHtml, 'query');
};

/**
 * 금리/환율 상세 정보 표시 (특정 항목 클릭 시)
 * @param {string} code - 항목 코드 (금리: "61", "12", "14", 환율: "01", "02", "03")
 * @param {Object} data - API 응답 데이터
 * @param {string} period - 기간 (금리만: "3", "6", "12", 환율은 "")
 */
window.RebotCore.displayExchangeDetail = function(code, data, period = "") {
    // EXCN_DATA에서 정보 찾기
    const codeInfo = this.EXCN_DATA.find(item => item.code === code);
    if (!codeInfo) {
        this.showBotMessage(`${code} 상세 정보를 찾을 수 없습니다.`, "금리 및 환율");
        return;
    }
    
    const isRate = codeInfo.type === "cd"; // 금리인지 확인
    const name = codeInfo.name;
    const emoji = codeInfo.emoji;
    
    let html = '';
    
    // 금리인 경우
    if (isRate) {
        const record = data?.response?.record1?.[0];
        if (!record) {
            this.showBotMessage(`${name} 상세 정보를 찾을 수 없습니다.`, "금리 및 환율");
            return;
        }
        
        // 차트 이미지 URL 처리
        const chartUrl = data?.response?.chartUrl;
        let fullChartUrl = '';
        
        if (chartUrl && chartUrl !== null && chartUrl !== '') {
            // 이미 전체 URL인 경우
            if (chartUrl.startsWith('http://') || chartUrl.startsWith('https://')) {
                fullChartUrl = chartUrl;
            } else {
                // 상대 경로인 경우
                fullChartUrl = `https://rc.kbsec.com${chartUrl.startsWith('/') ? chartUrl : '/' + chartUrl}`;
            }
        }
        
        // 날짜 포맷팅
        const dateStr = record.dt ? this.formatDateForDisplay(record.dt) : '';
        
        // 금리 데이터: amt1, amt2, amt3 중 해당하는 것 선택
        let amt = "0";
        let bdyRt = "0";
        if (code === "61") {
            amt = record.amt1 || "0";
            bdyRt = record.bdyRt1 || "0";
        } else if (code === "12") {
            amt = record.amt2 || "0";
            bdyRt = record.bdyRt2 || "0";
        } else if (code === "14") {
            amt = record.amt3 || "0";
            bdyRt = record.bdyRt3 || "0";
        }
        
        // 가격 및 등락 정보
        const price = amt ? (Number(amt) / 100).toFixed(2) + "%" : "0.00%";
        const bp = Number(bdyRt);
        const bpStr = bp >= 0 ? ` ▲${Math.abs(bp)} bp` : ` ▼${Math.abs(bp)} bp`;
        
        // 차트 이미지 표시 (URL이 있으면 무조건 표시)
        if (fullChartUrl) {
            html += `<a id="chatBotChart" href="javascript:void(0)">`;
            html += `<img src="${fullChartUrl}" width="230px" height="150px" alt="${name} 차트">`;
            html += `</a><br><br>`;
        }
        
        // 금리 정보
        html += `<font class="font_B">${name}</font>`;
        if (dateStr) {
            html += ` (${dateStr})`;
        }
        html += `<br>`;
        html += `${price}${bpStr}`;
        
        // 기간 선택 버튼 (상단) - 금리 항목인 경우에만 표시
        const periodButtonHtml = `
            <div id="query-rl-btn-sm" class="query__rl__btn__sm">
                <div class="query__rl__btn__wrapper__sm">
                    <button type="button" class="query__rl__it__sm" data-role="" onclick="window.RebotCore.exchange('D', '3');">3개월</button>
                </div>
                <div class="query__rl__btn__wrapper__sm">
                    <button type="button" class="query__rl__it__sm" data-role="" onclick="window.RebotCore.exchange('D', '6');">6개월</button>
                </div>
                <div class="query__rl__btn__wrapper__sm">
                    <button type="button" class="query__rl__it__sm" data-role="" onclick="window.RebotCore.exchange('D', '12');">1년</button>
                </div>
            </div>
        `;
        
        // 금리 선택 버튼 (하단)
        const rateButtonHtml = `
            <div id="query-rl-btn-sm" class="query__rl__btn__sm">
                <div class="query__rl__btn__wrapper__sm">
                    <button type="button" class="query__rl__it__sm" data-role="" onclick="window.RebotCore.exchange('T', '61');">CD</button>
                </div>
                <div class="query__rl__btn__wrapper__sm">
                    <button type="button" class="query__rl__it__sm" data-role="" onclick="window.RebotCore.exchange('T', '12');">국고3년</button>
                </div>
                <div class="query__rl__btn__wrapper__sm">
                    <button type="button" class="query__rl__it__sm" data-role="" onclick="window.RebotCore.exchange('T', '14');">국고10년</button>
                </div>
            </div>
        `;
        
        // 환율 선택 버튼 (하단)
        const exchangeButtonHtml = `
            <div id="query-rl-btn-sm" class="query__rl__btn__sm">
                <div class="query__rl__btn__wrapper__sm">
                    <button type="button" class="query__rl__it__sm" data-role="" onclick="window.RebotCore.exchange('T', '01');">원/달러</button>
                </div>
                <div class="query__rl__btn__wrapper__sm">
                    <button type="button" class="query__rl__it__sm" data-role="" onclick="window.RebotCore.exchange('T', '02');">엔/달러</button>
                </div>
                <div class="query__rl__btn__wrapper__sm">
                    <button type="button" class="query__rl__it__sm" data-role="" onclick="window.RebotCore.exchange('T', '03');">유로/달러</button>
                </div>
            </div>
        `;
        
        // HTML 메시지로 표시
        const currentTime = this.formatTimeWithPeriod();
        const botMessageHtml = `
            <div class="prompt__cont">
                <div class="prompt__src sr_only" data-role="">
                    query:
                </div>
                <div class="prompt__query_box">
                    <div class="prompt__txt_adjust">
                        <div class="prompt__query_title">금리 및 환율</div>
                        <div class="prompt__model_chosen">
                            rebot thinking
                            <img src="icons/gr_ic.svg" alt="">
                        </div>
                    </div>
                </div>
                <div class="chatOutBox">
                    <div class="chatOutTd">
                        <span>
                            ${html}
                        </span>
                        <span class="fr mt5 ml10 c_6" style="font-size:9px">${currentTime}</span>
                    </div>
                    ${periodButtonHtml}
                    ${rateButtonHtml}
                    ${exchangeButtonHtml}
                    <div style="clear:both"></div>
                </div>
                <div class="prompt__txt_box">
                    <div class="prompt__txt_adjust">
                        <div class="prompt__timestamp">${currentTime}</div>
                    </div>
                </div>
            </div>
        `;
        
        this.addMessageToChat(botMessageHtml, 'query');
    } else {
        // 환율인 경우 (차트 포함, 기간 선택 지원)
        const res = data?.response;
        if (!res) {
            this.showBotMessage(`${name} 상세 정보를 찾을 수 없습니다.`, "금리 및 환율");
            return;
        }
        
        // 차트 이미지 URL 처리
        const chartUrl = data?.response?.chartUrl;
        let fullChartUrl = '';
        
        if (chartUrl && chartUrl !== null && chartUrl !== '') {
            // 이미 전체 URL인 경우
            if (chartUrl.startsWith('http://') || chartUrl.startsWith('https://')) {
                fullChartUrl = chartUrl;
            } else {
                // 상대 경로인 경우
                fullChartUrl = `https://rc.kbsec.com${chartUrl.startsWith('/') ? chartUrl : '/' + chartUrl}`;
            }
        }
        
        const dateStr = res.dt ? this.formatDateForDisplay(res.dt) : '';
        
        // 가격 포맷팅
        let price = "0.00";
        if (res.nowPrc) {
            if (code === "01") {
                // 원/달러: 100배 값
                price = (Number(res.nowPrc) / 100).toFixed(2);
            } else if (code === "02") {
                // 엔/달러: 그대로
                price = Number(res.nowPrc).toFixed(2);
            } else {
                // 유로/달러: 100배 값
                price = (Number(res.nowPrc) / 100).toFixed(2);
            }
        }
        
        // 등락률 포맷팅
        let rate = "0.00";
        let rateSign = "";
        if (res.upDwnR) {
            const rateNum = Number(res.upDwnR) / 100;
            rate = Math.abs(rateNum).toFixed(2);
            rateSign = rateNum >= 0 ? "+" : "-";
        }
        
        // 차트 이미지 표시 (URL이 있으면 무조건 표시)
        if (fullChartUrl) {
            html += `<a id="chatBotChart" href="javascript:void(0)">`;
            html += `<img src="${fullChartUrl}" width="230px" height="150px" alt="${name} 차트">`;
            html += `</a><br><br>`;
        }
        
        html += `${emoji} <font class="font_B">${name}</font>`;
        if (dateStr) {
            html += ` (${dateStr})`;
        }
        html += `<br>`;
        html += `${price}　　${rateSign}${rate}%`;
        
        // 기간 선택 버튼 (상단) - 환율도 기간 선택 지원
        const periodButtonHtml = `
            <div id="query-rl-btn-sm" class="query__rl__btn__sm">
                <div class="query__rl__btn__wrapper__sm">
                    <button type="button" class="query__rl__it__sm" data-role="" onclick="window.RebotCore.exchange('D', '3');">3개월</button>
                </div>
                <div class="query__rl__btn__wrapper__sm">
                    <button type="button" class="query__rl__it__sm" data-role="" onclick="window.RebotCore.exchange('D', '6');">6개월</button>
                </div>
                <div class="query__rl__btn__wrapper__sm">
                    <button type="button" class="query__rl__it__sm" data-role="" onclick="window.RebotCore.exchange('D', '12');">1년</button>
                </div>
            </div>
        `;
        
        // 금리 선택 버튼 (하단)
        const rateButtonHtml = `
            <div id="query-rl-btn-sm" class="query__rl__btn__sm">
                <div class="query__rl__btn__wrapper__sm">
                    <button type="button" class="query__rl__it__sm" data-role="" onclick="window.RebotCore.exchange('T', '61');">CD</button>
                </div>
                <div class="query__rl__btn__wrapper__sm">
                    <button type="button" class="query__rl__it__sm" data-role="" onclick="window.RebotCore.exchange('T', '12');">국고3년</button>
                </div>
                <div class="query__rl__btn__wrapper__sm">
                    <button type="button" class="query__rl__it__sm" data-role="" onclick="window.RebotCore.exchange('T', '14');">국고10년</button>
                </div>
            </div>
        `;
        
        // 환율 선택 버튼 (하단)
        const exchangeButtonHtml = `
            <div id="query-rl-btn-sm" class="query__rl__btn__sm">
                <div class="query__rl__btn__wrapper__sm">
                    <button type="button" class="query__rl__it__sm" data-role="" onclick="window.RebotCore.exchange('T', '01');">원/달러</button>
                </div>
                <div class="query__rl__btn__wrapper__sm">
                    <button type="button" class="query__rl__it__sm" data-role="" onclick="window.RebotCore.exchange('T', '02');">엔/달러</button>
                </div>
                <div class="query__rl__btn__wrapper__sm">
                    <button type="button" class="query__rl__it__sm" data-role="" onclick="window.RebotCore.exchange('T', '03');">유로/달러</button>
                </div>
            </div>
        `;
        
        // HTML 메시지로 표시
        const currentTime = this.formatTimeWithPeriod();
        const botMessageHtml = `
            <div class="prompt__cont">
                <div class="prompt__src sr_only" data-role="">
                    query:
                </div>
                <div class="prompt__query_box">
                    <div class="prompt__txt_adjust">
                        <div class="prompt__query_title">금리 및 환율</div>
                        <div class="prompt__model_chosen">
                            rebot thinking
                            <img src="icons/gr_ic.svg" alt="">
                        </div>
                    </div>
                </div>
                <div class="chatOutBox">
                    <div class="chatOutTd">
                        <span>
                            ${html}
                        </span>
                        <span class="fr mt5 ml10 c_6" style="font-size:9px">${currentTime}</span>
                    </div>
                    ${periodButtonHtml}
                    ${rateButtonHtml}
                    ${exchangeButtonHtml}
                    <div style="clear:both"></div>
                </div>
                <div class="prompt__txt_box">
                    <div class="prompt__txt_adjust">
                        <div class="prompt__timestamp">${currentTime}</div>
                    </div>
                </div>
            </div>
        `;
        
        this.addMessageToChat(botMessageHtml, 'query');
    }
};

/**
 * KB데일리 정보 조회
 */
window.RebotCore.kbDaily = function(typeChk, valueChk) {
        this.showBotMessage("KB데일리 정보를 조회합니다...", "KB 데일리");
    
    // 날짜 계산: 2주 전부터 오늘까지
    const today = new Date();
    const twoWeeksAgo = new Date(today);
    twoWeeksAgo.setDate(today.getDate() - 14);
    
    const params = {
        flag: "I",
        pageNo: 1,
        pageSize: 10,
        registdateFrom: this.formatDateToYYYYMMDD(twoWeeksAgo),
        registdateTo: this.formatDateToYYYYMMDD(today)
    };
    
    const useSample = this.config.useSampleData();
    if (useSample && window.dailyReportList) {
        console.log("[개발 모드] KB데일리 샘플 데이터 사용");
        setTimeout(() => {
            this.displayKBDaily(window.dailyReportList);
        }, 500);
    } else {
        console.log("[프로덕션 모드] KB데일리 API 호출");
        this.ajaxCall("/ajax/dailyReportList.json", params, (data) => {
            this.displayKBDaily(data);
    }, (error) => {
            console.error("KB데일리 조회 실패:", error);
            this.showBotMessage("KB데일리 정보를 조회하는 중 오류가 발생했습니다.", "KB 데일리");
        });
    }
};

/**
 * KB데일리 리포트 목록 표시
 */
window.RebotCore.displayKBDaily = function(data) {
    if (!data || !data.response || !data.response.reportList) {
        this.showBotMessage("KB데일리 정보를 찾을 수 없습니다.", "KB 데일리");
        return;
    }
    
    const reportList = data.response.reportList;
    if (reportList.length === 0) {
        this.showBotMessage("조회 결과가 없습니다.", "KB 데일리");
        return;
    }
    
    let cardsHtml = '';
    
    reportList.forEach((report) => {
        // 카테고리 이름 추출
        let categoryName = "데일리";
        
        // docDetail에서 첫 번째 섹션 제목 찾기 (예: [자산배분전략])
        if (report.docDetail) {
            const sectionMatch = report.docDetail.match(/^\[([^\]]+)\]/);
            if (sectionMatch && sectionMatch[1]) {
                categoryName = sectionMatch[1]; // [자산배분전략] -> 자산배분전략
            } else if (report.foldertemplate) {
                // 섹션 제목이 없으면 foldertemplate에서 추출
                const parts = report.foldertemplate.split('>');
                const lastPart = parts[parts.length - 1];
                if (lastPart.includes("KB데일리") || lastPart.includes("데일리")) {
                    categoryName = "데일리";
                } else if (lastPart) {
                    categoryName = lastPart.trim();
                }
            }
        } else if (report.foldertemplate) {
            // docDetail이 없으면 foldertemplate에서 추출
            const parts = report.foldertemplate.split('>');
            const lastPart = parts[parts.length - 1];
            if (lastPart.includes("KB데일리") || lastPart.includes("데일리")) {
                categoryName = "데일리";
            } else if (lastPart) {
                categoryName = lastPart.trim();
            }
        }
        
        // 제목
        const title = report.docTitle || report.docTitleSub || "제목 없음";
        
        // 서브타이틀 (docDetail에서 섹션 제목 제거하고 5줄 정도)
        let subtitle = "";
        if (report.docDetail) {
            // 첫 번째 섹션 제목 제거
            let content = report.docDetail.replace(/^\[[^\]]+\]\s*\n?/, '');
            
            // 줄바꿈으로 분리하고 5줄까지 가져오기
            const lines = content.split('\n').filter(line => line.trim() !== '');
            const subtitleLines = lines.slice(0, 5);
            subtitle = subtitleLines.join(' ');
            
            // 길이 제한 (300자 정도)
            if (subtitle.length > 300) {
                subtitle = subtitle.substring(0, 300) + "...";
            }
        }
        
        // 작성자
        const author = report.analystNm || "리서치본부";
        
        // 날짜 포맷팅 (YYYY-MM-DD 형식)
        let dateStr = "";
        if (report.publicDate) {
            dateStr = report.publicDate; // 이미 YYYY-MM-DD 형식
        } else if (report.publicTime) {
            // 시간만 있는 경우 현재 날짜 사용
            dateStr = new Date().toISOString().split('T')[0];
        }
        
        // 링크 URL
        const linkUrl = report.urlLinkH || report.urlLink || "#";
        
        // 카드 HTML 생성
        cardsHtml += `
            <div class="report__card__box__wrapper">
                <div class="report__card__wrapper" data-id="${report.documentid || ''}">
                    <div class="report__card__items">
                        <div class="report__card__item__box">
                            <div class="report__card__item__wrapper">
                                <div id="report-name-chip" class="report__name__chip">${categoryName}</div>
                                <div class="report__card__title__wrapper">
                                    <p id="report-card-title" class="report__card__title" data-id="${report.documentid || ''}" data-name="${title}">${title}</p>
                                </div>
                                <div class="report__card__subtitle__wrapper">
                                    <p id="report-card-subtitle" class="report__card__subtitle" data-id="${report.documentid || ''}" data-name="${subtitle}">${subtitle}</p>
                                </div>
                                <div class="report__card__inner__box">
                                    <div class="report__card__textbox">
                                        <div class="report__card__info_row">by&nbsp;<span id="report-card-info" class="report__card__info">${author}</span></div>
                                        <p id="report-card-timestamp" class="report__card__timestamp">${dateStr}</p>
                                    </div>
                                    <a href="${linkUrl}" id="report-more-btn" class="card__more__btn" target="_blank" onclick="window.RebotCore.linkOpen('${linkUrl}'); return false;">자세히 보기</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    });
    
    // 전체 HTML 구조
    const currentTime = this.formatTimeWithPeriod();
    const botMessageHtml = `
        <div class="prompt__cont">
            <div class="prompt__src sr_only" data-role="">
                query:
            </div>
            <div class="prompt__query_box">
                <div class="prompt__txt_adjust">
                    <div class="prompt__query_title">KB 데일리</div>
                    <div class="prompt__model_chosen">
                        rebot thinking
                        <img src="icons/gr_ic.svg" alt="">
                    </div>
                </div>
                <div id="report-card-comp" class="report__card__comp">
                    <div id="card-box" class="report__card__box">
                        ${cardsHtml}
                    </div>
                </div>
            </div>
        </div>
    `;
    
    this.addMessageToChat(botMessageHtml, 'query');
};

/**
 * 최신리포트 조회
 */
window.RebotCore.todayReport = function() {
        this.showBotMessage("최신리포트를 조회합니다...", "최신 리포트");
    
    const params = {
        category: "",
        flag: "I",
        keyword: "",
        pageNo: 1,
        pageSize: 5,
        stockCode: ""
    };
    
    const useSample = this.config.useSampleData();
    if (useSample && window.getChatbotRecentReportList) {
        console.log("[개발 모드] 최신리포트 샘플 데이터 사용");
        setTimeout(() => {
            this.displayRecentReportList(window.getChatbotRecentReportList);
        }, 500);
    } else {
        console.log("[프로덕션 모드] 최신리포트 API 호출");
        this.ajaxCall("/ajax/getChatbotRecentReportList.json", params, (data) => {
            this.displayRecentReportList(data);
    }, (error) => {
            console.error("최신리포트 조회 실패:", error);
            this.showBotMessage("최신리포트 정보를 조회하는 중 오류가 발생했습니다.", "최신 리포트");
        });
    }
};

/**
 * 최신리포트 목록 표시
 */
window.RebotCore.displayRecentReportList = function(data) {
    if (!data || !data.response || !Array.isArray(data.response) || data.response.length === 0) {
        this.showBotMessage("최신리포트 정보를 찾을 수 없습니다.", "최신 리포트");
        return;
    }
    
    const reportList = data.response;
    let cardsHtml = '';
    
    reportList.forEach((report) => {
        // 타이틀 파싱: "[11-05] AI 실적속보: SK바이오팜 (326030) - 3Q25 실적속보: 컨센서스 상회 / 김혜민"
        const title = report.title || "";
        
        // 카테고리: [11-05] -> 11-05
        let categoryName = "";
        const dateMatch = title.match(/^\[([^\]]+)\]/);
        if (dateMatch && dateMatch[1]) {
            categoryName = dateMatch[1];
        } else {
            categoryName = "리포트";
        }
        
        // 제목: "-" 전까지
        let reportTitle = "";
        let subtitle = "";
        let author = "";
        
        if (title.includes(" - ")) {
            const parts = title.split(" - ");
            // 첫 부분에서 날짜 제거
            reportTitle = parts[0].replace(/^\[[^\]]+\]\s*/, "").trim();
            
            // 두 번째 부분에서 작성자 추출
            if (parts[1] && parts[1].includes(" / ")) {
                const subtitleParts = parts[1].split(" / ");
                subtitle = subtitleParts[0].trim();
                author = subtitleParts[1] ? subtitleParts[1].trim() : "";
            } else {
                subtitle = parts[1] ? parts[1].trim() : "";
            }
        } else {
            // "-"가 없는 경우, 날짜만 제거
            reportTitle = title.replace(/^\[[^\]]+\]\s*/, "").trim();
            // "/"로 분리
            if (title.includes(" / ")) {
                const parts = title.split(" / ");
                reportTitle = parts[0].replace(/^\[[^\]]+\]\s*/, "").trim();
                author = parts[1] ? parts[1].trim() : "";
            }
        }
        
        // 날짜 포맷팅 (카테고리에서 추출한 날짜 사용)
        const dateStr = categoryName || "";
        
        // 링크 URL
        const linkUrl = report.urlLinkH ? report.urlLinkH.replace(/^▶\s*/, "") : (report.urlLink || "#");
        
        // 카드 HTML 생성
        cardsHtml += `
            <div class="report__card__box__wrapper">
                <div class="report__card__wrapper" data-id="${report.documentid || ''}">
                    <div class="report__card__items">
                        <div class="report__card__item__box">
                            <div class="report__card__item__wrapper">
                                <div id="report-name-chip" class="report__name__chip">${categoryName}</div>
                                <div class="report__card__title__wrapper">
                                    <p id="report-card-title" class="report__card__title" data-id="${report.documentid || ''}" data-name="${reportTitle}">${reportTitle}</p>
                                </div>
                                <div class="report__card__subtitle__wrapper">
                                    <p id="report-card-subtitle" class="report__card__subtitle" data-id="${report.documentid || ''}" data-name="${subtitle}">${subtitle}</p>
                                </div>
                                <div class="report__card__inner__box">
                                    <div class="report__card__textbox">
                                        <div class="report__card__info_row">by&nbsp;<span id="report-card-info" class="report__card__info">${author}</span></div>
                                        <p id="report-card-timestamp" class="report__card__timestamp">${dateStr}</p>
                                    </div>
                                    <a href="${linkUrl}" id="report-more-btn" class="card__more__btn" target="_blank" onclick="window.RebotCore.linkOpen('${linkUrl}'); return false;">자세히 보기</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    });
    
    // 전체 HTML 구조
    const currentTime = this.formatTimeWithPeriod();
    const botMessageHtml = `
        <div class="prompt__cont">
            <div class="prompt__src sr_only" data-role="">
                query:
            </div>
            <div class="prompt__query_box">
                <div class="prompt__txt_adjust">
                    <div class="prompt__query_title">최신 리포트</div>
                    <div class="prompt__model_chosen">
                        rebot thinking
                        <img src="icons/gr_ic.svg" alt="">
                    </div>
                </div>
                <div id="report-card-comp" class="report__card__comp">
                    <div id="card-box" class="report__card__box">
                        ${cardsHtml}
                    </div>
                </div>
            </div>
        </div>
    `;
    
    this.addMessageToChat(botMessageHtml, 'query');
};

/**
 * 캘린더 정보 조회
 */
window.RebotCore.calendar = function(typeChk, valueChk) {
    const params = {
        date: new Date().toISOString().split('T')[0]
    };
    
    this.ajaxCall("/ajax/getCalendarView.json", params, (data) => {
        // API 성공 시 실제 데이터로 복잡한 구조 표시
        this.showComplexResult("캘린더", data);
    }, (error) => {
        // API 실패 시 샘플 데이터로 복잡한 구조 표시
        console.log("캘린더 API 실패, 샘플 데이터 사용:", error);
        this.showComplexResult("캘린더", null);
    });
};

/**
 * 애널리스트 정보 조회
 */
window.RebotCore.analyst = function(typeChk, valueChk) {
    const params = {
        type: "analyst"
    };
    
    this.ajaxCall("/ajax/getChatbotRecentReportList.json", params, (data) => {
        // API 성공 시 실제 데이터로 복잡한 구조 표시
        this.showComplexResult("애널리스트", data);
    }, (error) => {
        // API 실패 시 샘플 데이터로 복잡한 구조 표시
        this.showComplexResult("애널리스트", null);
    });
};

/**
 * 일반 검색 (AI 질문 API 호출로 변경)
 */
window.RebotCore.generalSearch = function(searchTerm) {
    console.log("AI 질문 처리 시작:", searchTerm);
    this.handleAIQuestion(searchTerm);
};

/**
 * AI 질문 처리
 * @param {string} userInput - 사용자 입력
 */
window.RebotCore.handleAIQuestion = function(userInput) {
    console.log("AI 질문 처리:", userInput);
    
    // 로딩 상태 표시
    this.showAILoadingState(userInput);
    
    // AI API 호출
    this.callAIQuestionAPI(userInput)
        .then(response => {
            this.showAIResponse(response, userInput);
        })
        .catch(error => {
            this.showAIError(error, userInput);
        });
};

/**
 * AI 질문 API 호출
 * @param {string} userInput - 사용자 입력
 * @returns {Promise} AI 응답 Promise
 */
window.RebotCore.callAIQuestionAPI = function(userInput) {
    const requestData = {
        user_role: this.getUserRole() || "",
        user_id: this.getUserId() || "",
        messages: [
            {
                role: "user",
                content: userInput
            }
        ],
        model_id: "antropic"
    };

    console.log("AI API 요청 데이터:", requestData);

    return new Promise((resolve, reject) => {
        $.ajax({
            url: this.getAIAPIUrl(), // 외부 AI API URL
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(requestData),
            timeout: 30000, // 30초 타임아웃
            success: (response) => {
                console.log("AI API 응답:", response);
                resolve(response);
            },
            error: (xhr, status, error) => {
                console.error("AI API 오류:", status, error, xhr.responseText);
                reject({
                    code: status === 'timeout' ? 'API_TIMEOUT' : 'API_ERROR',
                    message: error,
                    details: xhr.responseText,
                    status: xhr.status
                });
            }
        });
    });
};

/**
 * AI API URL 반환 (기본값, ai-config.js에서 오버라이드 가능)
 * @returns {string} AI API URL
 */
window.RebotCore.getAIAPIUrl = function() {
    // 기본값 반환 (ai-config.js에서 오버라이드됨)
    return 'https://your-ai-api-endpoint.com/api/chat';
};

/**
 * 사용자 역할 반환 (기본값, ai-config.js에서 오버라이드 가능)
 * @returns {string} 사용자 역할
 */
window.RebotCore.getUserRole = function() {
    // 기본값 반환 (ai-config.js에서 오버라이드됨)
    return "user";
};

/**
 * 사용자 ID 반환 (기본값, ai-config.js에서 오버라이드 가능)
 * @returns {string} 사용자 ID
 */
window.RebotCore.getUserId = function() {
    // 기본값 반환 (ai-config.js에서 오버라이드됨)
    return "anonymous_user";
};

/**
 * 디버그 모드 확인 (기본값, ai-config.js에서 오버라이드 가능)
 * @returns {boolean} 디버그 모드 여부
 */
window.RebotCore.isDebugMode = function() {
    // 기본값 반환 (ai-config.js에서 오버라이드됨)
    return false;
};

/**
 * 샘플 응답 반환 (기본값, ai-config.js에서 오버라이드 가능)
 * @returns {Object} 샘플 응답 데이터
 */
window.RebotCore.getSampleResponse = function() {
    // 기본값 반환 (ai-config.js에서 오버라이드됨)
    return {
        "response": {
            "id": "default_response_id",
            "model": "default",
            "role": "assistant",
            "content": "기본 응답입니다.",
            "input_tokens": 0,
            "output_tokens": 0
        },
        "eval_input": {
            "user_query": "기본 질문",
            "response": "기본 응답"
        },
        "chatroom_id": 0,
        "chatlog_id": 0
    };
};

/**
 * AI 로딩 상태 표시
 * @param {string} userInput - 사용자 입력
 */
window.RebotCore.showAILoadingState = function(userInput) {
    const loadingMessage = `
        <div class="prompt__cont">
            <div class="prompt__src sr_only" data-role="">
                query:
            </div>
            <div class="prompt__query_box">
                <div class="prompt__txt_adjust">
                    <div class="prompt__query_title">AI 분석 중...</div>
                    <div class="prompt__model_chosen">
                        rebot thinking
                        <img src="icons/gr_ic.svg" alt="">
                    </div>
                </div>
            </div>
            <div class="prompt__txt_box">
                <div class="prompt__txt_adjust">
                    <div class="prompt__timestamp">${this.formatTimeWithPeriod()}</div>
                </div>
            </div>
        </div>
    `;
    
    this.addMessageToChat(loadingMessage, 'query');
};

/**
 * AI 응답 표시
 * @param {Object} response - AI API 응답
 * @param {string} userInput - 사용자 입력
 */
window.RebotCore.showAIResponse = function(response, userInput) {
    console.log("AI 응답 표시:", response);
    
    // 응답 데이터 추출
    const aiResponse = response.response;
    const aiContent = aiResponse.content;
    const model = aiResponse.model;
    const inputTokens = aiResponse.input_tokens;
    const outputTokens = aiResponse.output_tokens;
    const chatroomId = response.chatroom_id;
    const chatlogId = response.chatlog_id;
    
    // AI 응답 HTML 구성
    const aiResponseHtml = `
        <div class="prompt__cont">
            <div class="prompt__src sr_only" data-role="">
                query:
            </div>
            <div class="prompt__query_box">
                <div class="prompt__txt_adjust">
                    <div class="prompt__query_title">AI 답변</div>
                    <div class="prompt__model_chosen">
                        rebot thinking
                        <img src="icons/gr_ic.svg" alt="">
                    </div>
                </div>
            </div>
            <div class="chatOutTd">
                <span>
                    <div class="ai-response">
                        <div class="ai-answer">${this.processAIContent(aiContent)}</div>
                        <div class="ai-meta">
                            <span class="ai-model">모델: ${model}</span>
                            <span class="ai-tokens">토큰: ${inputTokens}→${outputTokens}</span>
                        </div>
                    </div>
                </span>
            </div>
            <div class="prompt__txt_box">
                <div class="prompt__txt_adjust">
                    <div class="prompt__timestamp">${this.formatTimeWithPeriod()}</div>
                </div>
            </div>
        </div>
    `;
    
    this.addMessageToChat(aiResponseHtml, 'query');
    
    // 채팅 로그 저장 (선택사항)
    this.saveChatLog(chatroomId, chatlogId, userInput, aiContent);
};

/**
 * AI 응답 내용 처리 (3번째 줄부터 출력)
 * @param {string} content - AI 응답 내용
 * @returns {string} 처리된 내용
 */
window.RebotCore.processAIContent = function(content) {
    if (!content) return '';
    
    const lines = content.split('\n');
    if (lines.length <= 2) {
        return content; // 2줄 이하면 그대로 출력
    }
    
    // 3번째 줄부터 출력 (인덱스 2부터)
    return lines.slice(2).join('\n');
};

/**
 * AI 에러 표시
 * @param {Object} error - 에러 정보
 * @param {string} userInput - 사용자 입력
 */
window.RebotCore.showAIError = function(error, userInput) {
    console.error("AI 에러 표시:", error);
    
    let errorMessage = "죄송합니다. AI 서비스에 일시적인 문제가 발생했습니다.";
    let suggestions = [];
    
    // 에러 타입별 메시지 설정
    switch (error.code) {
        case 'API_TIMEOUT':
            errorMessage = "AI 응답 시간이 초과되었습니다. 잠시 후 다시 시도해주세요.";
            suggestions = ["네트워크 연결을 확인해주세요", "잠시 후 다시 시도해주세요"];
            break;
        case 'API_ERROR':
            if (error.status === 401) {
                errorMessage = "AI 서비스 인증에 실패했습니다.";
                suggestions = ["관리자에게 문의해주세요"];
            } else if (error.status === 429) {
                errorMessage = "AI 서비스 사용량이 초과되었습니다.";
                suggestions = ["잠시 후 다시 시도해주세요"];
            } else {
                errorMessage = "AI 서비스에 오류가 발생했습니다.";
                suggestions = ["다른 질문을 시도해보세요", "잠시 후 다시 시도해주세요"];
            }
            break;
        default:
            errorMessage = "알 수 없는 오류가 발생했습니다.";
            suggestions = ["다시 시도해주세요"];
    }
    
    // 에러 메시지 HTML 구성
    const errorHtml = `
        <div class="prompt__cont">
            <div class="prompt__src sr_only" data-role="">
                query:
            </div>
            <div class="prompt__query_box">
                <div class="prompt__txt_adjust">
                    <div class="prompt__query_title">AI 서비스 오류</div>
                    <div class="prompt__model_chosen">
                        rebot thinking
                        <img src="icons/gr_ic.svg" alt="">
                    </div>
                </div>
            </div>
            <div class="chatOutTd">
                <span>
                    <div class="ai-error">
                        <div class="error-message">${errorMessage}</div>
                        ${suggestions.length > 0 ? `
                            <div class="error-suggestions">
                                <div class="suggestion-title">다음 중 하나를 시도해보세요:</div>
                                <ul>
                                    ${suggestions.map(suggestion => `<li>${suggestion}</li>`).join('')}
                                </ul>
                            </div>
                        ` : ''}
                    </div>
                </span>
            </div>
            <div class="prompt__txt_box">
                <div class="prompt__txt_adjust">
                    <div class="prompt__timestamp">${this.formatTimeWithPeriod()}</div>
                </div>
            </div>
        </div>
    `;
    
    this.addMessageToChat(errorHtml, 'query');
};

/**
 * 채팅 메시지를 채팅 영역에 추가
 * @param {string} messageHtml - 추가할 메시지 HTML
 * @param {string} messageType - 메시지 타입 ('sender' 또는 'query')
 */
window.RebotCore.addMessageToChat = function(messageHtml, messageType = 'query') {
    const chatArea = document.getElementById('main-chat-area');
    if (chatArea) {
        const messageElement = document.createElement('article');
        messageElement.className = messageType === 'sender' ? 'prompt__wrapper__sender' : 'prompt__wrapper__query';
        messageElement.setAttribute('data-id', '');
        messageElement.innerHTML = messageHtml;
        
        chatArea.appendChild(messageElement);
        
        // 스크롤을 안전하게 처리
        setTimeout(() => {
            chatArea.scrollTop = Math.min(chatArea.scrollHeight - chatArea.clientHeight, chatArea.scrollHeight);
        }, 0);
    }
};

/**
 * 채팅 로그 저장 (선택사항)
 * @param {number} chatroomId - 채팅방 ID
 * @param {number} chatlogId - 채팅 로그 ID
 * @param {string} userInput - 사용자 입력
 * @param {string} aiResponse - AI 응답
 */
window.RebotCore.saveChatLog = function(chatroomId, chatlogId, userInput, aiResponse) {
    // 실제 구현 시 서버에 채팅 로그 저장
    console.log("채팅 로그 저장:", {
        chatroomId,
        chatlogId,
        userInput,
        aiResponse,
        timestamp: new Date().toISOString()
    });
};

/**
 * 봇 메시지 표시 (기본 텍스트 메시지 - 퍼블리싱된 구조 사용)
 */
window.RebotCore.showBotMessage = function(message, serviceName = null) {
    const titleText = serviceName || 'KB증권 리봇';
    
    const botMessageHtml = `
        <div class="prompt__cont">
            <div class="prompt__src sr_only" data-role="">
                query:
            </div>
            <div class="prompt__query_box">
                <div class="prompt__txt_adjust">
                    <div class="prompt__query_title">${titleText}</div>
                    <div class="prompt__model_chosen">
                        rebot thinking
                        <img src="icons/gr_ic.svg" alt="">
                    </div>
                    <div class="prompt__txt">${message}</div>
            </div>
            <div class="prompt__txt_box">
                <div class="prompt__txt_adjust">
                    <div class="prompt__timestamp">${this.formatTimeWithPeriod()}</div>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    this.addMessageToChat(botMessageHtml, 'query');
};

/**
 * 복잡한 결과 구조 표시 (퍼블리싱된 HTML 구조)
 */
window.RebotCore.showComplexResult = function(serviceType, data) {
    console.log("showComplexResult 호출:", serviceType, data);
    const chatArea = document.getElementById('main-chat-area');
    if (!chatArea) {
        console.log("chatArea를 찾을 수 없습니다");
        return;
    }

    const resultContainer = document.createElement('article');
    resultContainer.className = 'prompt__wrapper__query';
    resultContainer.setAttribute('data-id', '');
    
    // 서비스별 데이터 설정
    const resultData = this.getServiceData(serviceType, data);
    console.log("getServiceData 결과:", resultData);
    console.log("캘린더 데이터 존재 여부:", !!resultData.calendar);
    if (resultData.calendar) {
        console.log("캘린더 days 길이:", resultData.calendar.days.length);
    }
    
    resultContainer.innerHTML = `
        <div class="prompt__cont">
            <div class="prompt__src sr_only" data-role="">
                query:
            </div>
            <div class="prompt__query_box">
                <div class="prompt__txt_adjust">
                    <div class="prompt__query_title">
                        ${serviceType}
                    </div>
                    <div class="prompt__model_chosen">
                        rebot thinking
                        <img src="icons/gr_ic.svg" alt="">
                    </div>
                    <div class="prompt__txt">
                        ${resultData.content}
                    </div>

                    ${resultData.exlinks ? `
                    <div class="prompt__query__exlinks">
                        <button type="button" id="prompt-exlinks-box" class="prompt__exlinks" data-target="right-popup-links">
                            <div class="prompt__exlinks_txt1">출처</div>
                            <div class="exlinks__img__group">
                                <img src="icons/k__ic.svg" alt="출처 카카오" class="exlink__ic">
                                <img src="icons/g__ic.svg" alt="출처 유튜브" class="exlink__ic">
                                <img src="icons/n__ic.svg" alt="출처 네이버" class="exlink__ic">
                            </div>
                            <div class="prompt__exlinks_txt2">외의 사이트</div>
                        </button>
                    </div>
                    ` : ''}

                    ${resultData.showActionButtons !== false ? `
                    <div class="prompt__query__btn__group">
                        <button id="prompt-query-btn" class="prompt__query__btn">
                            <div class="prompt__query__btn_ic1"></div>
                        </button>
                        <button id="prompt-query-btn" class="prompt__query__btn">
                            <div class="prompt__query__btn_ic2"></div>
                        </button>
                        <button id="prompt-query-btn" class="prompt__query__btn">
                            <div class="prompt__query__btn_ic3"></div>
                        </button>
                        <button id="prompt-query-btn" class="prompt__query__btn">
                            <div class="prompt__query__btn_ic4"></div>
                        </button>
                        <button id="prompt-query-btn" class="prompt__query__btn">
                            <div class="prompt__query__btn_ic5"></div>
                        </button>
                        <button id="prompt-query-btn-fd" class="prompt__query__btn" data-target="prompt-btn-more">
                            <div class="prompt__query__btn_ic6"></div>
                        </button>
                        
                        <div id="prompt-btn-more" class="prompt__btn__more">
                            <ul class="prompt__btn__more_ul">
                                <li class="prompt__btn__more_li">피드백</li>
                                <li class="prompt__btn__more_li">다른 메뉴</li>
                            </ul>
                        </div>
                    </div>
                    ` : ''}

                    ${resultData.relatedButtons ? `
                    <div id="query-rl-btn" class="query__rl__btn">
                        ${resultData.relatedButtons.map(btn => `
                            <div class="query__rl__btn__wrapper">
                                <button type="button" id="query-rl-it" class="query__rl__it" data-role="">${btn}</button>
                            </div>
                        `).join('')}
                    </div>
                    ` : ''}

                    ${resultData.smallButtons ? `
                    <div id="query-rl-btn-sm" class="query__rl__btn__sm">
                        ${resultData.smallButtons.map(btn => `
                            <div class="query__rl__btn__wrapper__sm">
                                <button type="button" id="query-rl-it-sm" class="query__rl__it__sm" data-role="">${btn}</button>
                            </div>
                        `).join('')}
                    </div>
                    ` : ''}

                    ${resultData.cards ? resultData.cards.map(card => `
                        <div id="${card.id}-card-comp" class="${card.class}">
                            ${card.id === 'staff' ? `
                                <div class="staff__card__title__box">
                                    <p class="staff__card__title">${card.title}</p>
                                    <p class="staff__card__subtitle">${card.subtitle}</p>
                                </div>
                            ` : `
                                <p class="card__title">${card.title}</p>
                            `}
                            <div id="card-box" class="${card.boxClass}">
                                ${card.items ? card.items.map(item => `
                                    <div class="${card.wrapperClass}">
                                        <div class="${card.itemClass}" data-id="${item.id}">
                                            <div class="${card.itemsClass}">
                                                <div class="${card.itemBoxClass}">
                                                    ${item.content.includes('staff__card__item__wrapper_c') ? 
                                                        item.content : 
                                                        `<div class="${card.itemWrapperClass}">${item.content}</div>`
                                                    }
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                `).join('') : ''}
                            </div>
                            ${card.id === 'li' ? `
                                <a href="/" target="_blank" id="cal-more-btn" class="cal__more__btn">
                                    페이지로 이동
                                </a>
                            ` : ''}
                        </div>
                    `).join('') : ''}

                    ${resultData.calendar ? `
                    <div class="calander__v calander_wd">
                        <p class="calander__v__title">캘린더</p>
                        <p class="calander__v__subtitle">주요 일정을 정리해서 보여줍니다.</p>
                        <div class="calander__wrapper">
                            <table id="prompt-calander" class="prompt__calander">
                                <thead>
                                    <tr>
                                        <th class="tg-0pky" colspan="7" data-id="">
                                            <div class="cal__th__wrapper">
                                                <button type="button" id="cal-mon-prev" class="cal__mon__prev"><img src="icons/arrow_l_ic.svg" alt="" class="cal__th__bf"></button>
                                                <span class="cal__th__title">2025년 8월</span>
                                                <button type="button" id="cal-mon-next" class="cal__mon__next"><img src="icons/arrow_r_ic.svg" alt="" class="cal__th__af"></button>
                                            </div>
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    ${resultData.calendar.days.map(day => `
                                        <tr>
                                            ${day.map(cell => `
                                                <td class="tg-0lax">
                                                    <div class="cal__box">
                                                        <div class="cal__nb__wrapper">
                                                            <div id="cal-nb-date" class="cal__nb__date" data-status-current="${cell.status}">
                                                                <span id="cal-nb-date-txt" class="cal__nb__date__txt">${cell.date}</span>
                                                            </div>
                                                            <div id="cal-nb-day" class="cal__nb__day">${cell.day}</div>
                                                        </div>
                                                        <div id="cal__schedule__wrapper" class="cal__schedule__wrapper">
                                                            <ul class="cal__sc__ul">
                                                                ${cell.schedules ? cell.schedules.map(schedule => `
                                                                    <li id="cal-sc-it" class="cal__sc__it" data-type="${schedule.type}">${schedule.text}</li>
                                                                `).join('') : ''}
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </td>
                                            `).join('')}
                                        </tr>
                                    `).join('')}
                                </tbody>
                            </table>
                            <a href="/" target="_blank" id="cal-more-btn" class="cal__more__btn">
                                캘린더 페이지로 이동
                            </a>
                        </div>
                    </div>
                    ` : ''}
                    
                    <div class="sc__btn__wrapper">
                        <button type="button" id="sc-btn" class="sc__btn"><div class="sc__dr__ic"></div></button>
                    </div>
                </div>
                <div class="prompt__txt_box">
                    <div class="prompt__txt_adjust">
                        <div class="prompt__timestamp">${this.formatTimeWithPeriod()}</div>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    console.log("생성된 HTML:", resultContainer.innerHTML.substring(0, 500) + "...");
    
    // 기존 sc__btn__wrapper 제거 (중복 방지)
    const existingScBtn = chatArea.querySelector('.sc__btn__wrapper');
    if (existingScBtn) {
        existingScBtn.remove();
    }
    
    // 새로운 콘텐츠 추가
    chatArea.appendChild(resultContainer);
    // 스크롤을 안전하게 처리
    setTimeout(() => {
        chatArea.scrollTop = Math.min(chatArea.scrollHeight - chatArea.clientHeight, chatArea.scrollHeight);
    }, 0);
    
    // 새로 추가된 요소들에 이벤트 리스너 바인딩
    this.bindComplexResultEvents(resultContainer);
};

/**
 * 서비스별 데이터 생성 (퍼블리싱된 HTML 구조에 맞게)
 */
window.RebotCore.getServiceData = function(serviceType, data) {
    const baseData = {
        title: serviceType,
        content: `${serviceType} 정보를 조회했습니다.`,
        exlinks: true,
        relatedButtons: [
            "버튼앰",
            "버튼앰", 
            "버튼앰",
            "버튼앰",
            "버튼앰",
            "버튼앰"
        ],
        smallButtons: [
            "버튼앰",
            "버튼앰", 
            "버튼앰",
            "버튼앰",
            "버튼앰",
            "버튼앰"
        ],
        cards: [],
        calendar: null
    };

    // 전달받은 데이터가 있으면 우선 적용
    if (data) {
        if (data.exlinks !== undefined) baseData.exlinks = data.exlinks;
        if (data.showActionButtons !== undefined) baseData.showActionButtons = data.showActionButtons;
        if (data.content) baseData.content = data.content;
        if (data.relatedButtons !== undefined) baseData.relatedButtons = data.relatedButtons;
        if (data.smallButtons !== undefined) baseData.smallButtons = data.smallButtons;
    }

    switch(serviceType) {
        case "주식시장":
            // 샘플 데이터가 있는 경우 실제 데이터로 업데이트
            if (data && data.chartData) {
                baseData.content = `주식시장 현황을 조회했습니다.
<br>아래는 실시간 주가 정보와 매매동향입니다:
<hr class="prompt__linestyle">
주요 지수 현황
<ul class="prompt__txt_ul">
    <li class="prompt__txt_li">코스피: ${data.chartData.currentPrice} ${data.chartData.changeRate}</li>
    <li class="prompt__txt_li">외국인: ${data.tradingData.foreign > 0 ? '▲' : '▽'}${Math.abs(data.tradingData.foreign)}억</li>
    <li class="prompt__txt_li">기관: ${data.tradingData.institution > 0 ? '▲' : '▽'}${Math.abs(data.tradingData.institution)}억</li>
    <li class="prompt__txt_li">개인: ${data.tradingData.individual > 0 ? '▲' : '▽'}${Math.abs(data.tradingData.individual)}억</li>
</ul>`;
            } else {
                baseData.content = `중동 긴장 고조가 한국 시장에 미치는 영향은 주로 에너지 가격 변동, 수출입 불확실성, 그리고 금융시장 변동성으로 나타나고 있습니다.
<br>아래는 주요 동향과 영향을 정리한 내용입니다:
<hr class="prompt__linestyle">
금융시장 동향
<ul class="prompt__txt_ul">
    <li class="prompt__txt_li">환율 변동: 원/달러 환율은 강달러 기조와 중동 불확실성으로 인해 상승 압력을 받았으나,한국은행의 외환시장 안정화 조치로 큰 혼란은 억제되고 있습니다.</li>
    <li class="prompt__txt_li">환율 변동: 원/달러 환율은 강달러 기조와 중동 불확실성으로 인해 상승 압력을 받았으나,한국은행의 외환시장 안정화 조치로 큰 혼란은 억제되고 있습니다.</li>
    <li class="prompt__txt_li">환율 변동: 원/달러 환율은 강달러 기조와 중동 불확실성으로 인해 상승 압력을 받았으나,한국은행의 외환시장 안정화 조치로 큰 혼란은 억제되고 있습니다.</li>
</ul>`;
            }
            
            // 주식시장 전용 카드 구성
            baseData.cards = [
                {
                    id: "stock-chart",
                    class: "query__card__comp",
                    title: "주식시장 현황",
                    boxClass: "query__card__box",
                    wrapperClass: "query__card__box__wrapper",
                    itemClass: "query__card__wrapper",
                    itemsClass: "query__card__items",
                    itemBoxClass: "query__card__item__box",
                    itemWrapperClass: "query__card__item__wrapper",
                    items: [
                        {
                            id: 1,
                            content: `
                                <div class="query__card__title__wrapper">
                                    <p class="query__card__title">코스피 실시간 차트</p>
                                </div>
                                <div class="query__card__inner__box">
                                    <div class="stock__chart__wrapper">
                                        <img src="${data && data.chartData ? data.chartData.chartUrl : '/chartImgFiles/202510/chart_KGG01P_1_20251015094201841.png'}" 
                                             alt="주식차트" class="stock__chart__img" style="width: 100%; max-width: 300px; height: auto;">
                                    </div>
                                    <div class="stock__price__info">
                                        <p class="stock__price__text">코스피 ${data && data.chartData ? data.chartData.currentPrice : '3601.30'} 
                                            ${data && data.chartData ? (data.chartData.trend === 'up' ? '▲' : '▽') : '▲'}${data && data.chartData ? data.chartData.change : '39.49'} 
                                            ${data && data.chartData ? data.chartData.changeRate : '+1.11%'}</p>
                                    </div>
                                </div>
                            `
                        },
                        {
                            id: 2,
                            content: `
                                <div class="query__card__title__wrapper">
                                    <p class="query__card__title">매매동향</p>
                                </div>
                                <div class="query__card__subtitle__wrapper">
                                    <p class="query__card__subtitle">외국인 ${data && data.tradingData ? (data.tradingData.foreign > 0 ? '▲' : '▽') : '▲'}${data && data.tradingData ? Math.abs(data.tradingData.foreign) : '122'}억</p>
                                    <p class="query__card__subtitle">기관 ${data && data.tradingData ? (data.tradingData.institution > 0 ? '▲' : '▽') : '▲'}${data && data.tradingData ? Math.abs(data.tradingData.institution) : '1,442'}억</p>
                                    <p class="query__card__subtitle">개인 ${data && data.tradingData ? (data.tradingData.individual > 0 ? '▲' : '▽') : '▽'}${data && data.tradingData ? Math.abs(data.tradingData.individual) : '1,653'}억</p>
                                </div>
                            `
                        }
                    ]
                }
            ];
            
            // 주식시장에서는 출처 링크와 액션 버튼들 숨김
            baseData.exlinks = false;
            baseData.showActionButtons = false;
            
            // 주식시장 관련 버튼들 (큰 버튼은 비워두고 작은 버튼만 사용)
            baseData.relatedButtons = [];
            baseData.smallButtons = [
                "분봉",
                "3개월", 
                "6개월",
                "1년",
                "코스피",
                "코스닥"
            ];
            break;
            
            baseData.cards = [
                {
                    id: "query",
                    class: "staff__card__comp",
                    title: "관련된 질문",
                    boxClass: "query__card__box",
                    wrapperClass: "query__card__box__wrapper",
                    itemClass: "query__card__wrapper",
                    itemsClass: "query__card__items",
                    itemBoxClass: "query__card__item__box",
                    itemWrapperClass: "query__card__item__wrapper",
                    items: [
                        {
                            id: 1,
                            content: `
                                <div class="query__card__title__wrapper">
                                    <p id="query-card-title" class="query__card__title" data-id="" data-name="">현재 외국인 매수 동향이 궁금해요</p>
                                </div>
                                <div class="query__card__subtitle__wrapper">
                                    <p id="card-item-kp" class="query__card__subtitle">코스피&nbsp;-&nbsp;외국인 0억</p>
                                    <p id="card-item-kd" class="query__card__subtitle">코스닥&nbsp;-&nbsp;외국인 0억</p>
                                </div>
                                <div class="query__card__inner__box">
                                    <div class="query__card__indice__box">
                                        <p id="card-chart-index" class="card__chart__index">0000.00</p>
                                        <div id="card-chart-trend" class="card__chart__trend"><img src="/icons/index_up.svg" alt="인덱스 오름" id="chart-trend-ic" class="chart__trend__ic"><span id="chart-trend-indice" class="chart__trend__indice">100.00</span></div>
                                        <p id="card-chart-pc" class="card__chart__pc">100.00%</p>
                                    </div>
                                    <a href="/" id="news-more-btn" class="card__more__btn card__btn__flex">자세히 보기</a>
                                </div>
                            `
                        },
                        {
                            id: 2,
                            content: `
                                <div class="query__card__title__wrapper">
                                    <p id="query-card-title" class="query__card__title" data-id="" data-name="">현재 외국인 매수 동향이 궁금해요</p>
                                </div>
                                <div class="query__card__subtitle__wrapper">
                                    <p id="card-item-kp" class="query__card__subtitle">코스피&nbsp;-&nbsp;외국인 0억</p>
                                    <p id="card-item-kd" class="query__card__subtitle">코스닥&nbsp;-&nbsp;외국인 0억</p>
                                </div>
                                <div class="query__card__inner__box">
                                    <div class="query__card__indice__box">
                                        <p id="card-chart-index" class="card__chart__index">0000.00</p>
                                        <div id="card-chart-trend" class="card__chart__trend"><img src="/icons/index_up.svg" alt="인덱스 오름" id="chart-trend-ic" class="chart__trend__ic"><span id="chart-trend-indice" class="chart__trend__indice">100.00</span></div>
                                        <p id="card-chart-pc" class="card__chart__pc">100.00%</p>
                                    </div>
                                    <a href="/" id="news-more-btn" class="card__more__btn card__btn__flex">자세히 보기</a>
                                </div>
                            `
                        },
                        {
                            id: 3,
                            content: `
                                <div class="query__card__title__wrapper">
                                    <p id="query-card-title" class="query__card__title" data-id="" data-name="">현재 외국인 매수 동향이 궁금해요</p>
                                </div>
                                <div class="query__card__subtitle__wrapper">
                                    <p id="card-item-kp" class="query__card__subtitle">코스피&nbsp;-&nbsp;외국인 0억</p>
                                    <p id="card-item-kd" class="query__card__subtitle">코스닥&nbsp;-&nbsp;외국인 0억</p>
                                </div>
                                <div class="query__card__inner__box">
                                    <div class="query__card__indice__box">
                                        <p id="card-chart-index" class="card__chart__index">0000.00</p>
                                        <div id="card-chart-trend" class="card__chart__trend"><img src="/icons/index_up.svg" alt="인덱스 오름" id="chart-trend-ic" class="chart__trend__ic"><span id="chart-trend-indice" class="chart__trend__indice">100.00</span></div>
                                        <p id="card-chart-pc" class="card__chart__pc">100.00%</p>
                                    </div>
                                    <a href="/" id="news-more-btn" class="card__more__btn card__btn__flex">자세히 보기</a>
                                </div>
                            `
                        }
                    ]
                },
                {
                    id: "report",
                    class: "report__card__comp",
                    title: "최신 리포트",
                    boxClass: "report__card__box",
                    wrapperClass: "report__card__box__wrapper",
                    itemClass: "report__card__wrapper",
                    itemsClass: "report__card__items",
                    itemBoxClass: "report__card__item__box",
                    itemWrapperClass: "report__card__item__wrapper",
                    items: [
                        {
                            id: 1,
                            content: `
                                <div id="report-name-chip" class="report__name__chip">채권/크레딧</div>
                                <div class="report__card__title__wrapper">
                                    <p id="report-card-title" class="report__card__title" data-id="" data-name="">KB Bond</p>
                                </div>
                                <div class="report__card__subtitle__wrapper">
                                    <p id="report-card-subtitle" class="report__card__subtitle" data-id="" data-name="">예정되어 있던 관세 서한과 유예기간 연장</p>
                                </div>
                                <div class="report__card__inner__box">
                                    <div class="report__card__textbox">
                                        <div class="report__card__info_row">by&nbsp;<span id="report-card-info" class="report__card__info">Author</span></div>
                                        <p id="report-card-timestamp" class="report__card__timestamp">2025-07-08</p>
                                    </div>
                                    <a href="/" id="report-more-btn" class="card__more__btn">자세히 보기</a>
                                </div>
                            `
                        },
                        {
                            id: 2,
                            content: `
                                <div id="report-name-chip" class="report__name__chip">모닝코멘트</div>
                                <div class="report__card__title__wrapper">
                                    <p id="report-card-subtitle" class="report__card__title" data-id="" data-name="">KB Bond</p>
                                </div>
                                <div class="report__card__subtitle__wrapper">
                                    <p id="report-card-subtitle" class="report__card__subtitle" data-id="" data-name="">예정되어 있던 관세 서한과 유예기간 연장</p>
                                </div>
                                <div class="report__card__inner__box">
                                    <div class="report__card__textbox">
                                        <div class="report__card__info_row">by&nbsp;<span id="report-card-info" class="report__card__info">Author</span></div>
                                        <p id="report-card-timestamp" class="report__card__timestamp">2025-07-08</p>
                                    </div>
                                    <a href="/" id="report-more-btn" class="card__more__btn">자세히 보기</a>
                                </div>
                            `
                        },
                        {
                            id: 3,
                            content: `
                                <div id="report-name-chip" class="report__name__chip">데일리</div>
                                <div class="report__card__title__wrapper">
                                    <p id="report-card-subtitle" class="report__card__title" data-id="" data-name="">뉴욕증시 3대 지수 최고치 마감</p>
                                </div>
                                <div class="report__card__subtitle__wrapper">
                                    <p id="report-card-subtitle" class="report__card__subtitle" data-id="" data-name="">예정되어 있던 관세 서한과 유예기간 연장</p>
                                </div>
                                <div class="report__card__inner__box">
                                    <div class="report__card__textbox">
                                        <div class="report__card__info_row">by&nbsp;<span id="report-card-info" class="report__card__info">Author</span></div>
                                        <p id="report-card-timestamp" class="report__card__timestamp">2025-07-08</p>
                                    </div>
                                    <a href="/" id="report-more-btn" class="card__more__btn">자세히 보기</a>
                                </div>
                            `
                        }
                    ]
                },
                {
                    id: "news",
                    class: "news__card__comp",
                    title: "마감 기사",
                    boxClass: "news__card__box",
                    wrapperClass: "news__card__box__wrapper",
                    itemClass: "news__card__wrapper",
                    itemsClass: "news__card__items",
                    itemBoxClass: "news__card__item__box",
                    itemWrapperClass: "news__card__item__wrapper",
                    items: [
                        {
                            id: 1,
                            content: `
                                <div class="card__img__wrapper"></div>
                                <div class="news__card__item__wrapper">
                                    <div class="news__card__title__wrapper">
                                        <p id="news-card-subtitle" class="news__card__title" data-id="" data-name="">뉴욕증시 3대 지수 최고치 마감</p>
                                    </div>
                                    <div class="news__card__inner__box">
                                        <div class="news__card__textbox">
                                            <div class="news__card__info_row">by&nbsp;<span id="report-card-info" class="report__card__info">source</span></div>
                                            <p id="news-card-timestamp" class="report__card__timestamp">2025-07-08</p>
                                        </div>
                                        <a href="/" id="news-more-btn" class="card__more__btn">자세히 보기</a>
                                    </div>
                                </div>
                            `
                        },
                        {
                            id: 2,
                            content: `
                                <div class="card__img__wrapper"></div>
                                <div class="news__card__item__wrapper">
                                    <div class="news__card__title__wrapper">
                                        <p id="news-card-subtitle" class="news__card__title" data-id="" data-name="">뉴욕증시 3대 지수 최고치 마감</p>
                                    </div>
                                    <div class="news__card__inner__box">
                                        <div class="news__card__textbox">
                                            <div class="news__card__info_row">by&nbsp;<span id="report-card-info" class="report__card__info">source</span></div>
                                            <p id="news-card-timestamp" class="report__card__timestamp">2025-07-08</p>
                                        </div>
                                        <a href="/" id="news-more-btn" class="card__more__btn">자세히 보기</a>
                                    </div>
                                </div>
                            `
                        },
                        {
                            id: 3,
                            content: `
                                <div class="card__img__wrapper"></div>
                                <div class="news__card__item__wrapper">
                                    <div class="news__card__title__wrapper">
                                        <p id="news-card-subtitle" class="news__card__title" data-id="" data-name="">뉴욕증시 3대 지수 최고치 마감</p>
                                    </div>
                                    <div class="news__card__inner__box">
                                        <div class="news__card__textbox">
                                            <div class="news__card__info_row">by&nbsp;<span id="report-card-info" class="report__card__info">source</span></div>
                                            <p id="news-card-timestamp" class="report__card__timestamp">2025-07-08</p>
                                        </div>
                                        <a href="/" id="news-more-btn" class="card__more__btn">자세히 보기</a>
                                    </div>
                                </div>
                            `
                        }
                    ]
                },
                {
                    id: "staff",
                    class: "staff__card__comp",
                    title: "애널리스트 선택",
                    boxClass: "staff__card__box",
                    wrapperClass: "staff__card__box__wrapper",
                    itemClass: "staff__card__wrapper",
                    itemsClass: "staff__card__items",
                    itemBoxClass: "staff__card__item__box",
                    itemWrapperClass: "staff__card__item__wrapper",
                    items: [
                        {
                            id: 1,
                            content: `
                                <div class="staff__card__title__wrapper">
                                    <p id="staff-card-title" class="staff__card__inner__title" data-id="" data-name="">
                                        <span id="staff-name">김이박</span>
                                    </p>
                                </div>
                                <div class="staff__card__inner__box">
                                    <div class="staff__card__textbox">
                                        <p id="staff-card-dep" class="staff__card__timestamp">리서치팀 해외부서</p>
                                    </div>
                                    <a href="/" id="news-more-btn" class="card__more__btn card__btn__flex">자세히 보기</a>
                                </div>
                            `
                        },
                        {
                            id: 2,
                            content: `
                                <div class="staff__card__title__wrapper">
                                    <p id="staff-card-title" class="staff__card__inner__title" data-id="" data-name="">
                                        <span id="staff-name">김이박</span>
                                    </p>
                                </div>
                                <div class="staff__card__inner__box">
                                    <div class="staff__card__textbox">
                                        <p id="staff-card-dep" class="staff__card__timestamp">리서치팀 해외부서</p>
                                    </div>
                                    <a href="/" id="news-more-btn" class="card__more__btn card__btn__flex">자세히 보기</a>
                                </div>
                            `
                        },
                        {
                            id: 3,
                            content: `
                                <div class="staff__card__title__wrapper">
                                    <p id="staff-card-title" class="staff__card__inner__title" data-id="" data-name="">
                                        <span id="staff-name">김이박</span>
                                    </p>
                                </div>
                                <div class="staff__card__inner__box">
                                    <div class="staff__card__textbox">
                                        <p id="staff-card-dep" class="staff__card__timestamp">리서치팀 해외부서</p>
                                    </div>
                                    <a href="/" id="news-more-btn" class="card__more__btn card__btn__flex">자세히 보기</a>
                                </div>
                            `
                        },
                        {
                            id: 4,
                            content: `
                                <div class="staff__card__title__wrapper">
                                    <p id="staff-card-title" class="staff__card__inner__title" data-id="" data-name="">
                                        <span id="staff-name">김이박</span>
                                    </p>
                                </div>
                                <div class="staff__card__inner__box">
                                    <div class="staff__card__textbox">
                                        <p id="staff-card-dep" class="staff__card__timestamp">리서치팀 해외부서</p>
                                    </div>
                                    <a href="/" id="news-more-btn" class="card__more__btn card__btn__flex">자세히 보기</a>
                                </div>
                            `
                        },
                        {
                            id: 5,
                            content: `
                                <div class="staff__card__item__wrapper_c">
                                    <div class="staff__card__title__wrapper_c">
                                        <div class="staff__card__img__wrapper"></div>
                                        <div class="staff__card__info__wrapper_c">
                                            <p id="staff-card-title" class="staff__card__inner__title" data-id="" data-name=""></p>
                                            <div class="staff__card__textbox">
                                                <p id="staff-card-dep" class="staff__card__timestamp_c">리서치팀 해외부서</p>
                                            </div>
                                            <span id="staff-name">김이박</span>
                                        </div>
                                    </div>
                                    <div class="staff__card__inner__box">
                                        <a href="/" id="news-more-btn" class="card__more__btn card__btn__flex">자세히 보기</a>
                                    </div>
                                </div>
                            `
                        },
                        {
                            id: 6,
                            content: `
                                <div class="staff__card__item__wrapper_c">
                                    <div class="staff__card__title__wrapper_c">
                                        <div class="staff__card__img__wrapper"></div>
                                        <div class="staff__card__info__wrapper_c">
                                            <p id="staff-card-title" class="staff__card__inner__title" data-id="" data-name=""></p>
                                            <div class="staff__card__textbox">
                                                <p id="staff-card-dep" class="staff__card__timestamp_c">리서치팀 해외부서</p>
                                            </div>
                                            <span id="staff-name">김이박</span>
                                        </div>
                                    </div>
                                    <div class="staff__card__inner__box">
                                        <a href="/" id="news-more-btn" class="card__more__btn card__btn__flex">자세히 보기</a>
                                    </div>
                                </div>
                            `
                        },
                        {
                            id: 7,
                            content: `
                                <div class="staff__card__item__wrapper_c">
                                    <div class="staff__card__title__wrapper_c">
                                        <div class="staff__card__img__wrapper"></div>
                                        <div class="staff__card__info__wrapper_c">
                                            <p id="staff-card-title" class="staff__card__inner__title" data-id="" data-name=""></p>
                                            <div class="staff__card__textbox">
                                                <p id="staff-card-dep" class="staff__card__timestamp_c">리서치팀 해외부서</p>
                                            </div>
                                            <span id="staff-name">김이박</span>
                                        </div>
                                    </div>
                                    <div class="staff__card__inner__box">
                                        <a href="/" id="news-more-btn" class="card__more__btn card__btn__flex">자세히 보기</a>
                                    </div>
                                </div>
                            `
                        },
                        {
                            id: 8,
                            content: `
                                <div class="staff__card__item__wrapper_c">
                                    <div class="staff__card__title__wrapper_c">
                                        <div class="staff__card__img__wrapper"></div>
                                        <div class="staff__card__info__wrapper_c">
                                            <p id="staff-card-title" class="staff__card__inner__title" data-id="" data-name=""></p>
                                            <div class="staff__card__textbox">
                                                <p id="staff-card-dep" class="staff__card__timestamp_c">리서치팀 해외부서</p>
                                            </div>
                                            <span id="staff-name">김이박</span>
                                        </div>
                                    </div>
                                    <div class="staff__card__inner__box">
                                        <a href="/" id="news-more-btn" class="card__more__btn card__btn__flex">자세히 보기</a>
                                    </div>
                                </div>
                            `
                        }
                    ]
                },
                {
                    id: "cal",
                    class: "cal__card__comp",
                    title: "캘린더",
                    boxClass: "cal__card__box",
                    wrapperClass: "cal__card__box__wrapper",
                    itemClass: "cal__card__wrapper",
                    itemsClass: "cal__card__items",
                    itemBoxClass: "cal__card__item__box",
                    itemWrapperClass: "cal__card__item__wrapper",
                    items: [
                        {
                            id: 1,
                            content: `
                                <div class="cal__card__title__wrapper">
                                    <p id="cal-card-title" class="cal__card__inner__title" data-id="" data-name="">
                                        <span class="cal__nb__date__mo" data-status-current="today">1</span>
                                        <span id="cal__nb__day" class="cal__nb__day__mo">MON</span>
                                    </p>
                                </div>
                                <div class="cal__card__inner__box">
                                    <div class="cal__card__textbox">
                                        <div class="cal__sc__box">
                                            <p class="cal__sc__it__mo__title">한국 시장</p>
                                            <p class="cal__sc__it__mo" data-type="ksp">일정</p>
                                            <p class="cal__sc__it__mo" data-type="ksp">일정</p>
                                            <p class="cal__sc__it__mo" data-type="ksp">일정</p>
                                            <p class="cal__sc__it__mo" data-type="ksp">일정</p>
                                            <p class="cal__sc__it__mo" data-type="ksp">일정</p>
                                            <p class="cal__sc__it__mo" data-type="ksp">일정</p>
                                            <p class="cal__sc__it__mo" data-type="ksp">일정</p>
                                            <p class="cal__sc__it__mo__title cal__sc__it__adjust">미국 시장</p>
                                            <p class="cal__sc__it__mo" data-type="nsd">일정</p>
                                            <p class="cal__sc__it__mo" data-type="nsd">일정</p>
                                            <p class="cal__sc__it__mo" data-type="nsd">일정</p>
                                            <p class="cal__sc__it__mo" data-type="nsd">일정</p>
                                            <p class="cal__sc__it__mo" data-type="nsd">일정</p>
                                        </div>
                                    </div>
                                    <button type="button" id="cal-li-more-btn" class="cal__card__more__btn card__btn__flex keep-style">더 보기</button>
                                </div>
                            `
                        },
                        {
                            id: 2,
                            content: `
                                <div class="cal__card__title__wrapper">
                                    <p id="cal-card-title" class="cal__card__inner__title" data-id="" data-name="">
                                        <span class="cal__nb__date__mo" data-status-current="next-day">2</span>
                                        <span id="cal__nb__day" class="cal__nb__day__mo">TUE</span>
                                    </p>
                                </div>
                                <div class="cal__card__inner__box">
                                    <div class="cal__card__textbox">
                                        <div class="cal__sc__box">
                                            <p class="cal__sc__it__mo__title">한국 시장</p>
                                            <p class="cal__sc__it__mo" data-type="ksp">일정</p>
                                            <p class="cal__sc__it__mo" data-type="ksp">일정</p>
                                            <p class="cal__sc__it__mo" data-type="ksp">일정</p>
                                            <p class="cal__sc__it__mo" data-type="ksp">일정</p>
                                            <p class="cal__sc__it__mo" data-type="ksp">일정</p>
                                            <p class="cal__sc__it__mo" data-type="ksp">일정</p>
                                            <p class="cal__sc__it__mo" data-type="ksp">일정</p>
                                            <p class="cal__sc__it__mo__title cal__sc__it__adjust">미국 시장</p>
                                            <p class="cal__sc__it__mo" data-type="nsd">일정</p>
                                            <p class="cal__sc__it__mo" data-type="nsd">일정</p>
                                            <p class="cal__sc__it__mo" data-type="nsd">일정</p>
                                            <p class="cal__sc__it__mo" data-type="nsd">일정</p>
                                            <p class="cal__sc__it__mo" data-type="nsd">일정</p>
                                        </div>
                                    </div>
                                    <button type="button" id="cal-li-more-btn" class="cal__card__more__btn card__btn__flex keep-style">더 보기</button>
                                </div>
                            `
                        },
                        {
                            id: 3,
                            content: `
                                <div class="cal__card__title__wrapper">
                                    <p id="cal-card-title" class="cal__card__inner__title" data-id="" data-name="">
                                        <span class="cal__nb__date__mo" data-status-current="next-day">3</span>
                                        <span id="cal__nb__day" class="cal__nb__day__mo">WED</span>
                                    </p>
                                </div>
                                <div class="cal__card__inner__box">
                                    <div class="cal__card__textbox">
                                        <div class="cal__sc__box">
                                            <p class="cal__sc__it__mo__title">한국 시장</p>
                                            <p class="cal__sc__it__mo" data-type="ksp">일정</p>
                                            <p class="cal__sc__it__mo" data-type="ksp">일정</p>
                                            <p class="cal__sc__it__mo" data-type="ksp">일정</p>
                                            <p class="cal__sc__it__mo" data-type="ksp">일정</p>
                                            <p class="cal__sc__it__mo" data-type="ksp">일정</p>
                                            <p class="cal__sc__it__mo" data-type="ksp">일정</p>
                                            <p class="cal__sc__it__mo" data-type="ksp">일정</p>
                                            <p class="cal__sc__it__mo__title cal__sc__it__adjust">미국 시장</p>
                                            <p class="cal__sc__it__mo" data-type="nsd">일정</p>
                                            <p class="cal__sc__it__mo" data-type="nsd">일정</p>
                                            <p class="cal__sc__it__mo" data-type="nsd">일정</p>
                                            <p class="cal__sc__it__mo" data-type="nsd">일정</p>
                                            <p class="cal__sc__it__mo" data-type="nsd">일정</p>
                                        </div>
                                    </div>
                                    <button type="button" id="cal-li-more-btn" class="cal__card__more__btn card__btn__flex keep-style">더 보기</button>
                                </div>
                            `
                        }
                    ]
                },
                {
                    id: "li",
                    class: "li__card__comp",
                    title: "원자재 가격",
                    boxClass: "li__card__box",
                    wrapperClass: "li__card__box__wrapper",
                    itemClass: "li__card__wrapper",
                    itemsClass: "li__card__items",
                    itemBoxClass: "li__card__item__box",
                    itemWrapperClass: "li__card__item__wrapper",
                    items: [
                        {
                            id: 0,
                            content: `
                                <div class="li__card__title__box">
                                    <p id="li-card-title" class="li__card__title" data-p-name="">원자재 가격</p>
                                    <p class="li__card__subtitle"><span id="li-card-title" data-p-name="">원자재 가격</span>입니다.</p>
                                </div>
                            `
                        },
                        {
                            id: 1,
                            content: `
                                <div class="li__card__title__wrapper">
                                    <p id="li-card-title" class="li__card__inner__title" data-id="" data-name="">
                                        <span class="" data-status-current="">today</span>
                                        <span id="li__nb" class="li__nb__mo">원자재 가격</span>
                                    </p>
                                    <a href="/" id="" class="li__card__inner__link">시황 확인</a>
                                </div>
                                <div class="li__card__title__wrapper">
                                    <p id="li-card-title" class="li__card__inner__title" data-id="" data-name="">
                                        <span class="" data-status-current="">today</span>
                                        <span id="li__nb" class="li__nb__mo">원자재 가격</span>
                                    </p>
                                    <a href="/" id="" class="li__card__inner__link">시황 확인</a>
                                </div>
                            `
                        }
                    ]
                }
            ];
            break;
            
        case "주식시장 분봉":
            // 분봉 데이터가 있는 경우 실제 데이터로 업데이트
            if (data && data.realTimeChart) {
                baseData.content = `분봉 차트 정보를 조회했습니다.
<br>아래는 실시간 분봉 데이터와 매매동향입니다:
<hr class="prompt__linestyle">
분봉 현황
<ul class="prompt__txt_ul">
    <li class="prompt__txt_li">코스피: ${data.realTimeChart.currentPrice} ${data.realTimeChart.changeRate}</li>
    <li class="prompt__txt_li">외국인: ${data.tradingTrend.foreign > 0 ? '▲' : '▽'}${Math.abs(data.tradingTrend.foreign)}억</li>
    <li class="prompt__txt_li">기관: ${data.tradingTrend.institution > 0 ? '▲' : '▽'}${Math.abs(data.tradingTrend.institution)}억</li>
    <li class="prompt__txt_li">개인: ${data.tradingTrend.individual > 0 ? '▲' : '▽'}${Math.abs(data.tradingTrend.individual)}억</li>
</ul>`;
            } else {
                baseData.content = `분봉 차트 정보를 조회했습니다.
<br>아래는 실시간 분봉 데이터입니다:
<hr class="prompt__linestyle">
분봉 현황
<ul class="prompt__txt_ul">
    <li class="prompt__txt_li">코스피: 3612.92 +1.43%</li>
    <li class="prompt__txt_li">외국인: ▲263억</li>
    <li class="prompt__txt_li">기관: ▲2,347억</li>
    <li class="prompt__txt_li">개인: ▽-2,654억</li>
</ul>`;
            }
            
            // 분봉 전용 카드 구성
            baseData.cards = [
                {
                    id: "minute-chart",
                    class: "query__card__comp",
                    title: "분봉 차트 현황",
                    boxClass: "query__card__box",
                    wrapperClass: "query__card__box__wrapper",
                    itemClass: "query__card__wrapper",
                    itemsClass: "query__card__items",
                    itemBoxClass: "query__card__item__box",
                    itemWrapperClass: "query__card__item__wrapper",
                    items: [
                        {
                            id: 1,
                            content: `
                                <div class="query__card__title__wrapper">
                                    <p class="query__card__title">코스피 분봉 차트</p>
                                </div>
                                <div class="query__card__inner__box">
                                    <div class="stock__chart__wrapper">
                                        <img src="${data && data.realTimeChart ? data.realTimeChart.chartUrl : '/chartImgFiles/202510/chart_KGG01P_1_20251015102310481.png'}" 
                                             alt="분봉차트" class="stock__chart__img" style="width: 100%; max-width: 300px; height: auto;">
                                    </div>
                                    <div class="stock__price__info">
                                        <p class="stock__price__text">코스피 ${data && data.realTimeChart ? data.realTimeChart.currentPrice : '3612.92'} 
                                            ${data && data.realTimeChart ? (data.realTimeChart.trend === 'up' ? '▲' : '▽') : '▲'}${data && data.realTimeChart ? data.realTimeChart.change : '51.11'} 
                                            ${data && data.realTimeChart ? data.realTimeChart.changeRate : '+1.43%'}</p>
                                    </div>
                                </div>
                            `
                        },
                        {
                            id: 2,
                            content: `
                                <div class="query__card__title__wrapper">
                                    <p class="query__card__title">매매동향 (분봉)</p>
                                </div>
                                <div class="query__card__subtitle__wrapper">
                                    <p class="query__card__subtitle">외국인 ${data && data.tradingTrend ? (data.tradingTrend.foreign > 0 ? '▲' : '▽') : '▲'}${data && data.tradingTrend ? Math.abs(data.tradingTrend.foreign) : '263'}억</p>
                                    <p class="query__card__subtitle">기관 ${data && data.tradingTrend ? (data.tradingTrend.institution > 0 ? '▲' : '▽') : '▲'}${data && data.tradingTrend ? Math.abs(data.tradingTrend.institution) : '2,347'}억</p>
                                    <p class="query__card__subtitle">개인 ${data && data.tradingTrend ? (data.tradingTrend.individual > 0 ? '▲' : '▽') : '▽'}${data && data.tradingTrend ? Math.abs(data.tradingTrend.individual) : '2,654'}억</p>
                                </div>
                            `
                        },
                        {
                            id: 3,
                            content: `
                                <div class="query__card__title__wrapper">
                                    <p class="query__card__title">실시간 분봉 데이터</p>
                                </div>
                                <div class="query__card__subtitle__wrapper">
                                    <p class="query__card__subtitle">현재가: ${data && data.realTimeChart && data.realTimeChart.record1 && data.realTimeChart.record1[0] ? data.realTimeChart.record1[0].clsPrc : '361,292'}</p>
                                    <p class="query__card__subtitle">거래량: ${data && data.realTimeChart && data.realTimeChart.record1 && data.realTimeChart.record1[0] ? data.realTimeChart.record1[0].vlm : '122,000'}</p>
                                    <p class="query__card__subtitle">거래대금: ${data && data.realTimeChart && data.realTimeChart.record1 && data.realTimeChart.record1[0] ? (parseInt(data.realTimeChart.record1[0].dlTwAmt) / 100000000).toFixed(0) + '억' : '35억'}</p>
                                </div>
                            `
                        }
                    ]
                }
            ];
            
            // 분봉에서는 출처 링크와 액션 버튼들 숨김
            baseData.exlinks = false;
            baseData.showActionButtons = false;
            
            // 분봉 관련 버튼들 (큰 버튼은 비워두고 작은 버튼만 사용)
            baseData.relatedButtons = [];
            baseData.smallButtons = [
                "분봉",
                "3개월", 
                "6개월",
                "1년",
                "코스피",
                "코스닥"
            ];
            break;
            
        case "주식시장 3개월":
            baseData.content = `3개월 차트 정보를 조회했습니다.
<br>아래는 3개월 주가 정보와 매매동향입니다:
<hr class="prompt__linestyle">
3개월 현황
<ul class="prompt__txt_ul">
    <li class="prompt__txt_li">코스피: ${data && data.chartData ? data.chartData.currentPrice : '3580.15'} ${data && data.chartData ? data.chartData.changeRate : '+0.51%'}</li>
    <li class="prompt__txt_li">외국인: ${data && data.tradingData ? (data.tradingData.foreign > 0 ? '▲' : '▽') : '▲'}${data && data.tradingData ? Math.abs(data.tradingData.foreign) : '189'}억</li>
    <li class="prompt__txt_li">기관: ${data && data.tradingData ? (data.tradingData.institution > 0 ? '▲' : '▽') : '▲'}${data && data.tradingData ? Math.abs(data.tradingData.institution) : '1,123'}억</li>
    <li class="prompt__txt_li">개인: ${data && data.tradingData ? (data.tradingData.individual > 0 ? '▲' : '▽') : '▽'}${data && data.tradingData ? Math.abs(data.tradingData.individual) : '1,312'}억</li>
</ul>`;
            baseData.cards = this.getStockMarketCards(data, "3개월");
            baseData.exlinks = false;
            baseData.showActionButtons = false;
            baseData.relatedButtons = [];
            baseData.smallButtons = ["분봉", "3개월", "6개월", "1년", "코스피", "코스닥"];
            break;
            
        case "주식시장 6개월":
            baseData.content = `6개월 차트 정보를 조회했습니다.
<br>아래는 6개월 주가 정보와 매매동향입니다:
<hr class="prompt__linestyle">
6개월 현황
<ul class="prompt__txt_ul">
    <li class="prompt__txt_li">코스피: ${data && data.chartData ? data.chartData.currentPrice : '3520.45'} ${data && data.chartData ? data.chartData.changeRate : '-1.16%'}</li>
    <li class="prompt__txt_li">외국인: ${data && data.tradingData ? (data.tradingData.foreign > 0 ? '▲' : '▽') : '▽'}${data && data.tradingData ? Math.abs(data.tradingData.foreign) : '156'}억</li>
    <li class="prompt__txt_li">기관: ${data && data.tradingData ? (data.tradingData.institution > 0 ? '▲' : '▽') : '▲'}${data && data.tradingData ? Math.abs(data.tradingData.institution) : '987'}억</li>
    <li class="prompt__txt_li">개인: ${data && data.tradingData ? (data.tradingData.individual > 0 ? '▲' : '▽') : '▽'}${data && data.tradingData ? Math.abs(data.tradingData.individual) : '831'}억</li>
</ul>`;
            baseData.cards = this.getStockMarketCards(data, "6개월");
            baseData.exlinks = false;
            baseData.showActionButtons = false;
            baseData.relatedButtons = [];
            baseData.smallButtons = ["분봉", "3개월", "6개월", "1년", "코스피", "코스닥"];
            break;
            
        case "주식시장 1년":
            baseData.content = `1년 차트 정보를 조회했습니다.
<br>아래는 1년 주가 정보와 매매동향입니다:
<hr class="prompt__linestyle">
1년 현황
<ul class="prompt__txt_ul">
    <li class="prompt__txt_li">코스피: ${data && data.chartData ? data.chartData.currentPrice : '3456.78'} ${data && data.chartData ? data.chartData.changeRate : '-2.95%'}</li>
    <li class="prompt__txt_li">외국인: ${data && data.tradingData ? (data.tradingData.foreign > 0 ? '▲' : '▽') : '▽'}${data && data.tradingData ? Math.abs(data.tradingData.foreign) : '234'}억</li>
    <li class="prompt__txt_li">기관: ${data && data.tradingData ? (data.tradingData.institution > 0 ? '▲' : '▽') : '▲'}${data && data.tradingData ? Math.abs(data.tradingData.institution) : '756'}억</li>
    <li class="prompt__txt_li">개인: ${data && data.tradingData ? (data.tradingData.individual > 0 ? '▲' : '▽') : '▽'}${data && data.tradingData ? Math.abs(data.tradingData.individual) : '522'}억</li>
</ul>`;
            baseData.cards = this.getStockMarketCards(data, "1년");
            baseData.exlinks = false;
            baseData.showActionButtons = false;
            baseData.relatedButtons = [];
            baseData.smallButtons = ["분봉", "3개월", "6개월", "1년", "코스피", "코스닥"];
            break;
            
        case "주식시장 코스피":
            baseData.content = `코스피 차트 정보를 조회했습니다.
<br>아래는 코스피 주가 정보와 매매동향입니다:
<hr class="prompt__linestyle">
코스피 현황
<ul class="prompt__txt_ul">
    <li class="prompt__txt_li">코스피: ${data && data.chartData ? data.chartData.currentPrice : '2601.23'} ${data && data.chartData ? data.chartData.changeRate : '+0.61%'}</li>
    <li class="prompt__txt_li">외국인: ${data && data.tradingData ? (data.tradingData.foreign > 0 ? '▲' : '▽') : '▲'}${data && data.tradingData ? Math.abs(data.tradingData.foreign) : '89'}억</li>
    <li class="prompt__txt_li">기관: ${data && data.tradingData ? (data.tradingData.institution > 0 ? '▲' : '▽') : '▲'}${data && data.tradingData ? Math.abs(data.tradingData.institution) : '456'}억</li>
    <li class="prompt__txt_li">개인: ${data && data.tradingData ? (data.tradingData.individual > 0 ? '▲' : '▽') : '▽'}${data && data.tradingData ? Math.abs(data.tradingData.individual) : '545'}억</li>
</ul>`;
            baseData.cards = this.getStockMarketCards(data, "코스피");
            baseData.exlinks = false;
            baseData.showActionButtons = false;
            baseData.relatedButtons = [];
            baseData.smallButtons = ["분봉", "3개월", "6개월", "1년", "코스피", "코스닥"];
            break;
            
        case "주식시장 코스닥":
            baseData.content = `코스닥 차트 정보를 조회했습니다.
<br>아래는 코스닥 주가 정보와 매매동향입니다:
<hr class="prompt__linestyle">
코스닥 현황
<ul class="prompt__txt_ul">
    <li class="prompt__txt_li">코스닥: ${data && data.chartData ? data.chartData.currentPrice : '789.45'} ${data && data.chartData ? data.chartData.changeRate : '+1.14%'}</li>
    <li class="prompt__txt_li">외국인: ${data && data.tradingData ? (data.tradingData.foreign > 0 ? '▲' : '▽') : '▲'}${data && data.tradingData ? Math.abs(data.tradingData.foreign) : '67'}억</li>
    <li class="prompt__txt_li">기관: ${data && data.tradingData ? (data.tradingData.institution > 0 ? '▲' : '▽') : '▲'}${data && data.tradingData ? Math.abs(data.tradingData.institution) : '234'}억</li>
    <li class="prompt__txt_li">개인: ${data && data.tradingData ? (data.tradingData.individual > 0 ? '▲' : '▽') : '▽'}${data && data.tradingData ? Math.abs(data.tradingData.individual) : '301'}억</li>
</ul>`;
            baseData.cards = this.getStockMarketCards(data, "코스닥");
            baseData.exlinks = false;
            baseData.showActionButtons = false;
            baseData.relatedButtons = [];
            baseData.smallButtons = ["분봉", "3개월", "6개월", "1년", "코스피", "코스닥"];
            break;
            
        case "캘린더":
            baseData.content = "캘린더 정보를 조회했습니다.";
            baseData.exlinks = false;
            baseData.showActionButtons = false;
            baseData.relatedButtons = [];
            baseData.smallButtons = [];
            baseData.calendar = {
                days: [
                    [
                        { date: "1", day: "MON", status: "today", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "2", day: "TUE", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "3", day: "WED", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "4", day: "THU", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "5", day: "FRI", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "6", day: "SAT", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "7", day: "SUN", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] }
                    ],
                    [
                        { date: "1", day: "MON", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "2", day: "TUE", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "3", day: "WED", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "4", day: "THU", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "5", day: "FRI", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "6", day: "SAT", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "7", day: "SUN", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] }
                    ],
                    [
                        { date: "1", day: "MON", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "2", day: "TUE", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "3", day: "WED", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "4", day: "THU", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "5", day: "FRI", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "6", day: "SAT", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "7", day: "SUN", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] }
                    ],
                    [
                        { date: "1", day: "MON", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "2", day: "TUE", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "3", day: "WED", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "4", day: "THU", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "5", day: "FRI", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "6", day: "SAT", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] },
                        { date: "7", day: "SUN", status: "next-day", schedules: [{ type: "ksp", text: "관세 서한" }, { type: "nsd", text: "유예기간 연장" }] }
                    ]
                ]
            };
            break;
            
        case "최신 리포트":
            baseData.content = "최신 리포트를 조회했습니다.";
            baseData.cards = [
                {
                    id: "report",
                    class: "report__card__comp",
                    title: "최신 리포트",
                    boxClass: "report__card__box",
                    wrapperClass: "report__card__box__wrapper",
                    itemClass: "report__card__wrapper",
                    itemsClass: "report__card__items",
                    itemBoxClass: "report__card__item__box",
                    itemWrapperClass: "report__card__item__wrapper",
                    items: [
                        {
                            id: 1,
                            content: `
                                <div id="report-name-chip" class="report__name__chip">채권/크레딧</div>
                                <div class="report__card__title__wrapper">
                                    <p id="report-card-title" class="report__card__title" data-id="" data-name="">KB Bond</p>
                                </div>
                                <div class="report__card__subtitle__wrapper">
                                    <p id="report-card-subtitle" class="report__card__subtitle" data-id="" data-name="">예정되어 있던 관세 서한과 유예기간 연장</p>
                                </div>
                                <div class="report__card__inner__box">
                                    <div class="report__card__textbox">
                                        <div class="report__card__info_row">by&nbsp;<span id="report-card-info" class="report__card__info">Author</span></div>
                                        <p id="report-card-timestamp" class="report__card__timestamp">2025-07-08</p>
                                    </div>
                                    <a href="/" id="report-more-btn" class="card__more__btn">자세히 보기</a>
                                </div>
                            `
                        },
                        {
                            id: 2,
                            content: `
                                <div id="report-name-chip" class="report__name__chip">모닝코멘트</div>
                                <div class="report__card__title__wrapper">
                                    <p id="report-card-subtitle" class="report__card__title" data-id="" data-name="">KB Bond</p>
                                </div>
                                <div class="report__card__subtitle__wrapper">
                                    <p id="report-card-subtitle" class="report__card__subtitle" data-id="" data-name="">예정되어 있던 관세 서한과 유예기간 연장</p>
                                </div>
                                <div class="report__card__inner__box">
                                    <div class="report__card__textbox">
                                        <div class="report__card__info_row">by&nbsp;<span id="report-card-info" class="report__card__info">Author</span></div>
                                        <p id="report-card-timestamp" class="report__card__timestamp">2025-07-08</p>
                                    </div>
                                    <a href="/" id="report-more-btn" class="card__more__btn">자세히 보기</a>
                                </div>
                            `
                        },
                        {
                            id: 3,
                            content: `
                                <div id="report-name-chip" class="report__name__chip">데일리</div>
                                <div class="report__card__title__wrapper">
                                    <p id="report-card-subtitle" class="report__card__title" data-id="" data-name="">뉴욕증시 3대 지수 최고치 마감</p>
                                </div>
                                <div class="report__card__subtitle__wrapper">
                                    <p id="report-card-subtitle" class="report__card__subtitle" data-id="" data-name="">예정되어 있던 관세 서한과 유예기간 연장</p>
                                </div>
                                <div class="report__card__inner__box">
                                    <div class="report__card__textbox">
                                        <div class="report__card__info_row">by&nbsp;<span id="report-card-info" class="report__card__info">Author</span></div>
                                        <p id="report-card-timestamp" class="report__card__timestamp">2025-07-08</p>
                                    </div>
                                    <a href="/" id="report-more-btn" class="card__more__btn">자세히 보기</a>
                                </div>
                            `
                        }
                    ]
                }
            ];
            break;
            
        case "애널리스트":
            baseData.content = "애널리스트 정보를 조회했습니다.";
            baseData.exlinks = false;
            baseData.showActionButtons = false;
            baseData.relatedButtons = [];
            baseData.smallButtons = [];
            baseData.cards = [
                {
                    id: "staff",
                    class: "staff__card__comp",
                    title: "애널리스트 선택",
                    subtitle: "부서명",
                    boxClass: "staff__card__box",
                    wrapperClass: "staff__card__box__wrapper",
                    itemClass: "staff__card__wrapper",
                    itemsClass: "staff__card__items",
                    itemBoxClass: "staff__card__item__box",
                    itemWrapperClass: "staff__card__item__wrapper",
                    items: [
                        {
                            id: 1,
                            content: `
                                <div class="staff__card__title__wrapper">
                                    <p id="staff-card-title" class="staff__card__inner__title" data-id="" data-name="">
                                        <span id="staff-name">김철수</span>
                                    </p>
                                </div>
                                <div class="staff__card__inner__box">
                                    <div class="staff__card__textbox">
                                        <p id="staff-card-dep" class="staff__card__timestamp">리서치팀 해외부서</p>
                                    </div>
                                    <a href="/" id="news-more-btn" class="card__more__btn card__btn__flex">자세히 보기</a>
                                </div>
                            `
                        },
                        {
                            id: 2,
                            content: `
                                <div class="staff__card__title__wrapper">
                                    <p id="staff-card-title" class="staff__card__inner__title" data-id="" data-name="">
                                        <span id="staff-name">이영희</span>
                                    </p>
                                </div>
                                <div class="staff__card__inner__box">
                                    <div class="staff__card__textbox">
                                        <p id="staff-card-dep" class="staff__card__timestamp">리서치팀 국내부서</p>
                                    </div>
                                    <a href="/" id="news-more-btn" class="card__more__btn card__btn__flex">자세히 보기</a>
                                </div>
                            `
                        },
                        {
                            id: 3,
                            content: `
                                <div class="staff__card__title__wrapper">
                                    <p id="staff-card-title" class="staff__card__inner__title" data-id="" data-name="">
                                        <span id="staff-name">박민수</span>
                                    </p>
                                </div>
                                <div class="staff__card__inner__box">
                                    <div class="staff__card__textbox">
                                        <p id="staff-card-dep" class="staff__card__timestamp">투자전략팀</p>
                                    </div>
                                    <a href="/" id="news-more-btn" class="card__more__btn card__btn__flex">자세히 보기</a>
                                </div>
                            `
                        },
                        {
                            id: 4,
                            content: `
                                <div class="staff__card__title__wrapper">
                                    <p id="staff-card-title" class="staff__card__inner__title" data-id="" data-name="">
                                        <span id="staff-name">정수진</span>
                                    </p>
                                </div>
                                <div class="staff__card__inner__box">
                                    <div class="staff__card__textbox">
                                        <p id="staff-card-dep" class="staff__card__timestamp">경제분석팀</p>
                                    </div>
                                    <a href="/" id="news-more-btn" class="card__more__btn card__btn__flex">자세히 보기</a>
                                </div>
                            `
                        },
                        {
                            id: 5,
                            content: `
                                <div class="staff__card__item__wrapper_c">
                                    <div class="staff__card__title__wrapper_c">
                                        <div class="staff__card__img__wrapper"></div>
                                        <div class="staff__card__info__wrapper_c">
                                            <p id="staff-card-title" class="staff__card__inner__title" data-id="" data-name=""></p>
                                            <div class="staff__card__textbox">
                                                <p id="staff-card-dep" class="staff__card__timestamp_c">리서치팀 해외부서</p>
                                            </div>
                                            <span id="staff-name">최동현</span>
                                        </div>
                                    </div>
                                    <div class="staff__card__inner__box">
                                        <a href="/" id="news-more-btn" class="card__more__btn card__btn__flex">자세히 보기</a>
                                    </div>
                                </div>
                            `
                        },
                        {
                            id: 6,
                            content: `
                                <div class="staff__card__item__wrapper_c">
                                    <div class="staff__card__title__wrapper_c">
                                        <div class="staff__card__img__wrapper"></div>
                                        <div class="staff__card__info__wrapper_c">
                                            <p id="staff-card-title" class="staff__card__inner__title" data-id="" data-name=""></p>
                                            <div class="staff__card__textbox">
                                                <p id="staff-card-dep" class="staff__card__timestamp_c">투자전략팀</p>
                                            </div>
                                            <span id="staff-name">한미영</span>
                                        </div>
                                    </div>
                                    <div class="staff__card__inner__box">
                                        <a href="/" id="news-more-btn" class="card__more__btn card__btn__flex">자세히 보기</a>
                                    </div>
                                </div>
                            `
                        },
                        {
                            id: 7,
                            content: `
                                <div class="staff__card__item__wrapper_c">
                                    <div class="staff__card__title__wrapper_c">
                                        <div class="staff__card__img__wrapper"></div>
                                        <div class="staff__card__info__wrapper_c">
                                            <p id="staff-card-title" class="staff__card__inner__title" data-id="" data-name=""></p>
                                            <div class="staff__card__textbox">
                                                <p id="staff-card-dep" class="staff__card__timestamp_c">경제분석팀</p>
                                            </div>
                                            <span id="staff-name">서준호</span>
                                        </div>
                                    </div>
                                    <div class="staff__card__inner__box">
                                        <a href="/" id="news-more-btn" class="card__more__btn card__btn__flex">자세히 보기</a>
                                    </div>
                                </div>
                            `
                        },
                        {
                            id: 8,
                            content: `
                                <div class="staff__card__item__wrapper_c">
                                    <div class="staff__card__title__wrapper_c">
                                        <div class="staff__card__img__wrapper"></div>
                                        <div class="staff__card__info__wrapper_c">
                                            <p id="staff-card-title" class="staff__card__inner__title" data-id="" data-name=""></p>
                                            <div class="staff__card__textbox">
                                                <p id="staff-card-dep" class="staff__card__timestamp_c">리서치팀 국내부서</p>
                                            </div>
                                            <span id="staff-name">윤서연</span>
                                        </div>
                                    </div>
                                    <div class="staff__card__inner__box">
                                        <a href="/" id="news-more-btn" class="card__more__btn card__btn__flex">자세히 보기</a>
                                    </div>
                                </div>
                            `
                        }
                    ]
                }
            ];
            break;
            
        // 종목시세 조회 케이스들 (시세가 포함된 모든 케이스)
        default:
            // 종목명에 "시세"가 포함된 경우
            if (serviceType.includes("시세")) {
                baseData.exlinks = false;
                baseData.showActionButtons = false;
                baseData.relatedButtons = [];
                // smallButtons는 전달받은 값이 있으면 유지 (빈 배열이어도 유지)
                if (!data || data.smallButtons === undefined) {
                    baseData.smallButtons = [];
                }
            }
            break;
    }

    return baseData;
};

/**
 * 주식시장 공통 카드 생성 함수
 */
window.RebotCore.getStockMarketCards = function(data, period) {
    return [
        {
            id: "stock-chart",
            class: "query__card__comp",
            title: `${period} 차트 현황`,
            boxClass: "query__card__box",
            wrapperClass: "query__card__box__wrapper",
            itemClass: "query__card__wrapper",
            itemsClass: "query__card__items",
            itemBoxClass: "query__card__item__box",
            itemWrapperClass: "query__card__item__wrapper",
            items: [
                {
                    id: 1,
                    content: `
                        <div class="query__card__title__wrapper">
                            <p class="query__card__title">${period} 차트</p>
                        </div>
                        <div class="query__card__inner__box">
                            <div class="stock__chart__wrapper">
                                <img src="${data && data.chartData ? data.chartData.chartUrl : '/chartImgFiles/202510/chart_KGG01P_1_20251015094201841.png'}" 
                                     alt="${period}차트" class="stock__chart__img" style="width: 100%; max-width: 300px; height: auto;">
                            </div>
                            <div class="stock__price__info">
                                <p class="stock__price__text">${period === '코스닥' ? '코스닥' : '코스피'} ${data && data.chartData ? data.chartData.currentPrice : '3601.30'} 
                                    ${data && data.chartData ? (data.chartData.trend === 'up' ? '▲' : '▽') : '▲'}${data && data.chartData ? data.chartData.change : '39.49'} 
                                    ${data && data.chartData ? data.chartData.changeRate : '+1.11%'}</p>
                            </div>
                        </div>
                    `
                },
                {
                    id: 2,
                    content: `
                        <div class="query__card__title__wrapper">
                            <p class="query__card__title">매매동향 (${period})</p>
                        </div>
                        <div class="query__card__subtitle__wrapper">
                            <p class="query__card__subtitle">외국인 ${data && data.tradingData ? (data.tradingData.foreign > 0 ? '▲' : '▽') : '▲'}${data && data.tradingData ? Math.abs(data.tradingData.foreign) : '122'}억</p>
                            <p class="query__card__subtitle">기관 ${data && data.tradingData ? (data.tradingData.institution > 0 ? '▲' : '▽') : '▲'}${data && data.tradingData ? Math.abs(data.tradingData.institution) : '1,442'}억</p>
                            <p class="query__card__subtitle">개인 ${data && data.tradingData ? (data.tradingData.individual > 0 ? '▲' : '▽') : '▽'}${data && data.tradingData ? Math.abs(data.tradingData.individual) : '1,653'}억</p>
                        </div>
                    `
                }
            ]
        }
    ];
};

/**
 * 액션 버튼 그룹을 동적으로 추가하는 함수
 */
window.RebotCore.addActionButtons = function(container) {
    const actionButtonsHTML = `
        <div class="prompt__query__btn__group">
            <button id="prompt-query-btn" class="prompt__query__btn">
                <div class="prompt__query__btn_ic1"></div>
            </button>
            <button id="prompt-query-btn" class="prompt__query__btn">
                <div class="prompt__query__btn_ic2"></div>
            </button>
            <button id="prompt-query-btn" class="prompt__query__btn">
                <div class="prompt__query__btn_ic3"></div>
            </button>
            <button id="prompt-query-btn" class="prompt__query__btn">
                <div class="prompt__query__btn_ic4"></div>
            </button>
            <button id="prompt-query-btn" class="prompt__query__btn">
                <div class="prompt__query__btn_ic5"></div>
            </button>
            <button id="prompt-query-btn-fd" class="prompt__query__btn" data-target="prompt-btn-more">
                <div class="prompt__query__btn_ic6"></div>
            </button>
            
            <div id="prompt-btn-more" class="prompt__btn__more">
                <ul class="prompt__btn__more_ul">
                    <li class="prompt__btn__more_li">피드백</li>
                    <li class="prompt__btn__more_li">다른 메뉴</li>
                </ul>
            </div>
        </div>
    `;
    
    const promptQueryBox = container.querySelector('.prompt__query_box');
    if (promptQueryBox) {
        promptQueryBox.insertAdjacentHTML('beforeend', actionButtonsHTML);
        
        // 액션 버튼 이벤트 바인딩
        this.bindActionButtonEvents(container);
    }
};

/**
 * 액션 버튼 이벤트 바인딩
 */
window.RebotCore.bindActionButtonEvents = function(container) {
    // 더보기 버튼 이벤트
    const moreBtn = container.querySelector('#prompt-query-btn-fd');
    if (moreBtn) {
        moreBtn.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = moreBtn.getAttribute('data-target');
            const target = container.querySelector(`#${targetId}`);
            if (target) {
                target.classList.toggle('active');
            }
        });
    }
    
    // 피드백 및 다른 메뉴 이벤트
    const feedbackBtn = container.querySelector('.prompt__btn__more_li');
    if (feedbackBtn) {
        feedbackBtn.addEventListener('click', (e) => {
            e.preventDefault();
            console.log('피드백 클릭됨');
            // 피드백 모달 열기 등의 동작
        });
    }
    
    const otherMenuBtn = container.querySelectorAll('.prompt__btn__more_li')[1];
    if (otherMenuBtn) {
        otherMenuBtn.addEventListener('click', (e) => {
            e.preventDefault();
            console.log('다른 메뉴 클릭됨');
            // 다른 메뉴 동작
        });
    }
};

/**
 * 복잡한 결과 요소들에 이벤트 바인딩 (퍼블리싱된 구조에 맞게)
 */
window.RebotCore.bindComplexResultEvents = function(container) {
    // 출처 버튼 이벤트
    const exlinksBtn = container.querySelector('#prompt-exlinks-box');
    if (exlinksBtn) {
        exlinksBtn.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = exlinksBtn.getAttribute('data-target');
            const target = document.getElementById(targetId);
            if (target) {
                target.classList.toggle('active');
            }
        });
    }
    
    // 더보기 버튼 이벤트
    const moreBtn = container.querySelector('#prompt-query-btn-fd');
    if (moreBtn) {
        moreBtn.addEventListener('click', (e) => {
            e.preventDefault();
            const targetId = moreBtn.getAttribute('data-target');
            const target = container.querySelector(`#${targetId}`);
            if (target) {
                target.classList.toggle('active');
            }
        });
    }
    
    // 관련 질문 버튼 이벤트 (큰 버튼)
    const relatedBtns = container.querySelectorAll('.query__rl__it');
    console.log(`큰 버튼 개수: ${relatedBtns.length}`);
    relatedBtns.forEach((btn, index) => {
        console.log(`큰 버튼 ${index}: "${btn.textContent.trim()}"`);
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            const question = btn.textContent.trim();
            console.log(`큰 버튼 클릭: "${question}"`);
            this.subCallFunc(question);
        });
    });
    
    // 관련 질문 버튼 이벤트 (작은 버튼)
    const smallRelatedBtns = container.querySelectorAll('.query__rl__it__sm');
    console.log(`작은 버튼 개수: ${smallRelatedBtns.length}`);
    smallRelatedBtns.forEach((btn, index) => {
        console.log(`작은 버튼 ${index}: "${btn.textContent.trim()}"`);
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            
            // 종목 선택 버튼인지 확인 (data-stock-name 속성이 있는 경우)
            const stockName = btn.getAttribute('data-stock-name');
            if (stockName) {
                console.log(`종목 선택 버튼 클릭: "${stockName}"`);
                this.selectStockFromOptions(stockName);
                return;
            }
            
            // 차트 기간 버튼인지 확인 (분봉, 3개월, 6개월, 1년)
            const buttonText = btn.textContent.trim();
            const chartPeriods = ['분봉', '3개월', '6개월', '1년'];
            if (chartPeriods.includes(buttonText)) {
                console.log(`차트 기간 버튼 클릭: "${buttonText}"`);
                this.handleChartPeriodClick(buttonText, container);
                return;
            }
            
            // 일반 관련 질문 버튼인 경우
            const question = btn.textContent.trim();
            console.log(`작은 버튼 클릭: "${question}"`);
            this.subCallFunc(question);
        });
    });
    
    // 자세히 보기 버튼 이벤트
    const detailBtns = container.querySelectorAll('.card__more__btn');
    detailBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            console.log('자세히 보기 클릭됨');
        });
    });
    
    // 주식시장 관련 작은 버튼 이벤트
    const stockSmallBtns = container.querySelectorAll('.query__rl__it__sm');
    stockSmallBtns.forEach(btn => {
        const buttonText = btn.textContent.trim();
        if (['분봉', '3개월', '6개월', '1년', '코스피', '코스닥'].includes(buttonText)) {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                console.log('주식시장 작은 버튼 클릭:', buttonText);
                this.handleMinuteButtonClick(buttonText);
            });
        }
    });
    
    // 캘린더 이벤트들
    const calPrevBtn = container.querySelector('#cal-mon-prev');
    if (calPrevBtn) {
        calPrevBtn.addEventListener('click', (e) => {
            e.preventDefault();
            console.log('이전 달 클릭됨');
        });
    }
    
    const calNextBtn = container.querySelector('#cal-mon-next');
    if (calNextBtn) {
        calNextBtn.addEventListener('click', (e) => {
            e.preventDefault();
            console.log('다음 달 클릭됨');
        });
    }
    
    // 캘린더 날짜 클릭 이벤트
    const calDates = container.querySelectorAll('#cal-nb-date');
    calDates.forEach(date => {
        date.addEventListener('click', (e) => {
            e.preventDefault();
            console.log('캘린더 날짜 클릭됨:', date.textContent);
        });
    });
    
    // 캘린더 더보기 버튼
    const calMoreBtn = container.querySelector('#cal-more-btn');
    if (calMoreBtn) {
        calMoreBtn.addEventListener('click', (e) => {
            e.preventDefault();
            console.log('캘린더 더보기 클릭됨');
        });
    }
    
    // 캘린더 카드 더보기 버튼
    const calCardMoreBtns = container.querySelectorAll('#cal-li-more-btn');
    calCardMoreBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            console.log('캘린더 카드 더보기 클릭됨');
        });
    });
    
    // 스크롤 버튼 이벤트
    const scrollBtn = container.querySelector('#sc-btn');
    if (scrollBtn) {
        scrollBtn.addEventListener('click', (e) => {
            e.preventDefault();
            const chatArea = document.getElementById('main-chat-area');
            if (chatArea) {
                // 스크롤을 안전하게 처리
                chatArea.scrollTop = Math.min(chatArea.scrollHeight - chatArea.clientHeight, chatArea.scrollHeight);
            }
        });
    }
    
    // 카드 클릭 이벤트들
    const queryCards = container.querySelectorAll('.query__card__wrapper');
    queryCards.forEach(card => {
        card.addEventListener('click', (e) => {
            e.preventDefault();
            console.log('관련 질문 카드 클릭됨');
        });
    });
    
    const reportCards = container.querySelectorAll('.report__card__wrapper');
    reportCards.forEach(card => {
        card.addEventListener('click', (e) => {
            e.preventDefault();
            console.log('리포트 카드 클릭됨');
        });
    });
    
    const newsCards = container.querySelectorAll('.news__card__wrapper');
    newsCards.forEach(card => {
        card.addEventListener('click', (e) => {
            e.preventDefault();
            console.log('뉴스 카드 클릭됨');
        });
    });
    
    const staffCards = container.querySelectorAll('.staff__card__wrapper');
    staffCards.forEach(card => {
        card.addEventListener('click', (e) => {
            e.preventDefault();
            const staffName = card.querySelector('#staff-name');
            const staffDep = card.querySelector('#staff-card-dep');
            
            if (staffName && staffDep) {
                const name = staffName.textContent.trim();
                const department = staffDep.textContent.trim();
                console.log(`애널리스트 선택: ${name} (${department})`);
                
                // 애널리스트 선택 시 추가 동작
                this.showBotMessage(`${name} 애널리스트의 상세 정보를 조회합니다...`, name);
            } else {
                console.log('애널리스트 카드 클릭됨');
            }
        });
    });
    
    const calCards = container.querySelectorAll('.cal__card__wrapper');
    calCards.forEach(card => {
        card.addEventListener('click', (e) => {
            e.preventDefault();
            console.log('캘린더 카드 클릭됨');
        });
    });
    
    const liCards = container.querySelectorAll('.li__card__wrapper');
    liCards.forEach(card => {
        card.addEventListener('click', (e) => {
            e.preventDefault();
            console.log('원자재 카드 클릭됨');
        });
    });
};

// 전역 함수로 등록 (기존 챗봇 호환성)
window.XSSCheck = window.RebotCore.XSSCheck;
window.fn_chatBotBtn = window.RebotCore.fn_chatBotBtn.bind(window.RebotCore);
window.subCallFunc = window.RebotCore.subCallFunc.bind(window.RebotCore);
window.addActionButtons = window.RebotCore.addActionButtons.bind(window.RebotCore);
window.linkOpen = window.RebotCore.linkOpen.bind(window.RebotCore);

// 자동 초기화
$(document).ready(function() {
    window.RebotCore.init();
});
