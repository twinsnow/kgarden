const tarea = document.getElementById('content-chat-input');



function autoResize(el) {
    el.style.height = 'auto';
    el.style.height = `${el.scrollHeight}px`;

    const max = parseInt(getComputedStyle(el).maxHeight);
    el.style.overflowY = (el.scrollHeight > max) ? 'auto' : 'hidden';
}

['input','change','cut','paste'].forEach(evt =>
    tarea.addEventListener(evt, () => autoResize(tarea)));

autoResize(tarea)

const navSdToggle = document.getElementById('sd-toggle-nav')
const sdbar = document.getElementById('sidebar')
const sdbarOn = document.querySelector('.sidebar__cont_on')
const sdbarOff = document.querySelector('.sidebar__cont_off')

const logoShow = document.getElementById('nav-logo-top')

const sdListToggle = document.getElementById('sd-toggle-list');
const sdList = document.getElementById('sd-list');

const sdMenuLBtn = document.getElementById('open-sd-l-menu');
const sdMenuLBtnA = document.querySelector('.link__menu_btn')

const sdLMenu = document.getElementById('sd-l-menu');
const listLinkStop = document.querySelector('.link-title')

document.querySelectorAll('[data-target]').forEach(btn => {
  btn.addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();

    const targetId = btn.getAttribute('data-target');
    const target = document.getElementById(targetId);
    const toggleIcon = btn.querySelector('.list_toggle_icon')
    if (target && toggleIcon) {
        const isActive = target.classList.toggle('active');
        toggleIcon.src = isActive ? "icons/toggle_ic_i.svg" : "icons/toggle_ic.svg";
        toggleIcon.alt = isActive ? 'on' : 'off'
    }
  });
});


function openSideMenu(el) {
    el.addEventListener('click', (e) => {
        e.preventDefault();
        const currentStatus = sdbarOn.getAttribute('data-status');
        const nextStatus = currentStatus === 'on'? 'off' : 'on';

        sdbarOn.setAttribute('data-status', nextStatus);
        navSdToggle.setAttribute('data-status', nextStatus);


        if (nextStatus === 'off') {
            sdbarOff.setAttribute('data-status', 'on' )
            logoShow.classList.remove('nav__logo_tt')
            logoShow.classList.add('nav__logo_t')
            console.log(logoShow)
        } else if (nextStatus === 'on') {
            sdbarOff.setAttribute('data-status', 'off' )
            logoShow.classList.remove('nav__logo_t')
            logoShow.classList.add('nav__logo_tt')
        }
    })
}

openSideMenu(navSdToggle);

sdMenuLBtn.addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();
})

let currentBtn = null
let currentItemId = null

function openMenuNearButton(btn) {
  const btnRect = btn.getBoundingClientRect();

  const viewportHeight = window.innerHeight;
  const top  = 70;  // 버튼 아래
  const left = 0;
  console.log(top)
  console.log((btnRect.top / viewportHeight)* 10)

  sdLMenu.style.top  = `${top}px`; //70px 0
  sdLMenu.style.left = `${left}px`;

  sdLMenu.hidden = false;
  currentBtn = btn;
  currentItemId = btn.getAttribute('data-target') || null;

  btn.setAttribute('aria-expanded', 'true');
  btn.setAttribute('aria-controls', 'list-menu');
}

function closeMenu() {
  if (sdLMenu.hidden) return;
  sdLMenu.hidden = true;
  if (currentBtn) currentBtn.setAttribute('aria-expanded', 'false');
  currentBtn = null;
  currentItemId = null;
}

document.querySelectorAll('.link__menu_btn').forEach(btn =>
  btn.addEventListener('click', (e) => {
    console.log(sdLMenu)
    const btn = e.target.closest('.link__menu_btn');
    console.log('btn')
    console.log(btn)
    const rect = btn.getBoundingClientRect();
    console.log(rect);
    const li = sdLMenu
    console.log(li)
    if (!btn) return;

    e.preventDefault();
    e.stopPropagation();

    if (currentBtn === btn && !sdLMenu.hidden) {
      closeMenu();
      return;
    }

    openMenuNearButton(btn);
}));

const modelSelectBtn = document.getElementById('model-select-btn')
const modelSelectMenuId = document.getElementById('model-select-menu')
const modelSelectType = document.getElementById('model-select-type')




modelSelectBtn.addEventListener('click', (e) => {
  console.log(modelSelectBtn)
  e.preventDefault()
  
  const targetId = modelSelectBtn.getAttribute('data-target')
  const selectMenuId = document.getElementById(targetId)

  if (!selectMenuId) return

  console.log(selectMenuId)



  const isActive = selectMenuId.classList.toggle('active')

  if(isActive) {
    modelSelectBtn.setAttribute('data-status', 'btn-on');
  } /* else if(isActive !== 'active') {
    modelSelectBtn.setAttribute('data-status', 'btn-off');
  } */

  checkModelBtn(modelSelectBtn)
})

modelSelectType.addEventListener('click', (e) => {
  e.preventDefault()
})


function checkModelBtn (el) {
  const checkModelStatus = el.getAttribute('data-status')
  const toggleIcon = el.querySelector('.model__icons')

  if (!checkModelStatus) return;
  if(checkModelStatus === 'btn-on') {
    el.classList.add('btn__on')
    toggleIcon.src = "icons/model_active_ic.svg";
    toggleIcon.alt = isActive ? 'on' : 'off'
  } else if (checkModelStatus=== 'btn-off') {
    el.classList.remove('btn__on')
    toggleIcon.src = "icons/model_ic.svg";
  } else {
    console.warn(`Unexpected data-status value. Expected 'btn-on' or 'btn-off'.`);
  }
}

const rightPopupClose = document.getElementById('right-menu-close')
const rightPopupMenu = document.getElementById('right-popup-menu')

const rightPopupLinks = document.getElementById('right-popup-links')
const rightLinksBtn = document.getElementById('prompt-exlinks-box')
const rightLinksClose = document.getElementById('right-links-close')




rightPopupClose.addEventListener('click', () => {
  console.log(rightPopupClose)
  if(rightPopupClose !== null) {
    rightPopupMenu.style.display = 'none'
  }
})


rightLinksBtn.addEventListener('click', (e) => {
  e.preventDefault();

  const targetId = rightLinksBtn.getAttribute('data-target');
  const rightLinksId = document.getElementById(targetId);
  if (!rightLinksId) return;

  const isActive = rightLinksId.classList.toggle('active');

  if (isActive) {
    rightLinksId.classList.remove('display-off');
  } else {
    rightLinksId.classList.add('display-off');
  }
});

rightLinksClose.addEventListener('click', () => {
  const targetId = rightLinksBtn.getAttribute('data-target');
  const rightLinksId = document.getElementById(targetId);
  if (!rightLinksId) return;

  rightLinksId.classList.remove('active');
  rightLinksId.classList.add('display-off');
});
