## rebot
part: publishing


tools & language
- html, css
- jscript

## todo

### Styling
- [ ] 사이드 바 작업 : 모달 버튼 동작
- [ ] 단추바 일렬 : 페이드 효과
- [ ] 채팅 자동 스크롤 바 수정
- [ ] (input) textarea resizing
- [ ] tablet, mobile 반응형에서 modal
- [ ] dark mode 색상 변경
- [ ] 아이콘 SVG 정리 및 배포 시 깨짐 방지 처리 



## 수정사항



### 9/9 수정사항 - 공통 index.html && prompt.html 
 - 8: title
 - 14: deleted
 - 22: div + anchor tag 추가
 - 26: id added
 - 28: , 31: id added
 - 66:, 70:, 75:, 82:, 84:, 85: id added
 - 93:, 97:, 102:, 109:, 111:, 112: id added
 - 120: id added
 - 블럭 교체 필요 (내부 id, class 등 구조 변화) <div id="prompt-content" class="prompt__content__box__main">
 - 블럭 교체 필요 <dialog id="modal" claas="modal__root main__wrapper" aria-labelledby="modalTitle">
 - <script src="/js/main.js"></script>, <script src="/js/modal.js"></script> , 이 외 하나의 내부 스크립트 추가(305:)

 ### 9/9 수정사항 - modal
  - common_bm.html added


-----------------------

  ### 9/11 수정사항 - 공통 index.html && prompt.html
 - 52: 블럭 교체 필요 (내부 id, class 등 구조 변화) <div id="sidebar" class="sidebar__cont_on" data-status="on">

 ### 9/11 수정사항 - 공통 index.html
 - 263: 블럭 교체 필요 (내부 id, class 등 구조 변화) <div class="content__model__select">

 ### 9/11 수정사항 - prompt.html 
  - 227: 블럭 위치 변경 <div class="prompt__query__exlinks"> >> <div class="prompt__query__btn__group">
  - 265: 블럭 추가 <div id="query-card-comp" class="query__card__comp">
  - 329: 블럭 추가 <div id="report-card-comp" class="report__card__comp">
  - 418: 블럭 교체 필요 <div class="content__model__select">