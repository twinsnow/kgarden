## rebot
part: publishing


tools & language
- html, css
- jscript

## todo

### Styling
- [ ] 크로스 브라우징 : edge, mozilla, edge > 글자 폰트 렌더링 이외 특별한 이슈 없음
- [ ] 아이콘 SVG 정리 및 배포 시 깨짐 방지 처리

### 요청 사항
- [ ] 사이드 바 리스트 메뉴 : 위치 동적으로 잡아 주세요 (main.js 218)
- [ ] 메세지 입력창 입력시 1줄 이상의 경우, 스타일 변경 하도록 해주세요 (라인 하이트 계산 등의 동적 변화 필요) (main.js 1)
- [ ] 설정 모달 창 : 기능 추가 해 주세요 ( 버튼, 디스플레이 모드 ) (modal.js 150)
- [ ] 글자 포인트 설정 : 추후 추가 드리겠습니다.
- [ ] 모바일 키보드 뜰 경우, 레이 아웃 점검 필요

## 지난 수정 사항

### 9/9 수정사항 - 공통 index.html && prompt.html 
 - 8: title
 - 14: deleted
 - 22: div + anchor tag 추가
 - 26: id added
 - 28: , 31: id added
 - 66:, 70:, 75:, 82:, 84:, 85: id added
 - 93:, 97:, 102:, 109:, 111:, 112: id added
 - 120: id added
 - 블럭 교체 필요 (내부 id, class 등 구조 변화) <div id="prompt-content" class="prompt__content__box__main">
 - 블럭 교체 필요 <dialog id="modal" claas="modal__root main__wrapper" aria-labelledby="modalTitle">
 - <script src="/js/main.js"></script>, <script src="/js/modal.js"></script> , 이 외 하나의 내부 스크립트 추가(305:)

 ### 9/9 수정사항 - modal
  - common_bm.html added


-----------------------

  ### 9/11 수정사항 - 공통 index.html && prompt.html
 - 52: 블럭 교체 필요 (내부 id, class 등 구조 변화) <div id="sidebar" class="sidebar__cont_on" data-status="on">

 ### 9/11 수정사항 - 공통 index.html
 - 263: 블럭 교체 필요 (내부 id, class 등 구조 변화) <div class="content__model__select">

 ### 9/11 수정사항 - prompt.html 
  - 227: 블럭 위치 변경 <div class="prompt__query__exlinks"> >> <div class="prompt__query__btn__group">
  - 265: 블럭 추가 <div id="query-card-comp" class="query__card__comp">
  - 329: 블럭 추가 <div id="report-card-comp" class="report__card__comp">
  - 418: 블럭 교체 필요 <div class="content__model__select">


 ### 9/25 오후 수정사항
  - 아이콘 추가
  - 모든 파일 교체 필요

  ### 9/29 오전수정사항
  - 글자 렌더링 수정
  - 테이블 보더 수정
  - 모질라 스크롤 커스텀
  - 모달 반응형 수정
  - cal.css, main.css, modal.css 교체 필요