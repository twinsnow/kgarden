/**
 * Rebot Utilities
 * 기존 sixUtils.js의 핵심 기능들을 rebot 프로젝트에 맞게 최적화
 */

window.RebotUtils = {
    
    /**
     * 숫자에 콤마 추가
     * @param {number|string} num - 숫자
     * @returns {string} - 콤마가 추가된 문자열
     */
    addComma: function(num) {
        if (num === null || num === undefined || num === '') return '0';
        return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    },
    
    /**
     * 콤마 제거
     * @param {string} str - 콤마가 포함된 문자열
     * @returns {string} - 콤마가 제거된 문자열
     */
    removeComma: function(str) {
        if (!str) return '';
        return str.toString().replace(/,/g, '');
    },
    
    /**
     * 숫자 패딩 (앞에 0 추가)
     * @param {number|string} num - 숫자
     * @param {number} length - 패딩 길이
     * @returns {string} - 패딩된 문자열
     */
    padZero: function(num, length) {
        if (!num) return '';
        return num.toString().padStart(length, '0');
    },
    
    /**
     * 문자열 길이 계산 (한글 2자리로 계산)
     * @param {string} str - 문자열
     * @returns {number} - 계산된 길이
     */
    getStringLength: function(str) {
        if (!str) return 0;
        let length = 0;
        for (let i = 0; i < str.length; i++) {
            if (str.charCodeAt(i) > 127) {
                length += 2; // 한글
            } else {
                length += 1; // 영문
            }
        }
        return length;
    },
    
    /**
     * 날짜 포맷팅
     * @param {Date|string} date - 날짜
     * @param {string} format - 포맷 (YYYY-MM-DD, MM/DD 등)
     * @returns {string} - 포맷된 날짜 문자열
     */
    formatDate: function(date, format = 'YYYY-MM-DD') {
        if (!date) return '';
        
        const d = new Date(date);
        if (isNaN(d.getTime())) return '';
        
        const year = d.getFullYear();
        const month = String(d.getMonth() + 1).padStart(2, '0');
        const day = String(d.getDate()).padStart(2, '0');
        const hours = String(d.getHours()).padStart(2, '0');
        const minutes = String(d.getMinutes()).padStart(2, '0');
        const seconds = String(d.getSeconds()).padStart(2, '0');
        
        return format
            .replace('YYYY', year)
            .replace('MM', month)
            .replace('DD', day)
            .replace('HH', hours)
            .replace('mm', minutes)
            .replace('ss', seconds);
    },
    
    /**
     * 현재 시간 포맷팅
     * @param {string} format - 포맷
     * @returns {string} - 포맷된 현재 시간
     */
    getCurrentTime: function(format = 'HH:mm:ss') {
        return this.formatDate(new Date(), format);
    },
    
    /**
     * 상대 시간 표시 (예: 3분 전)
     * @param {Date|string} date - 날짜
     * @returns {string} - 상대 시간 문자열
     */
    getRelativeTime: function(date) {
        if (!date) return '';
        
        const now = new Date();
        const target = new Date(date);
        const diff = now - target;
        
        const seconds = Math.floor(diff / 1000);
        const minutes = Math.floor(seconds / 60);
        const hours = Math.floor(minutes / 60);
        const days = Math.floor(hours / 24);
        
        if (days > 0) return `${days}일 전`;
        if (hours > 0) return `${hours}시간 전`;
        if (minutes > 0) return `${minutes}분 전`;
        return '방금 전';
    },
    
    /**
     * 숫자 범위 체크
     * @param {number} value - 값
     * @param {number} min - 최소값
     * @param {number} max - 최대값
     * @returns {boolean} - 범위 내 여부
     */
    isInRange: function(value, min, max) {
        return value >= min && value <= max;
    },
    
    /**
     * 배열에서 중복 제거
     * @param {Array} arr - 배열
     * @returns {Array} - 중복이 제거된 배열
     */
    removeDuplicates: function(arr) {
        if (!Array.isArray(arr)) return [];
        return [...new Set(arr)];
    },
    
    /**
     * 객체 깊은 복사
     * @param {Object} obj - 객체
     * @returns {Object} - 복사된 객체
     */
    deepClone: function(obj) {
        if (obj === null || typeof obj !== 'object') return obj;
        if (obj instanceof Date) return new Date(obj.getTime());
        if (obj instanceof Array) return obj.map(item => this.deepClone(item));
        if (typeof obj === 'object') {
            const clonedObj = {};
            for (const key in obj) {
                if (obj.hasOwnProperty(key)) {
                    clonedObj[key] = this.deepClone(obj[key]);
                }
            }
            return clonedObj;
        }
    },
    
    /**
     * 디바운스 함수
     * @param {Function} func - 실행할 함수
     * @param {number} wait - 대기 시간 (ms)
     * @returns {Function} - 디바운스된 함수
     */
    debounce: function(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    },
    
    /**
     * 스로틀 함수
     * @param {Function} func - 실행할 함수
     * @param {number} limit - 제한 시간 (ms)
     * @returns {Function} - 스로틀된 함수
     */
    throttle: function(func, limit) {
        let inThrottle;
        return function(...args) {
            if (!inThrottle) {
                func.apply(this, args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, limit);
            }
        };
    }
};
