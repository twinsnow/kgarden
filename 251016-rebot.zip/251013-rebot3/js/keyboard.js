let lastHeight = window.innerHeight;

window.addEventListener('resize', () => {
  if (window.innerHeight < lastHeight) {
    console.log('Probably keyboard opened');
  } else {
    console.log('Probably keyboard closed');
  }
  lastHeight = window.innerHeight;
});

const kb = document.querySelector('.chat__btn');
const ta = document.getElementById('content-chat');
kb.addEventListener('click', () => {
    ta.focus(); // 이 경우에만 모바일 키보드 올라옴
    navigator.virtualKeyboard.show();
});

if (window.visualViewport) {
  kb.addEventListener("focus", () => {
    window.visualViewport.addEventListener("resize", handleKeyboard);
    console.log("viewport height:", window.visualViewport.height);
  });

  kb.addEventListener("blur", () => {
    window.visualViewport.removeEventListener("resize", handleKeyboard);
  });
}

function handleKeyboard() {
  const vh = window.visualViewport.height;
  console.log("viewport height:", vh);

  ta.style.bottom = `${window.innerHeight - vh}px`;
}

const onVV = () => {
  const vv = window.visualViewport;
  const delta = window.innerHeight - vv.height;
  ta.style.transform = delta > 80 ? `translateY(${-delta}px)` : 'translateY(0)';
};

if (window.visualViewport) {
  window.visualViewport.addEventListener('resize', onVV);
  window.visualViewport.addEventListener('scroll', onVV); // iOS 대응
}

ta.addEventListener('focus', () => document.body.classList.add('kb-open'));
ta.addEventListener('blur',  () => document.body.classList.remove('kb-open'));



ta.addEventListener('focus', () => {
  setTimeout(() => ta.scrollIntoView({block:'center', behavior:'smooth'}), 50);
});
