## rebot
part: publishing


tools & language
- html, css
- jscript

## todo

### Styling
- [ ] modal views (fetch)
- [ ] 아이콘 SVG 정리 및 배포 시 깨짐 방지 처리  
- [ ] 채팅 자동 스크롤 색상
- [ ] (input) textarea resizing
- [ ] tablet, mobile 반응형에서 modal
- [ ] dark mode 색상 변경  