/**
 * flexible ta 메세지 입력창 입력시 1줄 이상의 경우, 스타일 변경 하도록 해주세요 (라인 하이트 계산 등의 동적 변화 필요)
 */

const tarea = document.getElementById('content-chat-input');

function debounce(fn, ms = 120) {
  let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
}


function setupAutosize(el, {
  minRows = 1,
  maxRows = 2 + 1,
  multiClass = 'is-multiline',  // 2줄↑일 때 붙일 클래스
} = {}) {
  // 내부 여백/박스모델 계산
  const getMetrics = () => {
    const cs = getComputedStyle(el);
    const boxBorder = cs.boxSizing === 'border-box';
    const padY = parseFloat(cs.paddingTop) + parseFloat(cs.paddingBottom);
    const borderY = parseFloat(cs.borderTopWidth) + parseFloat(cs.borderBottomWidth);
    // line-height가 'normal'인 경우 보정
    let lh = parseFloat(cs.lineHeight);
    if (Number.isNaN(lh)) lh = (parseFloat(cs.fontSize) || 16) * 1;
    console.log(lh)
    // CSS max-height 우선 존중
    let cssMax = parseFloat(cs.maxHeight);
    if (Number.isNaN(cssMax)) cssMax = Infinity;
    return { boxBorder, padY, borderY, lh, cssMax };
  };

  const measure = () => {
    const { boxBorder, borderY, lh, cssMax } = getMetrics();

    // 높이 재측정
    el.style.height = 'auto';
    const raw = el.scrollHeight;
    
    const contentH = boxBorder ? raw - borderY : raw;
    let rows = Math.max(minRows, Math.round(contentH / lh));
    console.log(`result:${contentH}`)
    if (Number.isFinite(rows)) rows = Math.max(rows, minRows);
    // 목표 높이(px)
    let target = raw;
    console.log(`target${target}`)
    
    if (cssMax !== Infinity) target = Math.min(target, cssMax);
    console.log(`cssMax${cssMax}`)

    el.style.height = Math.ceil(target) + 'px';

    const chInput1 = document.querySelector('.content__chat__wrapper')
    const chInput = document.querySelector('.chat__control__box')
    // 2줄 이상일 때 형태 전환
    if(rows > maxRows) {
      console.log(`maxRows${rows}`)
      el.classList.add(multiClass);
      chInput.classList.add('chat__input_me');
      chInput1.classList.add('chat__input_me')
    } else if (rows <= maxRows) {
      console.log(`rows${rows}`)
      el.classList.remove(multiClass)
      chInput.classList.remove('chat__input_me');
      chInput1.classList.remove('chat__input_me')
    }
    // 스크롤 필요 여부
    const needsScroll = (rows > maxRows) || (cssMax !== Infinity && raw > cssMax);
    el.style.overflowY = needsScroll ? 'auto' : 'hidden';
  };

  // 입력/붙여넣기/IME 종료 시
  const onInput = () => requestAnimationFrame(measure);
  ['input','cut','paste','change','compositionend'].forEach(evt =>
    el.addEventListener(evt, onInput)
  );

  // 반응형: 너비/폰트 변화 감지 (ResizeObserver)
  let ro;
  if (window.ResizeObserver) {
    ro = new ResizeObserver(debounce(measure, 50));
    ro.observe(el);
    ro.observe(document.documentElement); // 폰트/미디어쿼리 변화도 커버
  } else {
    // 폴백
    const onWinResize = debounce(measure, 100);
    window.addEventListener('resize', onWinResize);
    el._autosizeWinResize = onWinResize;
  }

  // 초기 1회
  measure();

  // 정리용 핸들
  return {
    destroy() {
      ['input','cut','paste','change','compositionend'].forEach(evt =>
        el.removeEventListener(evt, onInput)
      );
      if (ro) ro.disconnect();
      if (el._autosizeWinResize) {
        window.removeEventListener('resize', el._autosizeWinResize);
        delete el._autosizeWinResize;
      }
    }
  };
}

// 사용
const autosize = setupAutosize(tarea, {
  minRows: 1,
  maxRows: 2 + 1,
  multiClass: 'is-multiline'
});


const sdCon = document.getElementById('sidebar-container')
const sdToggle = document.getElementById('sd-toggle-nav')
const sdTgMo = document.getElementById('sd-open-mo')

const sdbar = document.getElementById('sidebar')
const sdbarOn = document.querySelector('.sidebar__cont_on')
const sdbarOff = document.querySelector('.sidebar__cont_off')

const logoShow = document.getElementById('nav-logo-top')
const logoShowMo = document.getElementById('nav-logo-top-mo')
const sdListToggle = document.getElementById('sd-toggle-list');
const sdList = document.getElementById('sd-list');

const sdMenuLBtn = document.getElementById('open-sd-l-menu');
const sdMenuLBtnA = document.querySelector('.link__menu_btn')

const sdLMenu = document.getElementById('sd-l-menu');
const listLinkStop = document.querySelector('.link-title')

document.querySelectorAll('[data-target]').forEach(btn => {
  btn.addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();

    const targetId = btn.getAttribute('data-target');
    const target = document.getElementById(targetId);
    const toggleIcon = btn.querySelector('.list_toggle_icon')
    if (target && toggleIcon) {
        const isActive = target.classList.toggle('active');
        toggleIcon.src = isActive ? "icons/toggle_ic_i.svg" : "icons/toggle_ic.svg";
        toggleIcon.alt = isActive ? 'on' : 'off'
    }
  });
});


const navIcSize = document.querySelector('.sd__toggle__wrapper')
const navIcId = document.getElementById('sd-toggle-nav')
const navIc = document.querySelector('.nav__icon2')

function openSideMenu(el) {
    el.addEventListener('click', (e) => {
        e.preventDefault();
        const currentStatus = sdbarOn.getAttribute('data-status');
        console.log(currentStatus)
        
        const nextStatus = currentStatus === 'on'? 'off' : 'on';

        sdbarOn.setAttribute('data-status', nextStatus);
        sdToggle.setAttribute('data-status', nextStatus);


        if (nextStatus === 'off') {
            sdbarOff.setAttribute('data-status', 'on')
            logoShow.classList.remove('nav__logo_tt')
            logoShow.classList.add('nav__logo_t')

            navIcSize.style.width = '3rem'
            navIcSize.style.textAlign = 'end'
            navIcId.setAttribute('data-tooltip','열기')
            navIc.setAttribute('data-status', '열기')
            navIc.classList.add('nav__icon2_open')
        } else if (nextStatus === 'on') {
            sdbarOff.setAttribute('data-status', 'off' )
            logoShow.classList.remove('nav__logo_t')
            logoShow.classList.add('nav__logo_tt')
            navIcSize.style.width = '7rem'
            navIcId.setAttribute('data-tooltip','닫기')
            navIc.setAttribute('data-status', '닫기')
            navIc.classList.remove('nav__icon2_open')
        }
    })
}

openSideMenu(sdToggle);

function openSideMenuMo(el) {
  el.addEventListener('click', (e) => {
    e.preventDefault();

    const curMo = sdCon.getAttribute('data-status-mo') || 'off';
    const nextMo = curMo === 'on' ? 'off' : 'on';

    sdCon.setAttribute('data-status-mo', nextMo);
    sdTgMo?.setAttribute('data-status-mo', nextMo);

    const getStatus = document.querySelector('.sidebar__cont_off');
    const tStatus = sdbarOff?.getAttribute('data-status') || 'off';
    const curMoAgain = sdbarOn.getAttribute('data-status-mo');
  });
}


openSideMenuMo(sdTgMo)

sdMenuLBtn.addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();
})
let currentBtn = null
let currentItemId = null
/** 사이드 바 리스트 메뉴 : 위치 동적으로 잡아 주세요 */
function openMenuNearButton(btn) {
  const btnRect = btn.getBoundingClientRect();

  const viewportHeight = window.innerHeight;
  const top  = 70;
  const left = 0;
  console.log(top)
  console.log((btnRect.top / viewportHeight)* 10)

  sdLMenu.style.top  = `${top}px`;
  sdLMenu.style.left = `${left}px`;

  sdLMenu.hidden = false;
  currentBtn = btn;
  currentItemId = btn.getAttribute('data-target') || null;

  btn.setAttribute('aria-expanded', 'true');
  btn.setAttribute('aria-controls', 'list-menu');
}

const sdMoBtn = document.getElementById('sd-nav-toggle-mo')
 

sdMoBtn.addEventListener('click', () => {
  console.log(sdCon)
  sdCon.setAttribute('data-status-mo', 'off');
})

function closeMenu() {
  if (sdLMenu.hidden) return;
  sdLMenu.hidden = true;
  if (currentBtn) currentBtn.setAttribute('aria-expanded', 'false');
  currentBtn = null;
  currentItemId = null;
}

document.querySelectorAll('.link__menu_btn').forEach(btn =>
  btn.addEventListener('click', (e) => {
    console.log(sdLMenu)
    const btn = e.target.closest('.link__menu_btn');
    console.log('btn')
    console.log(btn)
    const rect = btn.getBoundingClientRect();
    console.log(rect);
    const li = sdLMenu
    console.log(li)
    if (!btn) return;

    e.preventDefault();
    e.stopPropagation();

    if (currentBtn === btn && !sdLMenu.hidden) {
      closeMenu();
      return;
    }

    openMenuNearButton(btn);
}));

document.addEventListener('click', (e) => {
  if(sdLMenu.hidden) return

  const clickedMenu = e.target.closest('#sd-l-menu')
  const clickedBtn = e.target.closest('.link__menu_btn')

  if (!clickedMenu && !clickedBtn) closeMenu()
})

const promptQueryBtn = document.getElementById('prompt-query-btn-fd')

const rightPopupClose = document.getElementById('right-menu-close')
const rightPopupMenu = document.getElementById('right-popup-menu')

const rightPopupLinks = document.getElementById('right-popup-links')
const rightLinksBtn = document.getElementById('prompt-exlinks-box')
const rightLinksClose = document.getElementById('right-links-close')

if(rightPopupClose) {
  rightPopupClose.addEventListener('click', () => {
  console.log(rightPopupClose)
  if(rightPopupClose !== null) {
    rightPopupMenu.style.display = 'none'
  }
})}


if(rightLinksBtn) {
  rightLinksBtn.addEventListener('click', (e) => {
  e.preventDefault();

  const targetId = rightLinksBtn.getAttribute('data-target');
  const rightLinksId = document.getElementById(targetId);
  if (!rightLinksId) return;

  const isActive = rightLinksId.classList.toggle('active');

  if (isActive) {
    rightLinksId.classList.remove('display-off');
  } else {
    rightLinksId.classList.add('display-off');
  }
});
}

if(rightLinksClose) {rightLinksClose.addEventListener('click', () => {
  const targetId = rightLinksBtn.getAttribute('data-target');
  const rightLinksId = document.getElementById(targetId);
  if (!rightLinksId) return;

  rightLinksId.classList.remove('active');
  console.log(rightLinksClose)
  rightLinksId.classList.add('display-off');
});}


const tip = document.getElementById('chipbar-tip');
const mq = window.matchMedia('(min-width: 767px)');
let tipShownOnce = false;

function showTipOnce(){
  
  if (tipShownOnce) return; 
  tip.setAttribute('aria-hidden','false');
  tip.classList.add('is-show');
  tipShownOnce = true;
  
  setTimeout(() => {
    tip.classList.remove('is-show');
    tip.setAttribute('aria-hidden','true');
  }, 12200);
}

// 첫 로드/리사이즈 시점
showTipOnce();
mq.addEventListener?.('change', showTipOnce);


// 스크롤하거나 칩바 터치/클릭하면 즉시 숨김
['scroll','touchstart','click'].forEach(evt=>{
  window.addEventListener(evt, () => {
    if (tip.classList.contains('is-show')) {
      tip.classList.remove('is-show');
      tip.setAttribute('aria-hidden','true');
    }
  }, { passive:true });
});

function setAppHeight() {
  const h = window.visualViewport ? window.visualViewport.height : window.innerHeight;
  document.documentElement.style.setProperty('--app-height', `${h}px`); // 3.125rem ≈ 50px
}
window.addEventListener('resize', setAppHeight);
window.addEventListener('orientationchange', setAppHeight);
setAppHeight();