const box = document.querySelector('.cal__sc__box');
const btn = document.querySelector('.cal__card__more__btn');
const card = document.querySelector('.cal__card__wrapper');


if (box.scrollHeight > box.clientHeight) {
  box.classList.add('is-multiline');
  btn.hidden = false;
}
document.querySelectorAll('.cal__card__more__btn').forEach(btn => {
  btn.addEventListener('click', e => {
    // 버튼이 속한 카드 찾기
    const card = btn.closest('.cal__card__wrapper');   // 각 카드의 루트
    if (!card) return;

    const box = card.querySelector('.cal__sc__box'); // 카드 안의 내용 박스
    if (!box) return;

    // 토글 처리
    box.classList.toggle('is-open');
    card.classList.toggle('is-multiline');
    btn.textContent = box.classList.contains('is-open') ? '접기' : '더 보기';
  });
});

if(promptQueryBtn){

  promptQueryBtn.addEventListener('click', (e) => {
    e.preventDefault()
    
    const targetId = promptQueryBtn.getAttribute('data-target')
    const selectMenuId = document.getElementById(targetId)

    if (!selectMenuId) return

    if(selectMenuId) {
      selectMenuId.classList.toggle('active')
    }

  })
  
}

if(promptQueryBtn)
document.addEventListener('click', (e) => {
  const selected = promptQueryBtn.getAttribute('data-target') || '';

  if(selected) {
    const clickedMenu = document.getElementById(selected)
    clickedMenu.classList.remove('active')
  }
})
