/** ChatBot Push Logic
 * 작성자 : 오아란
 * 작성일 : 2020.08.05
 * */

/* 전역변수 선언 */
var userIdCk = $("#userIdCk").val();
var sectCodeList = [];

var toDate = "";
var toHours = "";
var toMin = "";

// 메세지 push 합수
function sendPushMsg(date) {
	
	toDate = moment(date).format("YYYYMMDD");
	toHours = moment(date).format("HH");
	toMin = moment(date).format("mm");
	
	var userInfo = {};
	
	getChatBotUserConfig().then(function(rsUser){
		
		userInfo = rsUser.response[0];
		sectCodeList = [];
		var sectCode = "";
		var dailyChk = "N";
		
		
		// 사용자가 선택한 카테고리 리스트
		if(userInfo.sectorCodes.indexOf("|")>-1) {
			sectCodeList = userInfo.sectorCodes.split("|");
		}else{
			sectCodeList[0] = userInfo.sectorCodes;
		}
		
		if(userInfo.pushYn=="Y") {
			// 07:00 글로벌 증시
			if(toHours=="07" && toMin=="00") {
				if(userInfo.indexPushYn=="Y" && userInfo.userKey!=undefined && userInfo.userKey!=null && String(userInfo.userKey).trim()!="") {
					pushWorldIndex(userInfo);	
				}			
			}
			// 07:30 KB데일리
			if(toHours=="07" && toMin=="30") {
				for(var i=0; i<sectCodeList.length; i++) {
					sectCode = sectCodeList[i].split("@");
		            if(sectCode[1]=="20") {
		            	dailyChk = "Y";
		            }
		        }
				if(dailyChk=="Y"){
			        pushKBDaily();
				}
			}
		}
		
		// 07:55 헤드라인
		if(toHours=="07" && toMin=="55") {
			if(userInfo.headlinePushYn=="Y" && userInfo.userKey!=undefined && userInfo.userKey!=null && String(userInfo.userKey).trim()!="") {
				pushHeadLine();
			}
		}
		
		// 투데이리포트 (5분마다)
		if(userInfo.pushYn=="Y") {
			
			pushTodayReport();
			pushAlarm(userInfo.userId);
		}              

	});
}

//----------------------------- 요청 구분별 함수 목록 -----------------------------//
// push 투데이리포트
function pushTodayReport(){
	var param = setReportSearchDate();
	var resMsg = "";
	var reportList = [];
	var report = {}; 
	var catgrIdList = [];
	var pCatgrId = "";
	var sectCode = "";
	var pushChk = "N";
	
	getChatBotTodayReportList(param).then(function(result) {
		reportList = result.response.reportList;		
		if(reportList.length > 0) {
			for(var i=0; i<reportList.length; i++){
				report = reportList[i];
				catgrIdList = [];
				
				
				// 리포트 카테고리 리스트 
				if(String(report.categoryid).indexOf(",")>-1) {
					catgrIdList = report.categoryid.split(",");
				}else {
					catgrIdList[0] = report.categoryid;
				}
				
				for(var j=0; j<catgrIdList.length; j++) {
					pCatgrId = getPCategoryId(catgrIdList[j]);
					
					if(pCatgrId != null) {
						for(var k=0; k<sectCodeList.length; k++) {
							sectCode = sectCodeList[k].split("@");
							
							if((sectCode[1]==pCatgrId) && (sectCode[1]!="20")) {
								pushChk = "Y";
							}
						}
					}
				}
				
				if(pushChk == "Y") {
					RebotCore.showBotMessage(makeHtmlReport(report), "투데이 리포트");
				}
			}
		}
	});
}

// 투데이리포트 메세지 (aichatbot.js의 makeSrchHtml 템플릿 적용)
function makeHtmlReport(report) {
	var resMsg = [];
	var docTitle = report.docTitle;
    var name = report.analystNm;
    var date = report.publicDate;
    date = date.substring(0,4) + "/" + date.substring(5,7) + "/" + date.substring(8,10);

    //var urlLinkH = report.urlLinkH;
    //var reportUrl = "/detailView.able?documentid=" + report.documentid;
    var reportUrl = report.urlLink

    //var summary = report.docDetail ? report.docDetail.substring(0,350).replaceTag() : null;
    var summary = report.docDetail ? report.docDetail.substring(0,350).replace() : null;
    summary = summary.replace(/\n/g, "<br>");
    var ellipse = summary&&report.docDetail.length > 350 ? "..." : "";

    var docTitleSub = "";
    if(report.docTitleSub != "" && report.docTitleSub != docTitle) {
    	docTitleSub = " : " + report.docTitleSub;
    }

    // 종목의견
    var recomm = report.recomm && report.recomm != "Not Rated" ? report.recomm : "";
    var recommChg = report.recommChg ? report.recommChg : "";
    var tp = String(Math.ceil(Number(report.tp))).commify();

    var temp = [];
    if(recomm!="") temp.push(recomm);
    if(recommChg!="") temp.push(recommChg);
    if(tp != "0") temp.push("목표가 " + tp + "원");
    if(temp.length>0) {
        docTitle = docTitle.replace(/\((.*?)\)/, "(" + temp.join(", ") + ")");
    }

    //종목구분
    var reportTag = report.reportTag || "";
    if(reportTag){
    	resMsg.push("<li class='font_B'>" + reportTag + "</li>");
    }

    resMsg.push("<li class='font_B'>" + docTitle + docTitleSub + "</li>");
    resMsg.push("<li>" + name + ", " + date + "</li>");

    if (summary) {
    	resMsg.push("<br><li>" + summary + ellipse + "</li>");
    }
    //resMsg.push("<br>☞ <a href='" + urlLinkH + "'><font color='blue'>" + urlLinkH + "</font></a>");
    resMsg.push("<br><a href='javascript:void(0)' onclick='linkOpen(\"" + reportUrl + "\");'><img src='/images/web/webchatbot_link.png' width='66px' height='19px'/></a>");

    return resMsg.join("");
}

// push 글로벌 증시
function pushWorldIndex(userInfo) {
	var preDateInfo = setPreDate(1);	//마감날짜셋팅
	var closeDate = String(preDateInfo.preYear) + String(preDateInfo.preMonth) + String(preDateInfo.preDay);
	var param = {date:closeDate};
	var paramMrk = {};
	var resultData = {};
	var message = [];
	
	var week = new Date().getDay();
	var from_key = "";
	var to_key = "";
	var preDateInfo2 = {};
	
	getClosure(param).then(function(result) {
		if(result.status=="200") {
			resultData = result.response;
			
			if(resultData!=undefined && resultData!=null) {	// 미국 휴장일
				message.push("<li class='font_B'>- 미국/유럽 주요지수 알림 -</li><br>");
				message.push("<li>미국주식시장 휴장</li>");
				message.push("<li>- " + resultData.descr + "</li>");
				RebotCore.showBotMessage(message.join(""), "글로벌증시");
			}else {
				if(week==0 || week==7) {	//0:일요일 7:토요일
					preDateInfo2 = setPreDate(1);
					from_key = preDateInfo2.preYear+preDateInfo2.preMonth+preDateInfo2.preDay+"0530000000";
					to_key = preDateInfo2.preYear+preDateInfo2.preMont+preDateInfo2.preDay+"07"+toMin+"000000";
				}else if(week==1) {		//1:월요일
					preDateInfo2 = setPreDate(2);
					from_key = preDateInfo2.preYear+preDateInfo2.preMonth+preDateInfo2.preDay+"0530000000";
					to_key = preDateInfo2.preYear+preDateInfo2.preMont+preDateInfo2.preDay+"07"+toMin+"000000";
				}else {
					from_key = toDate+"0530000000";
					to_key = toDate+"07"+toMin+"000000";
				}
				paramMrk = {fromKey:from_key, toKey:to_key};
				
				var resMarket = null;
				//글로벌증시 조회
				getWorldIndex().then(function(rsltIndex) {
					if(rsltIndex.status=="200"){
						//시장정보 상세조회 
						getMarketNewsDetailInfo(paramMrk).then(function(rsltMarket) {
							if(rsltMarket.status=="200"){
								if(rsltMarket.response!=null) {
									resMarket = rsltMarket.response;	//file write 추가가능성 있음
								}else{
									resMarket = null;	//file write 추가가능성 있음
								}
							}else{
								resMarket = null;	//file write 추가가능성 있음
							}
							message = makeHtmlWorldIndex(rsltIndex, resMarket, userInfo);
							RebotCore.showBotMessage(message.join(""), "글로벌증시");
						}); //getMarketNewsDetailInfo() end
					}
				});	//getWorldIndex() end
			}
		}
	}); //getClosure() end
}

// 글로벌증시 메세지 생성 (aichatbot.js의 globalMarket 카드 템플릿 적용)
function makeHtmlWorldIndex(rsltIndex, rspMarket, userInfo) {
	var indexData = rsltIndex.response.record1 || [];
	var resMsg = [];
	var text = "";
	var title = "미국/유럽 주요지수";
	var codes = window.RebotCore.EU_US_CODE; // aichatbot.js의 상수 직접 사용
	var data = {};
	var price = 0;
	var mark = 0;
	var cmpr = 0;

	// 글로벌 증시 현황 메시지
	text = "미국/유럽 주요지수 알림입니다.";

	resMsg.push('<div id="query-card-comp" class="query__card__comp">');
	resMsg.push('<p class="card__title">'+title+'</p>');
    resMsg.push('<div id="card-box" class="query__card__box">');

	if(indexData.length > 0){
		for(var j=0; j<codes.length; j++) {
			for(var i=0; i<indexData.length; i++) {
		    	if(codes[j].code == indexData[i].indxCd ) {
		    		price = (Number(indexData[i].nowPrc)/100).toFixed(2).toString().commify(); // String.prototype.commify 사용
	            	mark = Number(indexData[i].cmprr) < 0 ? "" : "+";
	            	cmpr = (Number(indexData[i].cmprr) / 100).toFixed(2);
	            	var text1 = '<img src="/images/web/' + codes[j].img + '" width="20px" height="15px"><font class="font_B"> ' + codes[j].name + '</font><font>(' +  indexData[i].dt.substring(4,6) + '/' + indexData[i].dt.substring(6,8) + ')</font>';
	            	var text2 = price.toString().addEnd(10," "); // String.prototype.addEnd 사용
	            	var rate = (mark+cmpr).toString().addStr(6," "); // String.prototype.addStr 사용
	            	window.RebotCore.makeCardMessage(resMsg,text1,text2,rate,mark); // aichatbot.js의 함수 직접 호출
					break;
				}
			}
		}
	}

    resMsg.push('</div>');
    resMsg.push('</div>');

    // 시장 뉴스가 있는 경우 추가
    if(rspMarket!=null) {
        var urlLink="https://rc.kbsec.com/m.html?t=2&id=" + rspMarket.mrkStUntyKey;

        resMsg.push("<br><li class='font_B'>🎯 " + rspMarket.title + "</li>");
        resMsg.push("<br><a href='javascript:void(0)' onclick='linkOpen(\"" + urlLink + "\");'><img src='/images/web/webchatbot_link.png' width='66px' height='19px'/></a>");
    }

    return resMsg;
}

// push KB데일리
function pushKBDaily(userData) {
	var registDate = toDate;	//현재날짜setting
	var reportList = [];
	var reportInfo = {};
	var sectCodeList = [];
	var sectCode = "";
	
	var param = {registDateFrom:registDate, registDateTo:registDate, pageNo:"1", pageSize:20};
	
	getDailyReportList(param).then(function(result) {
		if(result.status=="200") {			
			reportList=result.response.reportList;
			
			for(var i=0; i<reportList.length; i++) {
				report = reportList[i];
				RebotCore.showBotMessage(makeHtmlReport(report), "KB 데일리");
			}
		}
	});
}

// push 헤드라인 
function pushHeadLine() {
	var registDate = toDate;	//현재날짜setting
	var param = {registDate:registDate};
	var content = "";
	var resDocumentId = "";
	var resTitle = "";
	var urlLink = "";
	
	getHeadLine(param).then(function(result) {
		if(result.status=="200") {
			resDocumentId = result.response.documentid;
			resTitle = result.response.title;
			resTitle = resTitle.replace(/\n/g, "<br>");
			urlLink = "/detailView.able?documentid=H" + resDocumentId;
			
			if(resDocumentId!=null) {
				content  = "<li class='font_B'>- 헤드라인 알림 -</li>" + resTitle;
                content += "<br><a href='javascript:void(0)' onclick='linkOpen(\"" + urlLink + "\");'><img src='/images/web/webchatbot_link.png' width='66px' height='19px'/></a>";
                RebotCore.showBotMessage(content, "헤드라인");
			}
		}
	})
}

// 수동 푸쉬 알람 조회
function pushAlarm(userId) {
	var regDate = toDate + " " + toHours + ":" + toMin;
	var param = {userId : userId
			   , regDate : regDate};
	
	var html = "";
	var contents = "";
	var imgPath = "";	
	getPushAlarm(param).then(function(result) {		
		if(result.status=="200") {
			var alarmList = result.response;			 
			if(alarmList.length > 0) {
				for(var i=0; i<alarmList.length; i++) {
					contents = alarmList[i].contents;
					imgPath = alarmList[i].imgPath;
					contents = contents.replace(/\n/gi, "<br>");

					// 카드 형태로 변경
					var html = '<div class="prompt__cont">';
					html += '<div class="prompt__src sr_only" data-role="">query:</div>';
					html += '<div class="prompt__query_box">';
					html += '<div class="prompt__txt_adjust">';
					html += '<div class="prompt__query_title">푸시 알림</div>';
					html += '<div class="prompt__model_chosen">알림<img src="/reNew/images/chatbotAI/icons/gr_ic.svg" alt=""></div>';
					html += '</div>';

					// 이미지 표시
					if(imgPath.length > 0){
						html += '<div style="margin:10px 0;">';
						html += '<a href="javascript:void(0)" onclick="linkOpen(\'https://rc.kbsec.com' + imgPath + '\');">';
						html += '<img src="https://rc.kbsec.com' + imgPath + '" style="width:100%; max-width:300px; height:auto; border-radius:8px;">';
						html += '</a>';
						html += '</div>';
					}

					// 텍스트 내용
					html += '<div style="padding:15px; background:#f8f9fa; border-radius:8px; margin-top:10px;">';
					html += contents;
					html += '</div>';

					html += '</div>';
					html += '</div>';

		            RebotCore.showBotMessage(html, "푸시 알림");
				}
			}else {
				return;
			}
		}
	});
}

//----------------------------- 사용자 함수 -----------------------------//
// 투데이리포트 파라미터 날짜변환
function setReportSearchDate() {
	var paramDate = {};
	var registDate = "";
	var startTime = "";
	var endTime = "";
	
	var toHoursChk = Number(toHours);
	var toMinChk = Number(toMin);
	var preDateInfo = {};
	
	registDate = toDate;	//현재날짜setting
	
	if(toMinChk==0) {	//정시일때
		if(toHoursChk==0 || toHoursChk==24){	// 12시
			preDateInfo = setPreDate(1);
			
			registDate = String(preDateInfo.preYear) + String(preDateInfo.preMonth) + String(preDateInfo.preDay);	// 24시간 전 날짜
			startTime = "23:55";
			endTime = "23:59";
			//오전,오후12시일때 - 24시간전날짜, 23:55 ~ 23:59
		}else {
			startTime = zeroExpr(Number(toHours)-1) + ":55";
			endTime = toHours + ":00";
			//12시를 제외한 시간 ex)15:00 (현재날짜, 14:55~15:00)
		}
	}else {	//정시가 아닐때
		startTime = toHours + ":" + zeroExpr(toMinChk-5);
		endTime = toHours + ":" + toMin;
		//정시가 아닐때 ex) 15:30 (현재날짜, 15:25~15:30)
	}
	
	paramDate = {registDate:registDate, startTime:startTime, endTime:endTime};
	return paramDate;
}

// 전일 마감일 setting
function setPreDate(hour) {
	var preDate = moment(toDate, "YYYYMMDD").add("-"+hour, "d");
	var preDateInfo = {preYear:preDate.format("YYYY"), preMonth:preDate.format("MM"), preDay:preDate.format("DD")};	// 24시간 전 날짜
	return preDateInfo;
}

// 카테고리ID 부모 카테고리ID로 셋팅
function getPCategoryId(id) {
	var pCategoryId = "";
	
	for(var i=0; i<categoryList.length; i++) {
		if(id == categoryList[i].categoryid) {
			pCategoryId = categoryList[i].pCategoryid;
			break;
		}
	}
	return pCategoryId;
}

// 1 -> 01 형식으로 변환
function zeroExpr(numStr) {
	var num = Number(numStr);
	if(num < 10) {
		num = "0" + num;
	}
	return num;

}

